package com.pratap.springdataoverview.repository;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.pratap.springdataoverview.entity.Flight;

// public interface FlightRepository extends CrudRepository<Flight, Long>
public interface FlightRepository extends PagingAndSortingRepository<Flight, Long>, DeleteByOriginRepository {

	// SELECT * FROM flight WHERE origin = ?
    List<Flight> findByOrigin(String origin);

    // SELECT * FROM flight WHERE origin = ? AND destination = ?
    List<Flight> findByOriginAndDestination(String london, String destination);

    // SELECT * FROM flight WHERE origin IN (?)
    List<Flight> findByOriginIn(String ... origins);

    // SELECT * FROM flight WHERE upper(origin) = upper(?)
    List<Flight> findByOriginIgnoreCase(String origin);

    Page<Flight> findByOrigin(String origin, Pageable pageRequest);
}
