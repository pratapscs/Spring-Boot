package com.pratap.exceptions;

public class FriendEntityException extends RuntimeException {
	
	private static final long serialVersionUID = -5894885583783682360L;

	public FriendEntityException() {
        super();
    }

    public FriendEntityException(String message) {
        super(message);
    }

    public FriendEntityException(String message, Throwable cause) {
        super(message, cause);
    }

    public FriendEntityException(Throwable cause) {
        super(cause);
    }

    protected FriendEntityException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}
