package com.pratap.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class FriendNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -5767045163601350123L;

	public FriendNotFoundException(String message) {
        this(message, null);
    }

    public FriendNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}