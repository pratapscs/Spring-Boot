package com.pratap.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.pratap.model.Employee;

public interface EmployeeRepository extends PagingAndSortingRepository<Employee, Long> {
}
