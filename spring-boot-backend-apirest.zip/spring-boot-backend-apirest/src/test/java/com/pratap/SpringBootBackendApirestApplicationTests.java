package com.pratap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBackendApirestApplicationTests {

	@Test
	void contextLoads() {
	}

}
