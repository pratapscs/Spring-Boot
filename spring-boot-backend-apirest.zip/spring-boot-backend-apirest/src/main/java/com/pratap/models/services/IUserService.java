package com.pratap.models.services;

import com.pratap.models.entity.User;

public interface IUserService {

	public User findByUsername(String username);
}
