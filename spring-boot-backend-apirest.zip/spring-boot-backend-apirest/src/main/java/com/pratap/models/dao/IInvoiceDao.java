package com.pratap.models.dao;

import org.springframework.data.repository.CrudRepository;

import com.pratap.models.entity.Invoice;

public interface IInvoiceDao extends CrudRepository<Invoice, Long>{

}
