package com.pratap.todoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoAppApplication.class, args);
	}

}

/*
 * What is an actuator?
-------------------
- An actuator is a compoent, responsible for..controlling a mechanism or system.

- An Actuator Receives a signal and generates output.
  (Signal -> Actuator = Output).

- Describing Spring Boot Actuator: 
  Spring Boot Actuator lets you monitor and interact, or control, your application.

- Spring Boot Actuator's Benifits:
  --------------------------------
 - Automatically built-in features.
 - https://docs.spring.io/spring-boot/docs/current/reference/html/production-ready-  features.html#production-ready-endpoints
  - production ready.

- fundamentally, the concepts in spring boot actuator 1.x and 2.x are the same.
- Spring Boot Actuator 1.x
   - Spring MVC
   - Extension-based
   - Hierachical metrics
   - Custom metrics collector
   - Less secure by default.

- Spring Boot Actuator 2.x
   - Spring MVC, JAX-RS, and Webflux
   - Annotation-driven
   - Hierarchical & dimensional metrics
   - MicroMEter-based metrics collection
   - More Secure by default.

Using Spring Boot Actuator with Maven:
-------------------------------------
  <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-actuator</artifactId>
  <dependency>

Using Spring Boot Actuator with Gradle:
--------------------------------------
build.gradle

dependencies{
    compile("org.springframework.boot:spring-boot-starter-actuator")
}

what is an Actuator endpoint?
----------------------------

What Actuator end points are included with Spring Boot by default?
-----------------------------------------------------------------

Most Common Endpoints and How they're used:
------------------------------------------
- Health Endpoint(With cloud data applications and especially microservices, checking the 
  health of your application is a regular thing. It's also a very important thing and so 
  many container management systems like Docker Swarm or Kubernetes come with functionality 
  to regular run a health check.)

- Metrics Endpoint(able to see inside of your live application while it's running, especially 
  in a production environment,You can use it for requesting individual metrics like the amount 
  of memory that your application is using or you can use it to drive performance dashboards 
  like Grafana, or New Relic, or DataDog and it allows you to have constant insight into 
  your application)

- Loggers Endpoint


Actuator endpoints in a action:
-------------------------------
- http://localhost:8080/actuator/health
- http://localhost:8080/actuator/metrics
- http://localhost:8080/actuator/metrics/jvm.memory.used
- http://localhost:8080/actuator/loggers
- http://localhost:8080/actuator/configprops


Deeper Look: Health Endpoint:
----------------------------
- An endpoint that provides a surprisingly comprehensive health check.

- What's possible with the health endpoint?
  -----------------------------------------
  - The results re an aggregation of several health checks.

  - some health checks(indicators) are auto-configured by default.(if your application 
    utilized elastic search, Spring Boot would detect the elastic search libraries on 
    the class path and automatically set up a health check to ensure that elastic search 
    was up and reachable and that individual elastic search health check would then roll 
    up with all the other health checks to determine as a whole is the application 
    healthy or unhealthy.)

  - Allows for easily adding custom health checks.(consider you had an application that 
    depended on a legacy system. You could write your own custom health check for the 
    legacy system and use that as one of the contributing factors to determine the health 
    status of your application)

Deep Dive: Metrics Endpoint:
---------------------------
- An Endpoint that provides detailed, hierarchical, and dimensional metrics can be 
  pushed or pulled.
- What's possible with the Metrics Endpoint?
  -----------------------------------------
- Built-in support for many monitoring systems.
- Built in core metrics
- bility to add custom metrics or augment existing metrics.


Securing Actuator Endpoints and creating customizations:
--------------------------------------------------------
Enabling and disabling Actuator Endpoints:
------------------------------------------
- Individual endpoints can be enabled or disabled.
- controls the creating of the endpoint.
- By Default, all actuator endpoints, except shutdown, are enabled.
- Enabling and disabling specific endpoints:
  - Configure application.properties or application.yml
  - Replace <NAME> with ID of endpoint.
  - ex: management.endpoint.<NAME>.enabled = true
        management.endpoint.<NAME>.enabled = false
- Disabled by default
  - All endpoints enabled-by-default, can be turned off.
  - USeful when you want only a few endpoints enabled.
   Ex: management.endpoints.enabled-by-default = true
       management.endpoint.health.enabled = true
       management.endpoint.loggers.enabled = true
       management.endpoint.env.enabled = true

Exposting Actuator endpoints:
----------------------------
- exposing an endpoint makes it available for consumption.
- individual endpoints can be included/excluded for exposure.
- Supported methods for exposing endpoints: HTTP, JMX
- all endpoints are exposed via JMX, by default.
- Most endpoints are not exposed via HTTP by default, only the health 
  and info endpoints.
- use caution when exposing endpoints, particularly via HTTP.
- Ensure endpoints are secured.
- controlling which endpoints are and ren't exposed:
  -application.properties
   management.endpoint.<PROTOCOL>.expose.include = 
   management.endpoint.<PROTOCOL>.expose.exclude =  

  # included http endpoints
  management.endpoint.<PROTOCOL>.expose.include = metrics

  # excluded jmx endpoints
  management.endpoint.jmx.expose.exclude = beans
  
  #Enable ALL http endpoints
   management.endpoint.http.expose.include = *
   
Enabling Vs. Exposing endpoints:
-------------------------------
- enabling != exposing
- Enablind:
  - controles creation
  - almost all endpoints are enabled by default.
  - efficiency purposes.
- Exposing
  - Controles consumption.
  - almost all endpoints are not exposed via HTTP by default
  - Security purposes.

Ex: 
  management.endpoints.web.exposure.include=beans,metrics,info,health,loggers
  management.endpoint.loggers.enabled=false
    http://localhost:8080/actuator/beans - it will display
    http://localhost:8080/actuator/configprops - it will not display
    http://localhost:8080/actuator/loggers - it will not display

Securing Acuator Endpoints:
--------------------------
- Enpoint security is automatically configured if spring security is on the clsspath.
  - Adds HTTP basic authentication to all endpoints except(Health, Info)
 <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-security</artifactId>
  <dependency>
  - Credentials: 
      - default credentials will automatically be configured
      - credentials are configurable
      - in console : AuthenticationManagerConfiguration : 
         using default security password: <random string>
        Note: The defaulr username is 'user'.
        spring.security.user.name = <username>
        spring.security.user.password = <password>

Endpoint Security Is Completely Custamizable:
--------------------------------------------
@Configuration(proxyBeanMethods = false)
public class ActuatorSecurity extends WebSecurityConfigurerAdaptor{
	
	@override
        protected void configure(HttpSecurity http) throws Exception{
 	  http
              .requestMatcher(EndpointRequest.toAnyEndPoint())
              .authorizeRequests((res) -> req.anyRequest().hasRole("ADMIN"));
	  
          http.httpBasic();
        }
}

Customizing Built-in endpoints:
-------------------------------
What can be customized?
- A subset of endpoints suport customizations.
  - Health endpoint
  - Info endpoint
  - Metrics endpoint

Customizing the Health Endpoint:
-------------------------------
- Adding additional checks and details to /health
- Adding custom Health checks and details to the health endpoint
  - create and register a new bean that implements HealthIndicator.
  - Implement the health() method.Return a Health object with the appropriate status.
  - Creating a custom HealthIndicator with details:
    ----------------------------------------------
@Component
public class FooServiceHealthIndicator implements HealthIndicator{

   @OVerride
   public Health health(){
     // perform a custom health check
     
     // insepect the status

     // unhealthy
     return Health.down()
		.withDetail("response_code", "...")
		.withDetail("response_ms", "...")
		.withDetail("num_retries", "...")
		.build();
}

Customizing the Info Endpoint:
-----------------------------
- Adding additional information points to /info
- Adding custom data to the info endpoint
  - Create and register a new bean that implements InfoContributor.
  - Implement the contribute() method and add data with the provided Info.Builder.
  - Creating a Custom InfoContributor:
    ----------------------------------
@Component
public class ProjectInfoContributor implements InfoContributor{

    @Override
    public void contribute(Info.Builder builder){
       // add new info 
       builder.withDetail("project_name", "...")
	      .withDetail("owned_by_team", "...")
              .withDetail("point_of_contact", "...")
    }
}

Customizing the Metrics Endpoint:
--------------------------------
- Adding new custom metrics.
- adding custom metrics tothe metrics endpoint
  - inject a MeterRegistry into the class metrics and register a new metric.
  - use the metric.( e.g. timer.record(...) or counter.increment() )
  - Exposing Custom Metrics Using the MeterRegistry:
    -----------------------------------------------
@Service
public class ComplexService{
    private Timer timer;
    
    public ComplexService(MeterRegistry registry){
	// give the timer a name
    timer = registry.timer("long.running.op.timer")  
    }
    
    public void longRunningOperation(){
	timer.record(() -> {
         // a  long running operation
        })
   }
}

Creating your own Actuator endpoints:
------------------------------------
- crate and register new bean annotated with @Endpoint
- Implementing a custom endpoints 
   - Annotate methods with one of @ReadOperation, @WriteOperation, @DeleteOperation.

@component
@Endpoint(id = "container")
public class DockerEndpoint{

    @ReadOperation 
    public String foo(){
       // gather and return information(e.g. get info about the docker container)
    }

    @WriteOperation 
    public String bar(){
       // Do some action(e.g. restart the docker container)
    }



}
 * 
 */
