package com.pratap.db.repository;


public interface ModelJpaRepositoryCustom {

	void aCustomMethod();
}
