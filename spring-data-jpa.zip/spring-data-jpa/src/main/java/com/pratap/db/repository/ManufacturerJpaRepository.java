package com.pratap.db.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pratap.db.model.Manufacturer;

@Repository
public interface ManufacturerJpaRepository extends JpaRepository<Manufacturer, Long> {

	List<Manufacturer> findByFoundedDateBefore(Date date); // Before 
	
	List<Manufacturer> findByActiveTrue(); // True
	List<Manufacturer> findByActiveFalse(); // False
	
	List<Manufacturer> getAllThatSellAcoustics(String name);
}
