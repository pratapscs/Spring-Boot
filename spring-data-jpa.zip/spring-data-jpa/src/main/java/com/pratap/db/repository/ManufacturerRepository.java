package com.pratap.db.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pratap.db.model.Manufacturer;

@Repository
public class ManufacturerRepository {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	private ManufacturerJpaRepository manufacturerJpaRepository;

	/**
	 * Create
	 */
	public Manufacturer create(Manufacturer man) {
		
		return manufacturerJpaRepository.saveAndFlush(man);
		/*
		entityManager.persist(man);
		entityManager.flush();
		return man;
		*/ 
	}

	/**
	 * Update
	 */
	public Manufacturer update(Manufacturer man) {
		
		return manufacturerJpaRepository.saveAndFlush(man);
		/*
		man = entityManager.merge(man);
		entityManager.flush();
		return man;
		*/
	}

	/**
	 * Delete
	 */
	public void delete(Manufacturer man) {
		
		manufacturerJpaRepository.delete(man);
		/*
		entityManager.remove(man);
		entityManager.flush();
		*/
	}

	/**
	 * Find
	 */
	public Manufacturer find(Long id) {
		
		return manufacturerJpaRepository.findOne(id);
		//return entityManager.find(Manufacturer.class, id);
	}

	/**
	 * Custom finder
	 */
	public List<Manufacturer> getManufacturersFoundedBeforeDate(Date date) {
		
		return manufacturerJpaRepository.findByFoundedDateBefore(date);
		/*
		@SuppressWarnings("unchecked")
		List<Manufacturer> mans = entityManager
				.createQuery("select m from Manufacturer m where m.foundedDate < :date")
				.setParameter("date", date).getResultList();
		return mans;
		*/
	}

	/**
	 * Custom finder
	 */
	public Manufacturer getManufacturerByName(String name) {
		Manufacturer man = (Manufacturer)entityManager
				.createQuery("select m from Manufacturer m where m.name like :name")
				.setParameter("name", name + "%").getSingleResult();
		return man;
	}

	/**
	 * Native Query finder
	 */
	public List<Manufacturer> getManufacturersThatSellModelsOfType(String modelType) {
		
		return manufacturerJpaRepository.getAllThatSellAcoustics(modelType);
		/*
		@SuppressWarnings("unchecked")
		List<Manufacturer> mans = entityManager
				.createNamedQuery("Manufacturer.getAllThatSellAcoustics")
				.setParameter(1, modelType).getResultList();
		return mans;
		*/
	}
}
