package com.pratap.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pratap.db.model.Location;

@Repository
public interface LocationJpaRepository extends JpaRepository<Location, Long> {

	List<Location> findByStateLike(String state); // Like
	List<Location> findByStateNotLike(String state); // Not Like
	
	List<Location> findByStateStartingWith(String state); // StartingWith
	
	List<Location> findByStateOrCountry(String value, String value2); // Or
	List<Location> findByStateAndCountry(String state, String country); // And 
	
	List<Location> findByStateIsOrCountryEquals(String value, String value2);
	List<Location> findByStateNot(String state);
	
	List<Location> findByStateIgnoreCaseStartingWith(String stateName); // IgnoreCase
	Location findFirstByStateIgnoreCaseStartingWith(String stateName); // FirstBy
	List<Location> findByStateNotLikeOrderByStateAsc(String stateName); // OrderBy
	
	
}
