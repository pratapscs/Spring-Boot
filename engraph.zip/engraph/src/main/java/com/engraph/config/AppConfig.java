package com.engraph.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
//import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
//@EnableResourceServer
public class AppConfig implements WebMvcConfigurer{
	
	private static final Logger logger = LoggerFactory.getLogger(AppConfig.class);
	
	 @Override
	    public void addCorsMappings(CorsRegistry registry) {

	        registry.addMapping("/**")
	                .allowedOrigins("http://localhost:4200")
	                .allowedMethods("GET", "POST", "PUT", "DELETE", "HEAD")
	                .allowCredentials(true);
	    }

}