package com.engraph.config;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;


@Configuration
public class PhoenixDatabaseConfig {

	private static final Logger logger = LoggerFactory.getLogger(PhoenixDatabaseConfig.class);
	
	@Autowired
	private Environment env;
	
	 @Bean(name = "phoenixDataSource")
	 //@ConfigurationProperties(prefix = "spring.phoenix.datasource")
	 public DataSource phoenixDataSource() {
		 	DriverManagerDataSource dataSource = new DriverManagerDataSource();
		    dataSource.setDriverClassName(env.getProperty("spring.phoenix.datasource.driver-class-name"));
		    dataSource.setUrl(env.getProperty("spring.phoenix.datasource.url"));
		    dataSource.setUsername(env.getProperty("spring.phoenix.datasource.username"));
		    dataSource.setPassword(env.getProperty("spring.phoenix.datasource.password"));
		    logger.info("## PHOENIX DataSource: " + dataSource);
		    return dataSource;
	 }
	

	 @Bean(name = "jdbcTemplatePhoenix")
	 public JdbcTemplate jdbcTemplate1(@Qualifier("phoenixDataSource") DataSource ds) {
	  return new JdbcTemplate(ds);
	 }

}
