package com.engraph.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;

import javax.jms.ConnectionFactory;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.converter.MappingJackson2MessageConverter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.MessageType;


//@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
@Configuration
@EnableJms
public class ApplicationProperties {
	
	private static final Logger logger = LoggerFactory.getLogger(ApplicationProperties.class);

	@Value("${mail.base-url}")
	private String baseUrl;

	@Value("${spring.activemq.broker-url}")
	private String mqUrl;
	 
	@Value("${spring.activemq.user}")
	private String user;
	
	@Value("${spring.activemq.password}")
	private String password;
	
	@Value("${mq.topic}")
	private String topic;
	

	//Initial ConnectionFactory
	@Bean
	public ConnectionFactory connectionFactory() {
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
		connectionFactory.setBrokerURL(mqUrl);
		connectionFactory.setUserName(user);
		connectionFactory.setPassword(password);
		//connectionFactory.setClientID("client-dcu");
		return connectionFactory;
	}
	
	
	@Bean
	public DefaultJmsListenerContainerFactory topicListenerFactory(ConnectionFactory connectionFactory,
	                                                           DefaultJmsListenerContainerFactoryConfigurer configurer) {
	    DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
	    configurer.configure(factory, connectionFactory);
	    //factory.setPubSubDomain(true);
	    factory.setConnectionFactory(connectionFactory);
        factory.setConcurrency("1");
        factory.setConnectionFactory(connectionFactory());
	    factory.setSubscriptionDurable(true);
	    factory.setSubscriptionShared(true);
	    return factory;
	}	

	// Serialize message content to JSON using TextMessage
	@Bean 
	public MessageConverter jacksonJmsMessageConverter() {
	      MappingJackson2MessageConverter converter = new MappingJackson2MessageConverter();
	      converter.setTargetType(MessageType.TEXT);
	      converter.setTypeIdPropertyName("engraph");
	      return converter;
	 }
	  
	/*
     * Used for Sending Messages.
     */
	@Bean
	public JmsTemplate jmsTemplate(){
		JmsTemplate template = new JmsTemplate();
	    template.setConnectionFactory(connectionFactory());
	    template.setMessageConverter(jacksonJmsMessageConverter());
	    //template.setPubSubDomain(true);
	    //template.setDeliveryMode(DeliveryMode.PERSISTENT);
	    //template.isExplicitQosEnabled();
	    //template.setDefaultDestinationName(queue);
	
	    return template;
	}
    
	public String getBaseUrl() {
		return baseUrl;
	}
	

	/*
	 * public String getUserName() { return userName; }
	 * 
	 * public String getPassword() { return password; }
	 */
	public String getMqUrl() {
		return mqUrl;
	}

	private final Cache cache = new Cache();

	public Cache getCache() {
		return cache;
	}

	public static class Cache {

		private final Ehcache ehcache = new Ehcache();

		public Ehcache getEhcache() {
			return ehcache;
		}

		public static class Ehcache {

			private int timeToLiveSeconds = 3600;
			private long maxEntries = 100;

			public int getTimeToLiveSeconds() {
				return timeToLiveSeconds;
			}

			public void setTimeToLiveSeconds(int timeToLiveSeconds) {
				this.timeToLiveSeconds = timeToLiveSeconds;
			}

			public long getMaxEntries() {
				return maxEntries;
			}

			public void setMaxEntries(long maxEntries) {
				this.maxEntries = maxEntries;
			}
		}
	}
}
