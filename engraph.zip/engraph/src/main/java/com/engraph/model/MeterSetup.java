package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * A MeterSetup Entity
 */
@Entity
@Table(name = "meter_setup")
public class MeterSetup implements Serializable{

	private static final long serialVersionUID = -6554737303823175742L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "meter_setup_id")
	private Long meterSetupId;

	@ManyToOne
	@JoinColumn(name = "dcuId")
	private Dcudetails dcu;

	@ManyToOne
	@JoinColumn(name = "siteId")
	private SiteMaster siteId;

	@ManyToOne
	@JoinColumn(name = "electricity_meter_id")
	private EletricityMeter meter;

	@Column(name = "meter_company")
	private String meterCompany;

	@Column(name = "meter_model")
	private String meterModel;

	public MeterSetup() {

	}

	public Long getMeterSetupId() {
		return meterSetupId;
	}

	public void setMeterSetupId(Long meterSetupId) {
		this.meterSetupId = meterSetupId;
	}

	public Dcudetails getDcu() {
		return dcu;
	}

	public void setDcu(Dcudetails dcu) {
		this.dcu = dcu;
	}

	public EletricityMeter getMeter() {
		return meter;
	}

	public void setMeter(EletricityMeter meter) {
		this.meter = meter;
	}

	public String getMeterCompany() {
		return meterCompany;
	}

	public void setMeterCompany(String meterCompany) {
		this.meterCompany = meterCompany;
	}

	public String getMeterModel() {
		return meterModel;
	}

	public void setMeterModel(String meterModel) {
		this.meterModel = meterModel;
	}

	public SiteMaster getSiteId() {
		return siteId;
	}

	public void setSiteId(SiteMaster siteId) {
		this.siteId = siteId;
	}

}
