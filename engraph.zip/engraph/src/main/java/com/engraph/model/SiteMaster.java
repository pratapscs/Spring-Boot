package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 * A Site Master Entity
 */
@Entity
@Table(name = "site_master")
public class SiteMaster implements Serializable {

	private static final long serialVersionUID = 1671653942688935935L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "site_id")
	private Long siteId;

	@Size(max = 100)
	@Column(name = "site_name", length = 100)
	private String siteName;

	@Size(max = 50)
	@Column(name = "site_type", length = 50)
	private String siteType;

	@Size(max = 50)
	@Column(name = "site_connection_type", length = 50)
	private String siteConnectionType;

	@Column(name = "site_total_area")
	private Double siteTotalArea;

	@Column(name = "site_buildup_area")
	private Double siteBuildupArea;

	@Column(name = "site_open_area")
	private Double siteOpenArea;

	@Column(name = "site_terrace_area")
	private Double siteTerraceArea;

	@Column(name = "site_building_no")
	private Integer siteBuildingNo;

	@Column(name = "site_energy_auditing")
	private String siteEnergyAuditing;

	@Size(max = 30)
	@Column(name = "site_goal_amount", length = 30)
	private String siteGoalAmount;

	@ManyToOne
	@JoinColumn(name = "organization_id")
	private Organization organization;

	@Column(name = "site_latitude")
	private Double siteLatitude;

	@Column(name = "site_longitude")
	private Double siteLongitude;

	public SiteMaster() {

	}

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public Organization getOrganization() {
		return organization;
	}

	public void setOrganization(Organization organization) {
		this.organization = organization;
	}

	public String getSiteType() {
		return siteType;
	}

	public void setSiteType(String siteType) {
		this.siteType = siteType;
	}

	public String getSiteConnectionType() {
		return siteConnectionType;
	}

	public void setSiteConnectionType(String siteConnectionType) {
		this.siteConnectionType = siteConnectionType;
	}

	public Double getSiteTotalArea() {
		return siteTotalArea;
	}

	public void setSiteTotalArea(Double siteTotalArea) {
		this.siteTotalArea = siteTotalArea;
	}

	public Double getSiteBuildupArea() {
		return siteBuildupArea;
	}

	public void setSiteBuildupArea(Double siteBuildupArea) {
		this.siteBuildupArea = siteBuildupArea;
	}

	public Double getSiteOpenArea() {
		return siteOpenArea;
	}

	public void setSiteOpenArea(Double siteOpenArea) {
		this.siteOpenArea = siteOpenArea;
	}

	public Double getSiteTerraceArea() {
		return siteTerraceArea;
	}

	public void setSiteTerraceArea(Double siteTerraceArea) {
		this.siteTerraceArea = siteTerraceArea;
	}

	public Integer getSiteBuildingNo() {
		return siteBuildingNo;
	}

	public void setSiteBuildingNo(Integer siteBuildingNo) {
		this.siteBuildingNo = siteBuildingNo;
	}

	public String getSiteEnergyAuditing() {
		return siteEnergyAuditing;
	}

	public void setSiteEnergyAuditing(String siteEnergyAuditing) {
		this.siteEnergyAuditing = siteEnergyAuditing;
	}

	public String getSiteGoalAmount() {
		return siteGoalAmount;
	}

	public void setSiteGoalAmount(String siteGoalAmount) {
		this.siteGoalAmount = siteGoalAmount;
	}

	public double getSiteLatitude() {
		return siteLatitude;
	}

	public void setSiteLatitude(double siteLatitude) {
		this.siteLatitude = siteLatitude;
	}

	public double getSiteLongitude() {
		return siteLongitude;
	}

	public void setSiteLongitude(double siteLongitude) {
		this.siteLongitude = siteLongitude;
	}

}