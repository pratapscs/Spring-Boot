package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dcu_production_master")
public class Dcudetails implements Serializable {

	private static final long serialVersionUID = -3343594108870468818L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long dcuId;

	@Column(name = "Manufacturing_ID")
	private long manufacturingID;

	@Column(name = "Model_No")
	private String modelNo;

	@Column(name = "Manufacturing_Date")
	private String manufacturingDate;

	@Column(name = "Service_Active_State")
	private Boolean serviceActiveState;

	@Column(name = "Batch_Number")
	private String batchNumber;

	@Column(name = "Lot_Quantity")
	private Integer lotQuantity;

	@Column(name = "Base_Price")
	private Double basePrice;

	@Column(name = "Market_Price")
	private Double marketPrice;

	@Column(name = "Minimum_Discountable_Percentage")
	private Double minimumDiscountablePercentage;

	@Column(name = "Maximum_Discountable_Percentage")
	private Double maximumDiscountablePercentage;

	public Dcudetails() {

	}

	public Long getDcuId() {
		return dcuId;
	}

	public void setDcuId(Long dcuId) {
		this.dcuId = dcuId;
	}

	public String getModelNo() {
		return modelNo;
	}

	public long getManufacturingID() {
		return manufacturingID;
	}

	public void setManufacturingID(long manufacturingID) {
		this.manufacturingID = manufacturingID;
	}

	public void setModelNo(String modelNo) {
		this.modelNo = modelNo;
	}

	public String getManufacturingDate() {
		return manufacturingDate;
	}

	public void setManufacturingDate(String manufacturingDate) {
		this.manufacturingDate = manufacturingDate;
	}

	public Boolean getServiceActiveState() {
		return serviceActiveState;
	}

	public void setServiceActiveState(Boolean serviceActiveState) {
		this.serviceActiveState = serviceActiveState;
	}

	public String getBatchNumber() {
		return batchNumber;
	}

	public void setBatchNumber(String batchNumber) {
		this.batchNumber = batchNumber;
	}

	public Integer getLotQuantity() {
		return lotQuantity;
	}

	public void setLotQuantity(Integer lotQuantity) {
		this.lotQuantity = lotQuantity;
	}

	public Double getBasePrice() {
		return basePrice;
	}

	public void setBasePrice(Double basePrice) {
		this.basePrice = basePrice;
	}

	public Double getMarketPrice() {
		return marketPrice;
	}

	public void setMarketPrice(Double marketPrice) {
		this.marketPrice = marketPrice;
	}

	public Double getMinimumDiscountablePercentage() {
		return minimumDiscountablePercentage;
	}

	public void setMinimumDiscountablePercentage(Double minimumDiscountablePercentage) {
		this.minimumDiscountablePercentage = minimumDiscountablePercentage;
	}

	public Double getMaximumDiscountablePercentage() {
		return maximumDiscountablePercentage;
	}

	public void setMaximumDiscountablePercentage(Double maximumDiscountablePercentage) {
		this.maximumDiscountablePercentage = maximumDiscountablePercentage;
	}

}
