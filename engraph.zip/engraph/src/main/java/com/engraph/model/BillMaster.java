package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * A Bill Master Entity
 */
@Entity
@Table(name = "bill_master")
public class BillMaster implements Serializable {

	private static final long serialVersionUID = 6788646428468828702L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bill_master_id")
	private Long billMasterId;

	@OneToOne
	@JoinColumn(name = "location_id")
	private LocationMaster locationId;

	@ManyToOne
	@JoinColumn(name = "discom_id")
	private DiscomMaster discomId;

	@ManyToOne
	@JoinColumn(name = "power_tension_id")
	private PowerTensionMaster powerTensionId;

	@ManyToOne
	@JoinColumn(name = "discom_category_id")
	private DiscomCategoryBusinessTypeMaster discomCategoryId;

	@Column(name = "phase_connection")
	private String phaseConnection;

	@Column(name = "bill_parameter")
	private String billParameter;

	@Column(name = "bill_currency")
	private String billCurrency;

	@Column(name = "meter_rent")
	private Double meterRent;

	@Column(name = "bill_payment_date")
	private String billPaymentDate;

	@Column(name = "electricity_bill")
	private String electricityBill;

	public BillMaster() {
		
	}
	
	public LocationMaster getLocationId() {
		return locationId;
	}

	public void setLocationId(LocationMaster locationId) {
		this.locationId = locationId;
	}

	public Long getBillMasterId() {
		return billMasterId;
	}

	public void setBillMasterId(Long billMasterId) {
		this.billMasterId = billMasterId;
	}

	public DiscomMaster getDiscomId() {
		return discomId;
	}

	public void setDiscomId(DiscomMaster discomId) {
		this.discomId = discomId;
	}

	public PowerTensionMaster getPowerTensionId() {
		return powerTensionId;
	}

	public void setPowerTensionId(PowerTensionMaster powerTensionId) {
		this.powerTensionId = powerTensionId;
	}

	public DiscomCategoryBusinessTypeMaster getDiscomCategoryId() {
		return discomCategoryId;
	}

	public void setDiscomCategoryId(DiscomCategoryBusinessTypeMaster discomCategoryId) {
		this.discomCategoryId = discomCategoryId;
	}

	public String getPhaseConnection() {
		return phaseConnection;
	}

	public void setPhaseConnection(String phaseConnection) {
		this.phaseConnection = phaseConnection;
	}

	public String getBillParameter() {
		return billParameter;
	}

	public void setBillParameter(String billParameter) {
		this.billParameter = billParameter;
	}

	public String getBillCurrency() {
		return billCurrency;
	}

	public void setBillCurrency(String billCurrency) {
		this.billCurrency = billCurrency;
	}

	public Double getMeterRent() {
		return meterRent;
	}

	public void setMeterRent(Double meterRent) {
		this.meterRent = meterRent;
	}

	public String getBillPaymentDate() {
		return billPaymentDate;
	}

	public void setBillPaymentDate(String billPaymentDate) {
		this.billPaymentDate = billPaymentDate;
	}

	public String getElectricityBill() {
		return electricityBill;
	}

	public void setElectricityBill(String electricityBill) {
		this.electricityBill = electricityBill;
	}

}
