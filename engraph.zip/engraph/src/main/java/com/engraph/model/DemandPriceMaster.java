package com.engraph.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * A Demand Price Entity
 */
@Entity
@Table(name = "demand_price")
public class DemandPriceMaster implements Serializable {

	private static final long serialVersionUID = -4897591647792292525L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "demand_price_id")
	private Long demandPriceId;

	@Column(name = "start_date")
	private Date startDate;

	@Column(name = "end_date")
	private Date endDate;

	@Column(name = "contract_demand")
	private String contractDemand;

	@Column(name = "demand_parameter")
	private String demandParameter;

	@Column(name = "demand_rate")
	private String demandRate;

	@Column(name = "over_usage_rate")
	private String overUsageRate;

	@Column(name = "demand_percentage")
	private String demandPercentage;

	@Column(name = "demand_intervel")
	private String demandIntervel;

	public DemandPriceMaster() {

	}

	public Long getDemandPriceId() {
		return demandPriceId;
	}

	public void setDemandPriceId(Long demandPriceId) {
		this.demandPriceId = demandPriceId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getContractDemand() {
		return contractDemand;
	}

	public void setContractDemand(String contractDemand) {
		this.contractDemand = contractDemand;
	}

	public String getDemandParameter() {
		return demandParameter;
	}

	public void setDemandParameter(String demandParameter) {
		this.demandParameter = demandParameter;
	}

	public String getDemandRate() {
		return demandRate;
	}

	public void setDemandRate(String demandRate) {
		this.demandRate = demandRate;
	}

	public String getOverUsageRate() {
		return overUsageRate;
	}

	public void setOverUsageRate(String overUsageRate) {
		this.overUsageRate = overUsageRate;
	}

	public String getDemandPercentage() {
		return demandPercentage;
	}

	public void setDemandPercentage(String demandPercentage) {
		this.demandPercentage = demandPercentage;
	}

	public String getDemandIntervel() {
		return demandIntervel;
	}

	public void setDemandIntervel(String demandIntervel) {
		this.demandIntervel = demandIntervel;
	}

}
