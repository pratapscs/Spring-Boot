package com.engraph.model;

public class ProcessAssets {

	private String siteId;
	private String siteName;
	private String siteBuildingId;
	private String buildingName;
	private String buildingFloorId;
	private String floorNumber;
	private String floorName;
	private String assetId;
	private String assetName;
	private String time;
	private String date;
	private String dates;
	private String hDate;
	private Double exactKwh;
	private Double vryPhase;
	private Double vybPhase;
	private Double vbrPhase;
	private String weekDate;
	private String weekDay;
	private String monthDate;
	private Double individualMeterDailyKwhSum;
	private Double co2Emission;
	private Double dailyIndividualMeterVryVoltageAvg;
	private Double dailyIndividualMeterVybVoltageAvg;
	private Double dailyIndividualMeterVbrVoltageAvg;
	private Double wattsTotal;
	private Double vaTotal;
	private Double pfAvgInst;
	private Double dailyIndividualMeterTotalKwAvg;
	private Double dailyIndividualMeterTotalKvaAvg;
	private Double dailyIndividualMeterTotalPfAvg;
	private Double dailyIndividualMeterLineToLineVoltageAvg;
	private Double dailyMeterWiseCo2Sum;

	public ProcessAssets() {

	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getSiteBuildingId() {
		return siteBuildingId;
	}

	public void setSiteBuildingId(String siteBuildingId) {
		this.siteBuildingId = siteBuildingId;
	}

	public String getBuildingFloorId() {
		return buildingFloorId;
	}

	public void setBuildingFloorId(String buildingFloorId) {
		this.buildingFloorId = buildingFloorId;
	}

	public String getFloorNumber() {
		return floorNumber;
	}

	public void setFloorNumber(String floorNumber) {
		this.floorNumber = floorNumber;
	}

	public String getFloorName() {
		return floorName;
	}

	public void setFloorName(String floorName) {
		this.floorName = floorName;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDates() {
		return dates;
	}

	public void setDates(String dates) {
		this.dates = dates;
	}

	public String gethDate() {
		return hDate;
	}

	public void sethDate(String hDate) {
		this.hDate = hDate;
	}

	public Double getExactKwh() {
		return exactKwh;
	}

	public void setExactKwh(Double exactKwh) {
		this.exactKwh = exactKwh;
	}

	public Double getVryPhase() {
		return vryPhase;
	}

	public void setVryPhase(Double vryPhase) {
		this.vryPhase = vryPhase;
	}

	public Double getVybPhase() {
		return vybPhase;
	}

	public void setVybPhase(Double vybPhase) {
		this.vybPhase = vybPhase;
	}

	public Double getVbrPhase() {
		return vbrPhase;
	}

	public void setVbrPhase(Double vbrPhase) {
		this.vbrPhase = vbrPhase;
	}

	public String getWeekDate() {
		return weekDate;
	}

	public void setWeekDate(String weekDate) {
		this.weekDate = weekDate;
	}

	public String getWeekDay() {
		return weekDay;
	}

	public void setWeekDay(String weekDay) {
		this.weekDay = weekDay;
	}

	public String getMonthDate() {
		return monthDate;
	}

	public void setMonthDate(String monthDate) {
		this.monthDate = monthDate;
	}

	public Double getIndividualMeterDailyKwhSum() {
		return individualMeterDailyKwhSum;
	}

	public void setIndividualMeterDailyKwhSum(Double individualMeterDailyKwhSum) {
		this.individualMeterDailyKwhSum = individualMeterDailyKwhSum;
	}

	public Double getCo2Emission() {
		return co2Emission;
	}

	public void setCo2Emission(Double co2Emission) {
		this.co2Emission = co2Emission;
	}

	public Double getDailyIndividualMeterVryVoltageAvg() {
		return dailyIndividualMeterVryVoltageAvg;
	}

	public void setDailyIndividualMeterVryVoltageAvg(Double dailyIndividualMeterVryVoltageAvg) {
		this.dailyIndividualMeterVryVoltageAvg = dailyIndividualMeterVryVoltageAvg;
	}

	public Double getDailyIndividualMeterVybVoltageAvg() {
		return dailyIndividualMeterVybVoltageAvg;
	}

	public void setDailyIndividualMeterVybVoltageAvg(Double dailyIndividualMeterVybVoltageAvg) {
		this.dailyIndividualMeterVybVoltageAvg = dailyIndividualMeterVybVoltageAvg;
	}

	public Double getDailyIndividualMeterVbrVoltageAvg() {
		return dailyIndividualMeterVbrVoltageAvg;
	}

	public void setDailyIndividualMeterVbrVoltageAvg(Double dailyIndividualMeterVbrVoltageAvg) {
		this.dailyIndividualMeterVbrVoltageAvg = dailyIndividualMeterVbrVoltageAvg;
	}

	public Double getWattsTotal() {
		return wattsTotal;
	}

	public void setWattsTotal(Double wattsTotal) {
		this.wattsTotal = wattsTotal;
	}

	public Double getVaTotal() {
		return vaTotal;
	}

	public void setVaTotal(Double vaTotal) {
		this.vaTotal = vaTotal;
	}

	public Double getPfAvgInst() {
		return pfAvgInst;
	}

	public void setPfAvgInst(Double pfAvgInst) {
		this.pfAvgInst = pfAvgInst;
	}

	public Double getDailyIndividualMeterTotalKwAvg() {
		return dailyIndividualMeterTotalKwAvg;
	}

	public void setDailyIndividualMeterTotalKwAvg(Double dailyIndividualMeterTotalKwAvg) {
		this.dailyIndividualMeterTotalKwAvg = dailyIndividualMeterTotalKwAvg;
	}

	public Double getDailyIndividualMeterTotalKvaAvg() {
		return dailyIndividualMeterTotalKvaAvg;
	}

	public void setDailyIndividualMeterTotalKvaAvg(Double dailyIndividualMeterTotalKvaAvg) {
		this.dailyIndividualMeterTotalKvaAvg = dailyIndividualMeterTotalKvaAvg;
	}

	public Double getDailyIndividualMeterTotalPfAvg() {
		return dailyIndividualMeterTotalPfAvg;
	}

	public void setDailyIndividualMeterTotalPfAvg(Double dailyIndividualMeterTotalPfAvg) {
		this.dailyIndividualMeterTotalPfAvg = dailyIndividualMeterTotalPfAvg;
	}

	public Double getDailyIndividualMeterLineToLineVoltageAvg() {
		return dailyIndividualMeterLineToLineVoltageAvg;
	}

	public void setDailyIndividualMeterLineToLineVoltageAvg(Double dailyIndividualMeterLineToLineVoltageAvg) {
		this.dailyIndividualMeterLineToLineVoltageAvg = dailyIndividualMeterLineToLineVoltageAvg;
	}

	public Double getDailyMeterWiseCo2Sum() {
		return dailyMeterWiseCo2Sum;
	}

	public void setDailyMeterWiseCo2Sum(Double dailyMeterWiseCo2Sum) {
		this.dailyMeterWiseCo2Sum = dailyMeterWiseCo2Sum;
	}

}
