package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * A Power Tension Master Entity
 */
@Entity
@Table(name = "power_tension_master")
public class PowerTensionMaster implements Serializable {

	private static final long serialVersionUID = -8519135466243713715L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "power_tension_id")
	private Long powerTensionId;
	
	@Column(name= "power_type")
	private String powerType;
	
	@ManyToOne
	@JoinColumn(name = "discom_id")
	private DiscomMaster discomId;

	public String getPowerType() {
		return powerType;
	}

	public void setPowerType(String powerType) {
		this.powerType = powerType;
	}

	public DiscomMaster getDiscomId() {
		return discomId;
	}

	public void setDiscomId(DiscomMaster discomId) {
		this.discomId = discomId;
	}

	
}
