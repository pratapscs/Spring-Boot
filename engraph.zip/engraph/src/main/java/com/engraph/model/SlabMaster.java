package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * A Slab Master Entity
 */
@Entity
@Table(name = "slab_master")
public class SlabMaster implements Serializable {

	private static final long serialVersionUID = -6778821209469548867L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "slab_master_id")
	private Long slabMasterId;

	@Column(name = "slab")
	private String slab;

	@Column(name = "slab_kwh_limit_value")
	private Double slabKwhLimitValue;

	@Column(name = "slab_rate")
	private Double slabRate;

	@ManyToOne
	@JoinColumn(name = "usage_hour_master_id")
	private UsageHourMaster usageHourMasterId;

	public SlabMaster() {

	}

	public String getSlab() {
		return slab;
	}

	public void setSlab(String slab) {
		this.slab = slab;
	}

	public Double getSlabKwhLimitValue() {
		return slabKwhLimitValue;
	}

	public void setSlabKwhLimitValue(Double slabKwhLimitValue) {
		this.slabKwhLimitValue = slabKwhLimitValue;
	}

	public Double getSlabRate() {
		return slabRate;
	}

	public void setSlabRate(Double slabRate) {
		this.slabRate = slabRate;
	}

	public UsageHourMaster getUsageHourMasterId() {
		return usageHourMasterId;
	}

	public void setUsageHourMasterId(UsageHourMaster usageHourMasterId) {
		this.usageHourMasterId = usageHourMasterId;
	}

}
