package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * A Asset Entity
 */
@Entity
@Table(name = "asset_details")
public class Asset implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "asset_id")
	private Long assetId;

	@Column(name = "asset_name")
	private String assetName;

	@Column(name = "asset_mac_id")
	private String assetMacId;

	@Column(name = "asset_manufacturer")
	private String assetManufacturer;

	@Column(name = "asset_model_number")
	private String assetModelNumber;

	@Column(name = "asset_batch_number")
	private String assetBatchNumber;

	@ManyToOne
	@JoinColumn(name = "site_id")
	private SiteMaster siteId;

	@ManyToOne
	@JoinColumn(name = "site_building_id")
	private SiteBuilding siteBuilding;

	@ManyToOne
	@JoinColumn(name = "electricity_meter_id")
	private EletricityMeter electricityMeter;

	@ManyToOne
	@JoinColumn(name = "building_floor_id")
	private BuildingFloor buildingFloor;

	public Asset() {

	}

	public BuildingFloor getBuildingFloor() {
		return buildingFloor;
	}

	public void setBuildingFloor(BuildingFloor buildingFloor) {
		this.buildingFloor = buildingFloor;
	}

	public EletricityMeter getElectricityMeter() {
		return electricityMeter;
	}

	public void setElectricityMeter(EletricityMeter electricityMeter) {
		this.electricityMeter = electricityMeter;
	}

	public SiteBuilding getSiteBuilding() {
		return siteBuilding;
	}

	public void setSiteBuilding(SiteBuilding siteBuilding) {
		this.siteBuilding = siteBuilding;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetMacId() {
		return assetMacId;
	}

	public void setAssetMacId(String assetMacId) {
		this.assetMacId = assetMacId;
	}

	public String getAssetManufacturer() {
		return assetManufacturer;
	}

	public void setAssetManufacturer(String assetManufacturer) {
		this.assetManufacturer = assetManufacturer;
	}

	public String getAssetModelNumber() {
		return assetModelNumber;
	}

	public void setAssetModelNumber(String assetModelNumber) {
		this.assetModelNumber = assetModelNumber;
	}

	public String getAssetBatchNumber() {
		return assetBatchNumber;
	}

	public void setAssetBatchNumber(String assetBatchNumber) {
		this.assetBatchNumber = assetBatchNumber;
	}

	public SiteMaster getSiteId() {
		return siteId;
	}

	public void setSiteId(SiteMaster siteId) {
		this.siteId = siteId;
	}

}
