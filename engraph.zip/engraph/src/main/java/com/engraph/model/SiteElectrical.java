package com.engraph.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 * A Site Electrical information Entity
 */
@Entity
@Table(name = "site_electrical")
public class SiteElectrical implements Serializable {

	private static final long serialVersionUID = 917467955367620958L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "site_electrical_id")
	private Long siteElectricalId;

	@Size(max = 50)
	@Column(name = "account_id", length = 50)
	private String accountId;

	@Size(max = 50)
	@Column(name = "rr_number", length = 50)
	private String rrNumber;

	@Size(max = 50)
	@Column(name = "connection_id", length = 50)
	private String connectionId;

	@Size(max = 50)
	@Column(name = "consumer_code", length = 50)
	private String consumerCode;

	@Size(max = 30)
	@Column(name = "phase_connection", length = 30)
	private String phaseConnection;

	@Column(name = "connection_load")
	private Double connectionLoad;

	@Size(max = 10)
	@Column(name = "load_unit", length = 10)
	String loadUnit;

	@Column(name = "total_meter")
	private Integer totalMeter;

	@Column(name = "data_collection_frequency")
	Integer dataCollectionFrequency;

	@Column(name = "site_electrical_diagram")
	// byte[] siteElectricalDiagram;
	private byte[] siteElectricalDiagram;

	/*
	 * @Column(name = "file_name") String fileName;
	 */
	@Column(name = "bill_date")
	Integer billDate;

	@Column(name = "contract_demand")
	Double contractDemand;

	@Size(max = 10)
	@Column(name = "contract_demand_unit", length = 10)
	String contractDemandUnit;

	@Column(name = "contract_start_date")
	Date contractStartDate;

	@Column(name = "contract_end_date")
	Date contractEndDate;

	@OneToOne
	@JoinColumn(name = "site_id")
	SiteMaster siteMaster;

	/*
	 * public byte[] getSiteElectricalDiagram() { return siteElectricalDiagram; }
	 * 
	 * public void setSiteElectricalDiagram(byte[] siteElectricalDiagram) {
	 * this.siteElectricalDiagram = siteElectricalDiagram; }
	 */

	/*
	 * public String getFileName() { return fileName; } public void
	 * setFileName(String fileName) { this.fileName = fileName; }
	 */

	public Long getSiteElectricalId() {
		return siteElectricalId;
	}

	public byte[] getSiteElectricalDiagram() {
		return siteElectricalDiagram;
	}

	public void setSiteElectricalDiagram(byte[] siteElectricalDiagram) {
		this.siteElectricalDiagram = siteElectricalDiagram;
	}

	public void setSiteElectricalId(Long siteElectricalId) {
		this.siteElectricalId = siteElectricalId;
	}

	public SiteMaster getSiteMaster() {
		return siteMaster;
	}

	public void setSiteMaster(SiteMaster siteMaster) {
		this.siteMaster = siteMaster;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getRrNumber() {
		return rrNumber;
	}

	public void setRrNumber(String rrNumber) {
		this.rrNumber = rrNumber;
	}

	public String getConnectionId() {
		return connectionId;
	}

	public void setConnectionId(String connectionId) {
		this.connectionId = connectionId;
	}

	public String getConsumerCode() {
		return consumerCode;
	}

	public void setConsumerCode(String consumerCode) {
		this.consumerCode = consumerCode;
	}

	public String getPhaseConnection() {
		return phaseConnection;
	}

	public void setPhaseConnection(String phaseConnection) {
		this.phaseConnection = phaseConnection;
	}

	public Double getConnectionLoad() {
		return connectionLoad;
	}

	public void setConnectionLoad(Double connectionLoad) {
		this.connectionLoad = connectionLoad;
	}

	public String getLoadUnit() {
		return loadUnit;
	}

	public void setLoadUnit(String loadUnit) {
		this.loadUnit = loadUnit;
	}

	public Integer getTotalMeter() {
		return totalMeter;
	}

	public void setTotalMeter(Integer totalMeter) {
		this.totalMeter = totalMeter;
	}

	public Integer getDataCollectionFrequency() {
		return dataCollectionFrequency;
	}

	public void setDataCollectionFrequency(Integer dataCollectionFrequency) {
		this.dataCollectionFrequency = dataCollectionFrequency;
	}

	public Integer getBillDate() {
		return billDate;
	}

	public void setBillDate(Integer billDate) {
		this.billDate = billDate;
	}

	public Double getContractDemand() {
		return contractDemand;
	}

	public void setContractDemand(Double contractDemand) {
		this.contractDemand = contractDemand;
	}

	public String getContractDemandUnit() {
		return contractDemandUnit;
	}

	public void setContractDemandUnit(String contractDemandUnit) {
		this.contractDemandUnit = contractDemandUnit;
	}

	public Date getContractStartDate() {
		return contractStartDate;
	}

	public void setContractStartDate(Date contractStartDate) {
		this.contractStartDate = contractStartDate;
	}

	public Date getContractEndDate() {
		return contractEndDate;
	}

	public void setContractEndDate(Date contractEndDate) {
		this.contractEndDate = contractEndDate;
	}

}
