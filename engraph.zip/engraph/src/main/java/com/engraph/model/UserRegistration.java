package com.engraph.model;

import java.io.Serializable;
import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * A User Registration Entity
 */
@Entity
@Table(name = "Registration_Table")
public class UserRegistration implements Serializable {

	private static final long serialVersionUID = 5067324076137146622L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_registration_id")
	private Long id;

	@Size(max = 100)
	@Column(name = "user_name", length = 100)
	private String userName;

	@Size(max = 100)
	@Column(name = "first_name", length = 100)
	private String firstName;

	@Size(max = 100)
	@Column(name = "last_name", length = 100)
	private String lastName;

	@Size(max = 45)
	@Column(name = "salutation", length = 45)
	private String salutation;

	@Email
	@Size(min = 5, max = 254)
	@Column(name = "email", length = 254, unique = true)
	private String email;

	@Size(max = 250)
	@Column(name = "description", length = 250)
	private String description;

	@NotNull
	@Column(name = "activated", nullable = false)
	private boolean activated = false;

	// @JsonIgnore
	@NotNull
	@Size(min = 0, max = 100)
	@Column(name = "password_hash", length = 100, nullable = false)
	private String password;

	@Column(name = "registration_date")
	private Instant registrationDate = null;

	@Size(max = 20)
	@Column(name = "activation_key", length = 20)
	// @JsonIgnore
	private String activationKey;

	@Column(name = "deactivate_date")
	private Instant deactivateDate = null;

	@Size(max = 20)
	@Column(name = "reset_key", length = 20)
	@JsonIgnore
	private String resetKey;

	@Column(name = "reset_date")
	private Instant resetDate = null;

	private boolean isValidUser;

	private String message;

	@OneToOne
	@JoinColumn(name = "role_id")
	private RoleMaster role;

	@OneToOne
	@JoinColumn(name = "designation_id")
	private DesignationMaster designation;

	@ManyToOne
	@JoinColumn(name = "organization_id")
	private Organization orgId;

	/*
	 * 
	 * `User_Authentication_Confirmation_Bit` varchar(100) DEFAULT NULL,
	 * `User_Access_For` int(11) DEFAULT NULL, `Role_ID` int(11) NOT NULL,
	 */

	public UserRegistration() {

	}

	public Long getId() {
		return id;
	}

	public RoleMaster getRole() {
		return role;
	}

	public void setRole(RoleMaster role) {
		this.role = role;
	}

	public DesignationMaster getDesignation() {
		return designation;
	}

	public void setDesignation(DesignationMaster designation) {
		this.designation = designation;
	}

	public void setValidUser(boolean isValidUser) {
		this.isValidUser = isValidUser;
	}

	public boolean isValidUser() {
		return isValidUser;
	}

	public void setIsValidUser(boolean isValidUser) {
		this.isValidUser = isValidUser;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public Organization getOrgId() {
		return orgId;
	}

	public void setOrgId(Organization orgId) {
		this.orgId = orgId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isActivated() {
		return activated;
	}

	public void setActivated(boolean activated) {
		this.activated = activated;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Instant getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(Instant registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getActivationKey() {
		return activationKey;
	}

	public void setActivationKey(String activationKey) {
		this.activationKey = activationKey;
	}

	public Instant getDeactivateDate() {
		return deactivateDate;
	}

	public void setDeactivateDate(Instant deactivateDate) {
		this.deactivateDate = deactivateDate;
	}

	public String getResetKey() {
		return resetKey;
	}

	public void setResetKey(String resetKey) {
		this.resetKey = resetKey;
	}

	public Instant getResetDate() {
		return resetDate;
	}

	public void setResetDate(Instant resetDate) {
		this.resetDate = resetDate;
	}

}
