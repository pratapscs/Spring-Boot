
package com.engraph.model;

import java.util.List;

public class SelectAssets {

	private String assetName;

	List<ProcessAssets> processAssets;

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public List<ProcessAssets> getProcessAssets() {
		return processAssets;
	}

	public void setProcessAssets(List<ProcessAssets> processAssets) {
		this.processAssets = processAssets;
	}

}
