package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * A Site Electrical information Entity
 */
@Entity
@Table(name = "site_power_source")
public class SitePower implements Serializable {

	private static final long serialVersionUID = -647420446169712406L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "site_power_id")
	private Long sitePowerId;

	@Column(name = "is_discom")
	private Boolean isDiscom;

	@Column(name = "is_diesel_generated")
	private Boolean isDieselGenerated;

	@Column(name = "is_solar_energy")
	private Boolean isSolarEnergy;

	@Column(name = "is_wind_energy")
	private Boolean isWindEnergy;

	@Column(name = "is_biomass_energy")
	private Boolean isBiomassEnergy;

	@Column(name = "is_hydroelectrical_energy")
	private Boolean isHydroelectricalEnergy;

	@Column(name = "is_geothermal_energy")
	private Boolean isGeothermalEnergy;

	@Column(name = "is_hydrogen_energy")
	private Boolean isHydrogenEnergy;

	@Column(name = "is_tidal_energy")
	private Boolean isTidalEnergy;

	@Column(name = "is_wave_energy")
	private Boolean isWaveEnergy;

	@Column(name = "is_nuclear_energy")
	private Boolean isNuclearEnergy;

	@Column(name = "is_fuel_cell")
	private Boolean isFuelCell;

	@Column(name = "all_source_meter")
	private Boolean allSourceMeter;

	@Column(name = "non_meter_source")
	private String nonMeterSource;

	@OneToOne
	@JoinColumn(name = "site_id")
	SiteMaster siteMaster;

	public SitePower() {

	}

	public Long getSitePowerId() {
		return sitePowerId;
	}

	public void setSitePowerId(Long sitePowerId) {
		this.sitePowerId = sitePowerId;
	}

	public SiteMaster getSiteMaster() {
		return siteMaster;
	}

	public void setSiteMaster(SiteMaster siteMaster) {
		this.siteMaster = siteMaster;
	}

	public Boolean getIsDiscom() {
		return isDiscom;
	}

	public void setIsDiscom(Boolean isDiscom) {
		this.isDiscom = isDiscom;
	}

	public Boolean getIsDieselGenerated() {
		return isDieselGenerated;
	}

	public void setIsDieselGenerated(Boolean isDieselGenerated) {
		this.isDieselGenerated = isDieselGenerated;
	}

	public Boolean getIsSolarEnergy() {
		return isSolarEnergy;
	}

	public void setIsSolarEnergy(Boolean isSolarEnergy) {
		this.isSolarEnergy = isSolarEnergy;
	}

	public Boolean getIsWindEnergy() {
		return isWindEnergy;
	}

	public void setIsWindEnergy(Boolean isWindEnergy) {
		this.isWindEnergy = isWindEnergy;
	}

	public Boolean getIsBiomassEnergy() {
		return isBiomassEnergy;
	}

	public void setIsBiomassEnergy(Boolean isBiomassEnergy) {
		this.isBiomassEnergy = isBiomassEnergy;
	}

	public Boolean getIsHydroelectricalEnergy() {
		return isHydroelectricalEnergy;
	}

	public void setIsHydroelectricalEnergy(Boolean isHydroelectricalEnergy) {
		this.isHydroelectricalEnergy = isHydroelectricalEnergy;
	}

	public Boolean getIsGeothermalEnergy() {
		return isGeothermalEnergy;
	}

	public void setIsGeothermalEnergy(Boolean isGeothermalEnergy) {
		this.isGeothermalEnergy = isGeothermalEnergy;
	}

	public Boolean getIsHydrogenEnergy() {
		return isHydrogenEnergy;
	}

	public void setIsHydrogenEnergy(Boolean isHydrogenEnergy) {
		this.isHydrogenEnergy = isHydrogenEnergy;
	}

	public Boolean getIsTidalEnergy() {
		return isTidalEnergy;
	}

	public void setIsTidalEnergy(Boolean isTidalEnergy) {
		this.isTidalEnergy = isTidalEnergy;
	}

	public Boolean getIsWaveEnergy() {
		return isWaveEnergy;
	}

	public void setIsWaveEnergy(Boolean isWaveEnergy) {
		this.isWaveEnergy = isWaveEnergy;
	}

	public Boolean getIsNuclearEnergy() {
		return isNuclearEnergy;
	}

	public void setIsNuclearEnergy(Boolean isNuclearEnergy) {
		this.isNuclearEnergy = isNuclearEnergy;
	}

	public Boolean getIsFuelCell() {
		return isFuelCell;
	}

	public void setIsFuelCell(Boolean isFuelCell) {
		this.isFuelCell = isFuelCell;
	}

	public Boolean getAllSourceMeter() {
		return allSourceMeter;
	}

	public void setAllSourceMeter(Boolean allSourceMeter) {
		this.allSourceMeter = allSourceMeter;
	}

	public String getNonMeterSource() {
		return nonMeterSource;
	}

	public void setNonMeterSource(String nonMeterSource) {
		this.nonMeterSource = nonMeterSource;
	}

}
