package com.engraph.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 * A Site Building Entity
 */
@Entity
@Table(name = "site_building")
public class SiteBuilding implements Serializable {

	private static final long serialVersionUID = 8859134402250418591L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "site_building_id")
	private Long siteBuildingId;

	@Column(name = "building_number")
	private String buildingNumber;

	@Size(max = 50)
	@Column(name = "building_name", length = 50)
	private String buildingName;

	@Column(name = "building_buildup_area")
	private Double buildingBuildupArea;

	@Column(name = "building_terrace_area")
	private Double buildingTerraceArea;

	@Column(name = "building_total_meters")
	private Double buildingTotalMeters;

	@Column(name = "building_total_floors")
	private Integer buildingTotalFloors;

	@Column(name = "building_electrical_diagram")
	private String buildingElectricalDiagram;

	@ManyToOne
	@JoinColumn(name = "site_id")
	private SiteMaster siteId;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "site_building_id")
	private List<BuildingFloor> floors;

	public List<BuildingFloor> getFloors() {
		return floors;
	}

	public void setFloors(List<BuildingFloor> floors) {
		this.floors = floors;
	}

	public Long getSiteBuildingId() {
		return siteBuildingId;
	}

	public void setSiteBuildingId(Long siteBuildingId) {
		this.siteBuildingId = siteBuildingId;
	}

	public String getBuildingNumber() {
		return buildingNumber;
	}

	public void setBuildingNumber(String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public Double getBuildingBuildupArea() {
		return buildingBuildupArea;
	}

	public void setBuildingBuildupArea(Double buildingBuildupArea) {
		this.buildingBuildupArea = buildingBuildupArea;
	}

	public Double getBuildingTerraceArea() {
		return buildingTerraceArea;
	}

	public void setBuildingTerraceArea(Double buildingTerraceArea) {
		this.buildingTerraceArea = buildingTerraceArea;
	}

	public Double getBuildingTotalMeters() {
		return buildingTotalMeters;
	}

	public void setBuildingTotalMeters(Double buildingTotalMeters) {
		this.buildingTotalMeters = buildingTotalMeters;
	}

	public Integer getBuildingTotalFloors() {
		return buildingTotalFloors;
	}

	public void setBuildingTotalFloors(Integer buildingTotalFloors) {
		this.buildingTotalFloors = buildingTotalFloors;
	}

	public String getBuildingElectricalDiagram() {
		return buildingElectricalDiagram;
	}

	public void setBuildingElectricalDiagram(String buildingElectricalDiagram) {
		this.buildingElectricalDiagram = buildingElectricalDiagram;
	}

	public SiteMaster getSiteId() {
		return siteId;
	}

	public void setSiteId(SiteMaster siteId) {
		this.siteId = siteId;
	}

}
