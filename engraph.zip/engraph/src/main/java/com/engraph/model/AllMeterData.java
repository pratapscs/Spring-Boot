package com.engraph.model;

import com.fasterxml.jackson.annotation.JsonFilter;

/**
 * A AllMeterData Entity For Phoenix
 */
@JsonFilter("allMeterData")
public class AllMeterData {

	private String uniqueId;

	// CLIENT_INFORMATION
	private String siteId;// SITE_ID
	private String siteName;// SITE_NAME

	// TIMESTAMP
	private String normalTimestamp;// TIMESTAMP.NORMAL_TIMESTAMP
	private String date;// TIMESTAMP.DATE
	private String hDate; // TIMESTAMP.HDATE
	private String time;// TIMESTAMP.TIME
	private String week; // TIMESTAMP.WEEK
	private String weekDay; // TIMESTAMP.WEEKDAY
	private String weekDate;
	private String month;// TIMESTAMP.MONTH
	private String monthName;
	private String monthDate;
	private String year;// TIMESTAMP.YEAR

	// ALL_METER_CALCULATED_DATA
	private Double allMeterKwh;
	private Double allMeterKwhSum;// ALL_METER_KWH_SUM
	private Double allMeterKvahSum;// ALL_Meter_KVAH_SUM
	private Double allMeterTotalKwAvg;// ALL_METER_TOTAL_KW_AVG
	private Double allMeterRPhaseKwAvg;// ALL_METER_R_PHASE_KW_AVG
	private Double allMeterYPhaseKwAvg;// ALL_METER_Y_PHASE_KW_AVG
	private Double allMeterBPhaseKwAvg;// ALL_METER_B_PHASE_KW_AVG
	private Double allMeterPfInstAvg;// ALL_METER_PF_INST_AVG
	private Double allMeterPfRPhase;// ALL_METER_PF_R_PHASE
	private Double allMeterPfYPhase;// ALL_METER_PF_Y_PHASE
	private Double allMeterPfBPhase;// ALL_METER_PF_B_PHASE
	private Double allMeterKvaAvg;// ALL_METER_KVA_AVG
	private Double allMeterRPhaseKvaAvg;// ALL_METER_R_PHASE_KVA_AVG
	private Double allMeterYPhaseKvaAvg;// ALL_METER_Y_PHASE_KVA_AVG
	private Double allMeterBPhaseKvaAvg;// ALL_METER_B_PHASE_KVA_AVG
	private Double allMeterVllAvg;// ALL_METER_VLL_AVG
	private Double allMeterVryPhaseAvg;// ALL_METER_VRY_PHASE_AVG
	private Double allMeterVybPhaseAvg;// ALL_METER_VYB_PHASE_AVG
	private Double allMeterVbrPhaseAvg;// ALL_METER_VBR_PHASE_AVG
	private Double allMeterCarbonEmissionSum;// ALL_METER_CARBON_EMISSION_SUM
	private Double dailyAllMeterKwhSum;// DAILY_ALL_METER_KWH_SUM
	private Double monthlyKwh;
	private Double dailyAllMeterTotalKwAvg;// DAILY_ALL_METER_TOTAL_KW_AVG
	private Double dailyAllMeterRPhaseKwAvg;// DAILY_ALL_METER_R_PHASE_KW_AVG
	private Double dailyAllMeterYPhaseKwAvg;// DAILY_ALL_METER_Y_PHASE_KW_AVG
	private Double dailyAllMeterBPhaseKwAvg;// DAILY_ALL_METER_B_PHASE_KW_AVG
	private Double dailyAllMeterTotalKvaAvg;// DAILY_ALL_METER_TOTAL_KVA_AVG
	private Double dailyAllMeterRPhaseKvaAvg;// DAILY_ALL_METER_R_PHASE_KVA_AVG
	private Double dailyAllMeterYPhaseKvaAvg;// DAILY_ALL_METER_Y_PHASE_KVA_AVG
	private Double dailyAllMeterBPhaseKvaAvg;// DAILY_ALL_METER_B_PHASE_KVA_AVG
	private Double dailyAllMeterTotalPfAvg;// DAILY_ALL_METER_TOTAL_PF_AVG
	private Double dailyAllMeterRPhasePfAvg;// DAILY_ALL_METER_R_PHASE_PF_AVG
	private Double dailyAllMeterYPhasePfAvg;// DAILY_ALL_METER_Y_PHASE_PF_AVG
	private Double dailyAllMeterBPhasePfAvg;// DAILY_ALL_METER_B_PHASE_PF_AVG
	private Double dailyAllMeterTotalLLVoltageAvg;// DAILY_ALL_METER_TOTAL_LL_VOLTAGE_AVG
	private Double dailyAllMeterTotalVRYPhaseVoltageAvg;// DAILY_ALL_METER_VRY_PHASE_VOLTAGE_AVG
	private Double dailyAllMeterTotalVYBPhaseVoltageAvg;// DAILY_ALL_METER_VYB_PHASE_VOLTAGE_AVG
	private Double dailyAllMeterTotalVBRPhaseVoltageAvg;// DAILY_ALL_METER_VBR_PHASE_VOLTAGE_AVG
	private Double allMeterDailyCarbonEmissionCumulativeValue;// ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE

	public AllMeterData() {

	}

	public String gethDate() {
		return hDate;
	}

	public void sethDate(String hDate) {
		this.hDate = hDate;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getNormalTimestamp() {
		return normalTimestamp;
	}

	public void setNormalTimestamp(String normalTimestamp) {
		this.normalTimestamp = normalTimestamp;
	}

	public Double getMonthlyKwh() {
		return monthlyKwh;
	}

	public void setMonthlyKwh(Double monthlyKwh) {
		this.monthlyKwh = monthlyKwh;
	}

	public String getMonthName() {
		return monthName;
	}

	public void setMonthName(String monthName) {
		this.monthName = monthName;
	}

	public String getMonthDate() {
		return monthDate;
	}

	public void setMonthDate(String monthDate) {
		this.monthDate = monthDate;
	}

	public String getWeekDate() {
		return weekDate;
	}

	public void setWeekDate(String weekDate) {
		this.weekDate = weekDate;
	}

	public Double getAllMeterKwh() {
		return allMeterKwh;
	}

	public void setAllMeterKwh(Double allMeterKwh) {
		this.allMeterKwh = allMeterKwh;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getWeek() {
		return week;
	}

	public void setWeek(String week) {
		this.week = week;
	}

	public String getWeekDay() {
		return weekDay;
	}

	public void setWeekDay(String weekDay) {
		this.weekDay = weekDay;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public Double getAllMeterKwhSum() {
		return allMeterKwhSum;
	}

	public void setAllMeterKwhSum(Double allMeterKwhSum) {
		this.allMeterKwhSum = allMeterKwhSum;
	}

	public Double getAllMeterKvahSum() {
		return allMeterKvahSum;
	}

	public void setAllMeterKvahSum(Double allMeterKvahSum) {
		this.allMeterKvahSum = allMeterKvahSum;
	}

	public Double getAllMeterTotalKwAvg() {
		return allMeterTotalKwAvg;
	}

	public void setAllMeterTotalKwAvg(Double allMeterTotalKwAvg) {
		this.allMeterTotalKwAvg = allMeterTotalKwAvg;
	}

	public Double getAllMeterRPhaseKwAvg() {
		return allMeterRPhaseKwAvg;
	}

	public void setAllMeterRPhaseKwAvg(Double allMeterRPhaseKwAvg) {
		this.allMeterRPhaseKwAvg = allMeterRPhaseKwAvg;
	}

	public Double getAllMeterYPhaseKwAvg() {
		return allMeterYPhaseKwAvg;
	}

	public void setAllMeterYPhaseKwAvg(Double allMeterYPhaseKwAvg) {
		this.allMeterYPhaseKwAvg = allMeterYPhaseKwAvg;
	}

	public Double getAllMeterBPhaseKwAvg() {
		return allMeterBPhaseKwAvg;
	}

	public void setAllMeterBPhaseKwAvg(Double allMeterBPhaseKwAvg) {
		this.allMeterBPhaseKwAvg = allMeterBPhaseKwAvg;
	}

	public Double getAllMeterPfInstAvg() {
		return allMeterPfInstAvg;
	}

	public void setAllMeterPfInstAvg(Double allMeterPfInstAvg) {
		this.allMeterPfInstAvg = allMeterPfInstAvg;
	}

	public Double getAllMeterPfRPhase() {
		return allMeterPfRPhase;
	}

	public void setAllMeterPfRPhase(Double allMeterPfRPhase) {
		this.allMeterPfRPhase = allMeterPfRPhase;
	}

	public Double getAllMeterPfYPhase() {
		return allMeterPfYPhase;
	}

	public void setAllMeterPfYPhase(Double allMeterPfYPhase) {
		this.allMeterPfYPhase = allMeterPfYPhase;
	}

	public Double getAllMeterPfBPhase() {
		return allMeterPfBPhase;
	}

	public void setAllMeterPfBPhase(Double allMeterPfBPhase) {
		this.allMeterPfBPhase = allMeterPfBPhase;
	}

	public Double getAllMeterKvaAvg() {
		return allMeterKvaAvg;
	}

	public void setAllMeterKvaAvg(Double allMeterKvaAvg) {
		this.allMeterKvaAvg = allMeterKvaAvg;
	}

	public Double getAllMeterRPhaseKvaAvg() {
		return allMeterRPhaseKvaAvg;
	}

	public void setAllMeterRPhaseKvaAvg(Double allMeterRPhaseKvaAvg) {
		this.allMeterRPhaseKvaAvg = allMeterRPhaseKvaAvg;
	}

	public Double getAllMeterYPhaseKvaAvg() {
		return allMeterYPhaseKvaAvg;
	}

	public void setAllMeterYPhaseKvaAvg(Double allMeterYPhaseKvaAvg) {
		this.allMeterYPhaseKvaAvg = allMeterYPhaseKvaAvg;
	}

	public Double getAllMeterBPhaseKvaAvg() {
		return allMeterBPhaseKvaAvg;
	}

	public void setAllMeterBPhaseKvaAvg(Double allMeterBPhaseKvaAvg) {
		this.allMeterBPhaseKvaAvg = allMeterBPhaseKvaAvg;
	}

	public Double getAllMeterVllAvg() {
		return allMeterVllAvg;
	}

	public void setAllMeterVllAvg(Double allMeterVllAvg) {
		this.allMeterVllAvg = allMeterVllAvg;
	}

	public Double getAllMeterVryPhaseAvg() {
		return allMeterVryPhaseAvg;
	}

	public void setAllMeterVryPhaseAvg(Double allMeterVryPhaseAvg) {
		this.allMeterVryPhaseAvg = allMeterVryPhaseAvg;
	}

	public Double getAllMeterVybPhaseAvg() {
		return allMeterVybPhaseAvg;
	}

	public void setAllMeterVybPhaseAvg(Double allMeterVybPhaseAvg) {
		this.allMeterVybPhaseAvg = allMeterVybPhaseAvg;
	}

	public Double getAllMeterVbrPhaseAvg() {
		return allMeterVbrPhaseAvg;
	}

	public void setAllMeterVbrPhaseAvg(Double allMeterVbrPhaseAvg) {
		this.allMeterVbrPhaseAvg = allMeterVbrPhaseAvg;
	}

	public Double getAllMeterCarbonEmissionSum() {
		return allMeterCarbonEmissionSum;
	}

	public void setAllMeterCarbonEmissionSum(Double allMeterCarbonEmissionSum) {
		this.allMeterCarbonEmissionSum = allMeterCarbonEmissionSum;
	}

	public Double getDailyAllMeterKwhSum() {
		return dailyAllMeterKwhSum;
	}

	public void setDailyAllMeterKwhSum(Double dailyAllMeterKwhSum) {
		this.dailyAllMeterKwhSum = dailyAllMeterKwhSum;
	}

	public Double getDailyAllMeterTotalKwAvg() {
		return dailyAllMeterTotalKwAvg;
	}

	public void setDailyAllMeterTotalKwAvg(Double dailyAllMeterTotalKwAvg) {
		this.dailyAllMeterTotalKwAvg = dailyAllMeterTotalKwAvg;
	}

	public Double getDailyAllMeterRPhaseKwAvg() {
		return dailyAllMeterRPhaseKwAvg;
	}

	public void setDailyAllMeterRPhaseKwAvg(Double dailyAllMeterRPhaseKwAvg) {
		this.dailyAllMeterRPhaseKwAvg = dailyAllMeterRPhaseKwAvg;
	}

	public Double getDailyAllMeterYPhaseKwAvg() {
		return dailyAllMeterYPhaseKwAvg;
	}

	public void setDailyAllMeterYPhaseKwAvg(Double dailyAllMeterYPhaseKwAvg) {
		this.dailyAllMeterYPhaseKwAvg = dailyAllMeterYPhaseKwAvg;
	}

	public Double getDailyAllMeterBPhaseKwAvg() {
		return dailyAllMeterBPhaseKwAvg;
	}

	public void setDailyAllMeterBPhaseKwAvg(Double dailyAllMeterBPhaseKwAvg) {
		this.dailyAllMeterBPhaseKwAvg = dailyAllMeterBPhaseKwAvg;
	}

	public Double getDailyAllMeterTotalKvaAvg() {
		return dailyAllMeterTotalKvaAvg;
	}

	public void setDailyAllMeterTotalKvaAvg(Double dailyAllMeterTotalKvaAvg) {
		this.dailyAllMeterTotalKvaAvg = dailyAllMeterTotalKvaAvg;
	}

	public Double getDailyAllMeterRPhaseKvaAvg() {
		return dailyAllMeterRPhaseKvaAvg;
	}

	public void setDailyAllMeterRPhaseKvaAvg(Double dailyAllMeterRPhaseKvaAvg) {
		this.dailyAllMeterRPhaseKvaAvg = dailyAllMeterRPhaseKvaAvg;
	}

	public Double getDailyAllMeterYPhaseKvaAvg() {
		return dailyAllMeterYPhaseKvaAvg;
	}

	public void setDailyAllMeterYPhaseKvaAvg(Double dailyAllMeterYPhaseKvaAvg) {
		this.dailyAllMeterYPhaseKvaAvg = dailyAllMeterYPhaseKvaAvg;
	}

	public Double getDailyAllMeterBPhaseKvaAvg() {
		return dailyAllMeterBPhaseKvaAvg;
	}

	public void setDailyAllMeterBPhaseKvaAvg(Double dailyAllMeterBPhaseKvaAvg) {
		this.dailyAllMeterBPhaseKvaAvg = dailyAllMeterBPhaseKvaAvg;
	}

	public Double getDailyAllMeterTotalPfAvg() {
		return dailyAllMeterTotalPfAvg;
	}

	public void setDailyAllMeterTotalPfAvg(Double dailyAllMeterTotalPfAvg) {
		this.dailyAllMeterTotalPfAvg = dailyAllMeterTotalPfAvg;
	}

	public Double getDailyAllMeterRPhasePfAvg() {
		return dailyAllMeterRPhasePfAvg;
	}

	public void setDailyAllMeterRPhasePfAvg(Double dailyAllMeterRPhasePfAvg) {
		this.dailyAllMeterRPhasePfAvg = dailyAllMeterRPhasePfAvg;
	}

	public Double getDailyAllMeterYPhasePfAvg() {
		return dailyAllMeterYPhasePfAvg;
	}

	public void setDailyAllMeterYPhasePfAvg(Double dailyAllMeterYPhasePfAvg) {
		this.dailyAllMeterYPhasePfAvg = dailyAllMeterYPhasePfAvg;
	}

	public Double getDailyAllMeterBPhasePfAvg() {
		return dailyAllMeterBPhasePfAvg;
	}

	public void setDailyAllMeterBPhasePfAvg(Double dailyAllMeterBPhasePfAvg) {
		this.dailyAllMeterBPhasePfAvg = dailyAllMeterBPhasePfAvg;
	}

	public Double getDailyAllMeterTotalLLVoltageAvg() {
		return dailyAllMeterTotalLLVoltageAvg;
	}

	public void setDailyAllMeterTotalLLVoltageAvg(Double dailyAllMeterTotalLLVoltageAvg) {
		this.dailyAllMeterTotalLLVoltageAvg = dailyAllMeterTotalLLVoltageAvg;
	}

	public Double getDailyAllMeterTotalVRYPhaseVoltageAvg() {
		return dailyAllMeterTotalVRYPhaseVoltageAvg;
	}

	public void setDailyAllMeterTotalVRYPhaseVoltageAvg(Double dailyAllMeterTotalVRYPhaseVoltageAvg) {
		this.dailyAllMeterTotalVRYPhaseVoltageAvg = dailyAllMeterTotalVRYPhaseVoltageAvg;
	}

	public Double getDailyAllMeterTotalVYBPhaseVoltageAvg() {
		return dailyAllMeterTotalVYBPhaseVoltageAvg;
	}

	public void setDailyAllMeterTotalVYBPhaseVoltageAvg(Double dailyAllMeterTotalVYBPhaseVoltageAvg) {
		this.dailyAllMeterTotalVYBPhaseVoltageAvg = dailyAllMeterTotalVYBPhaseVoltageAvg;
	}

	public Double getDailyAllMeterTotalVBRPhaseVoltageAvg() {
		return dailyAllMeterTotalVBRPhaseVoltageAvg;
	}

	public void setDailyAllMeterTotalVBRPhaseVoltageAvg(Double dailyAllMeterTotalVBRPhaseVoltageAvg) {
		this.dailyAllMeterTotalVBRPhaseVoltageAvg = dailyAllMeterTotalVBRPhaseVoltageAvg;
	}

	public Double getAllMeterDailyCarbonEmissionCumulativeValue() {
		return allMeterDailyCarbonEmissionCumulativeValue;
	}

	public void setAllMeterDailyCarbonEmissionCumulativeValue(Double allMeterDailyCarbonEmissionCumulativeValue) {
		this.allMeterDailyCarbonEmissionCumulativeValue = allMeterDailyCarbonEmissionCumulativeValue;
	}

}
