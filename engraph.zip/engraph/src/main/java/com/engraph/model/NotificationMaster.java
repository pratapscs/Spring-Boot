package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * A NotificationMaster Entity
 */
@Entity
@Table(name = "notification_master")
public class NotificationMaster implements Serializable{

	private static final long serialVersionUID = -7943169429876302477L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "notification_id")
	private Long notificationId;

	@Column(name = "parameterType")
	private String parameterType;

	@Column(name = "higherLimit")
	private Integer highestLimit;

	@Column(name = "lowerLimit")
	private Integer lowerLimit;

	@ManyToOne
	@JoinColumn(name = "siteId")
	private SiteMaster siteId;

	public NotificationMaster() {

	}

	public Long getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(Long notificationId) {
		this.notificationId = notificationId;
	}

	public String getParameterType() {
		return parameterType;
	}

	public void setParameterType(String parameterType) {
		this.parameterType = parameterType;
	}

	public Integer getHighestLimit() {
		return highestLimit;
	}

	public void setHighestLimit(Integer highestLimit) {
		this.highestLimit = highestLimit;
	}

	public Integer getLowerLimit() {
		return lowerLimit;
	}

	public void setLowerLimit(Integer lowerLimit) {
		this.lowerLimit = lowerLimit;
	}

	public SiteMaster getSiteId() {
		return siteId;
	}

	public void setSiteId(SiteMaster siteId) {
		this.siteId = siteId;
	}

}
