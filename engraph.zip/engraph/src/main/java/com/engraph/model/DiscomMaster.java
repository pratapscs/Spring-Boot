package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * A Discom Master Entity
 */
@Entity
@Table(name = "discom_master")
public class DiscomMaster implements Serializable {

	private static final long serialVersionUID = 3909530418651075992L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "discom_id")
	private Long discomId;

	@Column(name = "discom_name")
	private String discomName;

	@ManyToOne
	@JoinColumn(name = "location_id")
	private LocationMaster locationId;

	public DiscomMaster() {

	}

	public Long getDiscomId() {
		return discomId;
	}

	public void setDiscomId(Long discomId) {
		this.discomId = discomId;
	}

	public String getDiscomName() {
		return discomName;
	}

	public void setDiscomName(String discomName) {
		this.discomName = discomName;
	}

	public LocationMaster getLocationId() {
		return locationId;
	}

	public void setLocationId(LocationMaster locationId) {
		this.locationId = locationId;
	}

}
