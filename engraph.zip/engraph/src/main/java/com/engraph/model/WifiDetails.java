package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "wifi_details")
public class WifiDetails implements Serializable{
	
	private static final long serialVersionUID = -6191481927049024460L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "wifi_id")
	private long wifiId;

	@Column(name = "wifi_name")
	private String wifiName;

	@Column(name = "wifi_password")
	private String wifiPassword;
	
	@ManyToOne
	@JoinColumn(name = "siteId")
	private SiteMaster siteId;
	
	public WifiDetails() {
		
	}
	
	public long getWifiId() {
		return wifiId;
	}

	public void setWifiId(long wifiId) {
		this.wifiId = wifiId;
	}

	public String getWifiName() {
		return wifiName;
	}

	public void setWifiName(String wifiName) {
		this.wifiName = wifiName;
	}

	public String getWifiPassword() {
		return wifiPassword;
	}

	public void setWifiPassword(String wifiPassword) {
		this.wifiPassword = wifiPassword;
	}

	public SiteMaster getSiteId() {
		return siteId;
	}

	public void setSiteId(SiteMaster siteId) {
		this.siteId = siteId;
	}

}
