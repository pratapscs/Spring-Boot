package com.engraph.model;

/**
 * A ProcessedData Entity For Phoenix
 */
//@JsonFilter("processedData")
public class ProcessedData {

	private String uniqueId;

	// TIMESTAMP
	private String unixTimeStamp;// UNIX_TIMESTAMP
	private String timestamp;// NORMAL_TIMESTAMP
	private String date;// DATE
	private String hDate;
	private String weekDay;// WEEKDAY
	private String weekDate;
	private String timeSecond;// TIME_SECOND
	private String time;// TIME
	private String timeMillisecond;// TIME_MILLISECOND
	private String day;// DAY
	private String month;// MONTH
	private String monthDate;
	private String year;// YEAR
	private String hour;// HOUR
	private String minute;// MINUTE
	private String second;// SECOND
	private String milliSecond;// MILLISECOND
	private String week;// WEEK

	// CALCULATED_PARAMETER_FAMILY
	private double whReceivedActiveEnergy;// WH_RECEIVED_ACTIVE_ENERGY
	private double whDelivered;// WH_DELIVERED
	private double pfRPhase;// PF_R_PHASE
	private double pfYPhase;// PF_Y_PHASE
	private double pfBPhase;// PF_B_PHASE
	private double pfAvgInst;// PF_AVG_INST
	private double VllAverage;// VLL_AVERAGE
	private double VlnAverage;// VLN_AVERAGE
	private double vryphase;// VRY_PHASE
	private double vybphase;// VYB_PHASE
	private double vbrphase;// VBR_PHASE
	private double vrPhase;// V_R_PHASE
	private double vyPhase;// V_Y_PHASE
	private double vbPhase;// V_B_PHASE
	private double vaTotal;// VA_TOTAL
	private double varPhase;// VA_R_PHASE
	private double vayPhase;// VA_Y_PHASE
	private double vabPhase;// VA_B_PHASE
	private double wattsTotal;// WATTS_TOTAL
	private double wattsRPhase;// WATTS_R_PHASE
	private double wattsYPhase;// WATTS_Y_PHASE
	private double wattsBPhase;// WATTS_B_PHASE
	private double kwh;// KWH
	private double kvah;// KVAH

	// CLIENT_INFORMATION
	private String organizationId;// ORGANIZATION_ID
	private String organizationName;// ORGANIZATION_NAME
	private String siteId;// SITE_ID
	private String siteName;// SITE_NAME
	private String siteBuildingId; // SITE_BUILDING_ID
	private String buildingName;// BUILDING_NAME
	private String buildingFloorId;// BUILDING_FLOOR_ID
	private String floorNumber;// FLOOR_NUMBER
	private String floorName;// FLOOR_NAME
	private String electricityMeterId;// ELECTRICITY_METER_ID
	private String meterName;// METER_NAME
	private String smartMeterMacNumber;// SMART_METER_MAC_NUMBER
	private String meterSlaveId;// METER_SLAVE_ID
	private String assetId; // ASSET_ID
	private String assetName;// ASSET_NAME
	private String co2Year;// CO2_YEAR
	private String co2EmissionFactors;// CO2_EMISSION_FACTORS

	// CALCULATED_PARAMETER_FAMILY
	private double exactKwh;// EXACT_KWH
	private double highestKwh;
	private double individualMeterDailyKwhSum;// INDIVIDUAL_METER_DAILY_KWH_SUM
	private double dailyIndividualMeterTotalKwAvg;// DAILY_INDIVIDUAL_METER_TOTAL_KW_AVG
	private double dailyIndividualMeterPhaseRKwAvg;// DAILY_INDIVIDUAL_METER_PHASE_R_KW_AVG
	private double dailyIndividualMeterPhaseYKwAvg;// DAILY_INDIVIDUAL_METER_PHASE_Y_KW_AVG
	private double dailyIndividualMeterPhaseBKwAvg;// DAILY_INDIVIDUAL_METER_PHASE_B_KW_AVG
	private double dailyIndividualMeterTotalPfAvg;// DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG
	private double dailyIndividualMeterRPfAvg;// DAILY_INDIVIDUAL_METER_R_PF_AVG
	private double dailyIndividualMeterYPfAvg;// DAILY_INDIVIDUAL_METER_Y_PF_AVG
	private double dailyIndividualMeterBPfAvg;// DAILY_INDIVIDUAL_METER_B_PF_AVG
	private double dailyIndividualMeterTotalKvaAvg;// DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG
	private double dailyIndividualMeterPhaseRKvaAvg;// DAILY_INDIVIDUAL_METER_PHASE_R_KVA_AVG
	private double dailyIndividualMeterPhaseYKvaAvg;// DAILY_INDIVIDUAL_METER_PHASE_Y_KVA_AVG
	private double dailyIndividualMeterPhaseBKvaAvg;// DAILY_INDIVIDUAL_METER_PHASE_B_KVA_AVG
	private double dailyIndividualMeterLineToLineVoltageAvg;// DAILY_INDIVIDUAL_METER_LINE_TO_LINE_VOLTAGE_AVG
	private double dailyIndividualMeterVryVoltageAvg;// DAILY_INDIVIDUAL_METER_VRY_VOLTAGE_AVG
	private double dailyIndividualMeterVybVoltageAvg;// DAILY_INDIVIDUAL_METER_VYB_VOLTAGE_AVG
	private double dailyIndividualMeterVbrVoltageAvg;// DAILY_INDIVIDUAL_METER_VBR_VOLTAGE_AVG
	private double mwh;// MWH
	private double co2Emission;// CARBON_EMISSION
	private double dailyMeterWiseCo2Sum;// DAILY_METER_WISE_CARBON_EMISSION_SUM

	public ProcessedData() {

	}
	
	public String gethDate() {
		return hDate;
	}

	public void sethDate(String hDate) {
		this.hDate = hDate;
	}

	public String getSiteBuildingId() {
		return siteBuildingId;
	}

	public void setSiteBuildingId(String siteBuildingId) {
		this.siteBuildingId = siteBuildingId;
	}

	public String getBuildingFloorId() {
		return buildingFloorId;
	}

	public void setBuildingFloorId(String buildingFloorId) {
		this.buildingFloorId = buildingFloorId;
	}

	public String getElectricityMeterId() {
		return electricityMeterId;
	}

	public void setElectricityMeterId(String electricityMeterId) {
		this.electricityMeterId = electricityMeterId;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public double getHighestKwh() {
		return highestKwh;
	}

	public void setHighestKwh(double highestKwh) {
		this.highestKwh = highestKwh;
	}

	public String getMonthDate() {
		return monthDate;
	}

	public void setMonthDate(String monthDate) {
		this.monthDate = monthDate;
	}

	public String getWeekDate() {
		return weekDate;
	}

	public void setWeekDate(String weekDate) {
		this.weekDate = weekDate;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getUnixTimeStamp() {
		return unixTimeStamp;
	}

	public void setUnixTimeStamp(String unixTimeStamp) {
		this.unixTimeStamp = unixTimeStamp;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getWeekDay() {
		return weekDay;
	}

	public void setWeekDay(String weekDay) {
		this.weekDay = weekDay;
	}

	public String getTimeSecond() {
		return timeSecond;
	}

	public void setTimeSecond(String timeSecond) {
		this.timeSecond = timeSecond;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getTimeMillisecond() {
		return timeMillisecond;
	}

	public void setTimeMillisecond(String timeMillisecond) {
		this.timeMillisecond = timeMillisecond;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getHour() {
		return hour;
	}

	public void setHour(String hour) {
		this.hour = hour;
	}

	public String getMinute() {
		return minute;
	}

	public void setMinute(String minute) {
		this.minute = minute;
	}

	public String getSecond() {
		return second;
	}

	public void setSecond(String second) {
		this.second = second;
	}

	public String getMilliSecond() {
		return milliSecond;
	}

	public void setMilliSecond(String milliSecond) {
		this.milliSecond = milliSecond;
	}

	public String getWeek() {
		return week;
	}

	public void setWeek(String week) {
		this.week = week;
	}

	public double getWhReceivedActiveEnergy() {
		return whReceivedActiveEnergy;
	}

	public void setWhReceivedActiveEnergy(double whReceivedActiveEnergy) {
		this.whReceivedActiveEnergy = whReceivedActiveEnergy;
	}

	public double getWhDelivered() {
		return whDelivered;
	}

	public void setWhDelivered(double whDelivered) {
		this.whDelivered = whDelivered;
	}

	public double getPfRPhase() {
		return pfRPhase;
	}

	public void setPfRPhase(double pfRPhase) {
		this.pfRPhase = pfRPhase;
	}

	public double getPfYPhase() {
		return pfYPhase;
	}

	public void setPfYPhase(double pfYPhase) {
		this.pfYPhase = pfYPhase;
	}

	public double getPfBPhase() {
		return pfBPhase;
	}

	public void setPfBPhase(double pfBPhase) {
		this.pfBPhase = pfBPhase;
	}

	public double getPfAvgInst() {
		return pfAvgInst;
	}

	public void setPfAvgInst(double pfAvgInst) {
		this.pfAvgInst = pfAvgInst;
	}

	public double getVllAverage() {
		return VllAverage;
	}

	public void setVllAverage(double vllAverage) {
		VllAverage = vllAverage;
	}

	public double getVlnAverage() {
		return VlnAverage;
	}

	public void setVlnAverage(double vlnAverage) {
		VlnAverage = vlnAverage;
	}

	public double getVryphase() {
		return vryphase;
	}

	public void setVryphase(double vryphase) {
		this.vryphase = vryphase;
	}

	public double getVybphase() {
		return vybphase;
	}

	public void setVybphase(double vybphase) {
		this.vybphase = vybphase;
	}

	public double getVbrphase() {
		return vbrphase;
	}

	public void setVbrphase(double vbrphase) {
		this.vbrphase = vbrphase;
	}

	public double getVrPhase() {
		return vrPhase;
	}

	public void setVrPhase(double vrPhase) {
		this.vrPhase = vrPhase;
	}

	public double getVyPhase() {
		return vyPhase;
	}

	public void setVyPhase(double vyPhase) {
		this.vyPhase = vyPhase;
	}

	public double getVbPhase() {
		return vbPhase;
	}

	public void setVbPhase(double vbPhase) {
		this.vbPhase = vbPhase;
	}

	public double getVaTotal() {
		return vaTotal;
	}

	public void setVaTotal(double vaTotal) {
		this.vaTotal = vaTotal;
	}

	public double getVarPhase() {
		return varPhase;
	}

	public void setVarPhase(double varPhase) {
		this.varPhase = varPhase;
	}

	public double getVayPhase() {
		return vayPhase;
	}

	public void setVayPhase(double vayPhase) {
		this.vayPhase = vayPhase;
	}

	public double getVabPhase() {
		return vabPhase;
	}

	public void setVabPhase(double vabPhase) {
		this.vabPhase = vabPhase;
	}

	public double getWattsTotal() {
		return wattsTotal;
	}

	public void setWattsTotal(double wattsTotal) {
		this.wattsTotal = wattsTotal;
	}

	public double getWattsRPhase() {
		return wattsRPhase;
	}

	public void setWattsRPhase(double wattsRPhase) {
		this.wattsRPhase = wattsRPhase;
	}

	public double getWattsYPhase() {
		return wattsYPhase;
	}

	public void setWattsYPhase(double wattsYPhase) {
		this.wattsYPhase = wattsYPhase;
	}

	public double getWattsBPhase() {
		return wattsBPhase;
	}

	public void setWattsBPhase(double wattsBPhase) {
		this.wattsBPhase = wattsBPhase;
	}

	public double getKwh() {
		return kwh;
	}

	public void setKwh(double kwh) {
		this.kwh = kwh;
	}

	public double getKvah() {
		return kvah;
	}

	public void setKvah(double kvah) {
		this.kvah = kvah;
	}

	public String getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getFloorNumber() {
		return floorNumber;
	}

	public void setFloorNumber(String floorNumber) {
		this.floorNumber = floorNumber;
	}

	public String getFloorName() {
		return floorName;
	}

	public void setFloorName(String floorName) {
		this.floorName = floorName;
	}

	public String getMeterName() {
		return meterName;
	}

	public void setMeterName(String meterName) {
		this.meterName = meterName;
	}

	public String getSmartMeterMacNumber() {
		return smartMeterMacNumber;
	}

	public void setSmartMeterMacNumber(String smartMeterMacNumber) {
		this.smartMeterMacNumber = smartMeterMacNumber;
	}

	public String getMeterSlaveId() {
		return meterSlaveId;
	}

	public void setMeterSlaveId(String meterSlaveId) {
		this.meterSlaveId = meterSlaveId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getCo2Year() {
		return co2Year;
	}

	public void setCo2Year(String co2Year) {
		this.co2Year = co2Year;
	}

	public String getCo2EmissionFactors() {
		return co2EmissionFactors;
	}

	public void setCo2EmissionFactors(String co2EmissionFactors) {
		this.co2EmissionFactors = co2EmissionFactors;
	}

	public double getExactKwh() {
		return exactKwh;
	}

	public void setExactKwh(double exactKwh) {
		this.exactKwh = exactKwh;
	}

	public double getIndividualMeterDailyKwhSum() {
		return individualMeterDailyKwhSum;
	}

	public void setIndividualMeterDailyKwhSum(double individualMeterDailyKwhSum) {
		this.individualMeterDailyKwhSum = individualMeterDailyKwhSum;
	}

	public double getDailyIndividualMeterTotalKwAvg() {
		return dailyIndividualMeterTotalKwAvg;
	}

	public void setDailyIndividualMeterTotalKwAvg(double dailyIndividualMeterTotalKwAvg) {
		this.dailyIndividualMeterTotalKwAvg = dailyIndividualMeterTotalKwAvg;
	}

	public double getDailyIndividualMeterPhaseRKwAvg() {
		return dailyIndividualMeterPhaseRKwAvg;
	}

	public void setDailyIndividualMeterPhaseRKwAvg(double dailyIndividualMeterPhaseRKwAvg) {
		this.dailyIndividualMeterPhaseRKwAvg = dailyIndividualMeterPhaseRKwAvg;
	}

	public double getDailyIndividualMeterPhaseYKwAvg() {
		return dailyIndividualMeterPhaseYKwAvg;
	}

	public void setDailyIndividualMeterPhaseYKwAvg(double dailyIndividualMeterPhaseYKwAvg) {
		this.dailyIndividualMeterPhaseYKwAvg = dailyIndividualMeterPhaseYKwAvg;
	}

	public double getDailyIndividualMeterPhaseBKwAvg() {
		return dailyIndividualMeterPhaseBKwAvg;
	}

	public void setDailyIndividualMeterPhaseBKwAvg(double dailyIndividualMeterPhaseBKwAvg) {
		this.dailyIndividualMeterPhaseBKwAvg = dailyIndividualMeterPhaseBKwAvg;
	}

	public double getDailyIndividualMeterTotalPfAvg() {
		return dailyIndividualMeterTotalPfAvg;
	}

	public void setDailyIndividualMeterTotalPfAvg(double dailyIndividualMeterTotalPfAvg) {
		this.dailyIndividualMeterTotalPfAvg = dailyIndividualMeterTotalPfAvg;
	}

	public double getDailyIndividualMeterRPfAvg() {
		return dailyIndividualMeterRPfAvg;
	}

	public void setDailyIndividualMeterRPfAvg(double dailyIndividualMeterRPfAvg) {
		this.dailyIndividualMeterRPfAvg = dailyIndividualMeterRPfAvg;
	}

	public double getDailyIndividualMeterYPfAvg() {
		return dailyIndividualMeterYPfAvg;
	}

	public void setDailyIndividualMeterYPfAvg(double dailyIndividualMeterYPfAvg) {
		this.dailyIndividualMeterYPfAvg = dailyIndividualMeterYPfAvg;
	}

	public double getDailyIndividualMeterBPfAvg() {
		return dailyIndividualMeterBPfAvg;
	}

	public void setDailyIndividualMeterBPfAvg(double dailyIndividualMeterBPfAvg) {
		this.dailyIndividualMeterBPfAvg = dailyIndividualMeterBPfAvg;
	}

	public double getDailyIndividualMeterTotalKvaAvg() {
		return dailyIndividualMeterTotalKvaAvg;
	}

	public void setDailyIndividualMeterTotalKvaAvg(double dailyIndividualMeterTotalKvaAvg) {
		this.dailyIndividualMeterTotalKvaAvg = dailyIndividualMeterTotalKvaAvg;
	}

	public double getDailyIndividualMeterPhaseRKvaAvg() {
		return dailyIndividualMeterPhaseRKvaAvg;
	}

	public void setDailyIndividualMeterPhaseRKvaAvg(double dailyIndividualMeterPhaseRKvaAvg) {
		this.dailyIndividualMeterPhaseRKvaAvg = dailyIndividualMeterPhaseRKvaAvg;
	}

	public double getDailyIndividualMeterPhaseYKvaAvg() {
		return dailyIndividualMeterPhaseYKvaAvg;
	}

	public void setDailyIndividualMeterPhaseYKvaAvg(double dailyIndividualMeterPhaseYKvaAvg) {
		this.dailyIndividualMeterPhaseYKvaAvg = dailyIndividualMeterPhaseYKvaAvg;
	}

	public double getDailyIndividualMeterPhaseBKvaAvg() {
		return dailyIndividualMeterPhaseBKvaAvg;
	}

	public void setDailyIndividualMeterPhaseBKvaAvg(double dailyIndividualMeterPhaseBKvaAvg) {
		this.dailyIndividualMeterPhaseBKvaAvg = dailyIndividualMeterPhaseBKvaAvg;
	}

	public double getDailyIndividualMeterLineToLineVoltageAvg() {
		return dailyIndividualMeterLineToLineVoltageAvg;
	}

	public void setDailyIndividualMeterLineToLineVoltageAvg(double dailyIndividualMeterLineToLineVoltageAvg) {
		this.dailyIndividualMeterLineToLineVoltageAvg = dailyIndividualMeterLineToLineVoltageAvg;
	}

	public double getDailyIndividualMeterVryVoltageAvg() {
		return dailyIndividualMeterVryVoltageAvg;
	}

	public void setDailyIndividualMeterVryVoltageAvg(double dailyIndividualMeterVryVoltageAvg) {
		this.dailyIndividualMeterVryVoltageAvg = dailyIndividualMeterVryVoltageAvg;
	}

	public double getDailyIndividualMeterVybVoltageAvg() {
		return dailyIndividualMeterVybVoltageAvg;
	}

	public void setDailyIndividualMeterVybVoltageAvg(double dailyIndividualMeterVybVoltageAvg) {
		this.dailyIndividualMeterVybVoltageAvg = dailyIndividualMeterVybVoltageAvg;
	}

	public double getDailyIndividualMeterVbrVoltageAvg() {
		return dailyIndividualMeterVbrVoltageAvg;
	}

	public void setDailyIndividualMeterVbrVoltageAvg(double dailyIndividualMeterVbrVoltageAvg) {
		this.dailyIndividualMeterVbrVoltageAvg = dailyIndividualMeterVbrVoltageAvg;
	}

	public double getMwh() {
		return mwh;
	}

	public void setMwh(double mwh) {
		this.mwh = mwh;
	}

	public double getCo2Emission() {
		return co2Emission;
	}

	public void setCo2Emission(double co2Emission) {
		this.co2Emission = co2Emission;
	}

	public double getDailyMeterWiseCo2Sum() {
		return dailyMeterWiseCo2Sum;
	}

	public void setDailyMeterWiseCo2Sum(double dailyMeterWiseCo2Sum) {
		this.dailyMeterWiseCo2Sum = dailyMeterWiseCo2Sum;
	}

}