package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 * A Electricity Meter Details Entity
 */
@Entity
@Table(name = "electricity_meter_details")
public class EletricityMeter implements Serializable {

	private static final long serialVersionUID = 3926617440256225022L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "electricity_meter_id")
	private Long electricityMeterId;

	@Column(name = "meter_number")
	private String meterNumber;

	@Size(max = 50)
	@Column(name = "meter_name", length = 50)
	private String meterName;

	@Column(name = "meter_slave_id")
	private String meterSlaveId;

	@Column(name = "meter_mac_id")
	private String meterMacId;

	@Column(name = "meter_manufacturer")
	private String meterManufacturer;

	@Column(name = "meter_model_number")
	private String meterModelNumber;

	@Column(name = "meter_batch_number")
	private String meterBatchNumber;

	@ManyToOne
	@JoinColumn(name = "site_id")
	private SiteMaster siteId;

	public EletricityMeter() {

	}

	public Long getElectricityMeterId() {
		return electricityMeterId;
	}

	public void setElectricityMeterId(Long electricityMeterId) {
		this.electricityMeterId = electricityMeterId;
	}

	public String getMeterNumber() {
		return meterNumber;
	}

	public void setMeterNumber(String meterNumber) {
		this.meterNumber = meterNumber;
	}

	public String getMeterName() {
		return meterName;
	}

	public void setMeterName(String meterName) {
		this.meterName = meterName;
	}

	public String getMeterSlaveId() {
		return meterSlaveId;
	}

	public void setMeterSlaveId(String meterSlaveId) {
		this.meterSlaveId = meterSlaveId;
	}

	public String getMeterMacId() {
		return meterMacId;
	}

	public void setMeterMacId(String meterMacId) {
		this.meterMacId = meterMacId;
	}

	public String getMeterManufacturer() {
		return meterManufacturer;
	}

	public void setMeterManufacturer(String meterManufacturer) {
		this.meterManufacturer = meterManufacturer;
	}

	public String getMeterModelNumber() {
		return meterModelNumber;
	}

	public void setMeterModelNumber(String meterModelNumber) {
		this.meterModelNumber = meterModelNumber;
	}

	public String getMeterBatchNumber() {
		return meterBatchNumber;
	}

	public void setMeterBatchNumber(String meterBatchNumber) {
		this.meterBatchNumber = meterBatchNumber;
	}

	public SiteMaster getSiteId() {
		return siteId;
	}

	public void setSiteId(SiteMaster siteId) {
		this.siteId = siteId;
	}

}
