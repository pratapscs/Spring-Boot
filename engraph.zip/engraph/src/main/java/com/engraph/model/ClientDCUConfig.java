package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Client_DCU_Ftp_Master")
public class ClientDCUConfig implements Serializable {

	private static final long serialVersionUID = 5797760245935806070L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long clientDcuId;

	@Column(name = "frequency")
	private String frequency;

	@Column(name = "FTP_UID")
	private String ftpUID;

	@Column(name = "FTP_URL")
	private String ftpURL;

	@Column(name = "FTP_Password")
	private String ftpPassword;

	@Column(name = "FTP_Port_Number")
	private String ftpPortNumber;

	@Column(name = "Baud_Rate")
	private String baudRate;

	@Column(name = "Parity")
	private String parity;

	@Column(name = "Stop_Bit")
	private String stopBit;

	@ManyToOne
	@JoinColumn(name = "siteId")
	private SiteMaster siteId;

	@ManyToOne
	@JoinColumn(name = "dcuId")
	private Dcudetails dcuId;
	
	public ClientDCUConfig() {
		
	}

	public Long getClientDcuId() {
		return clientDcuId;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getFtpUID() {
		return ftpUID;
	}

	public void setFtpUID(String ftpUID) {
		this.ftpUID = ftpUID;
	}

	public String getFtpURL() {
		return ftpURL;
	}

	public void setFtpURL(String ftpURL) {
		this.ftpURL = ftpURL;
	}

	public String getFtpPassword() {
		return ftpPassword;
	}

	public void setFtpPassword(String ftpPassword) {
		this.ftpPassword = ftpPassword;
	}

	public String getFtpPortNumber() {
		return ftpPortNumber;
	}

	public void setFtpPortNumber(String ftpPortNumber) {
		this.ftpPortNumber = ftpPortNumber;
	}

	public String getBaudRate() {
		return baudRate;
	}

	public void setBaudRate(String baudRate) {
		this.baudRate = baudRate;
	}

	public String getParity() {
		return parity;
	}

	public void setParity(String parity) {
		this.parity = parity;
	}

	public String getStopBit() {
		return stopBit;
	}

	public void setStopBit(String stopBit) {
		this.stopBit = stopBit;
	}

	public SiteMaster getSiteId() {
		return siteId;
	}

	public void setSiteId(SiteMaster siteId) {
		this.siteId = siteId;
	}

	public Dcudetails getDcuId() {
		return dcuId;
	}

	public void setDcuId(Dcudetails dcuId) {
		this.dcuId = dcuId;
	}

	public void setClientDcuId(Long clientDcuId) {
		this.clientDcuId = clientDcuId;
	}

}
