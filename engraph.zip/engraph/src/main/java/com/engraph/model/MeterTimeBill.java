package com.engraph.model;

/**
 * A MeterTimeBill Entity For Phoenix
 */
//@JsonFilter("meterTimeBill")
public class MeterTimeBill {

	private String siteId; // SITE_ID
	private String siteName; // SITE_NAME
	private String siteBuildingId; // SITE_BUILDING_ID
	private String buildingName; // BUILDING_NAME
	private String buildingFloorId; // BUILDING_FLOOR_ID
	private String floorName; // FLOOR_NAME
	private String assetId; // ASSET_ID
	private String assetName; // ASSET_NAME
	private String month; // MONTH
	private String year; // YEAR
	private String energyConsumptionPrice; // ENERGY_CONSUMPTION_PRICE
	
	public MeterTimeBill() {
		
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getSiteBuildingId() {
		return siteBuildingId;
	}

	public void setSiteBuildingId(String siteBuildingId) {
		this.siteBuildingId = siteBuildingId;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getBuildingFloorId() {
		return buildingFloorId;
	}

	public void setBuildingFloorId(String buildingFloorId) {
		this.buildingFloorId = buildingFloorId;
	}

	public String getFloorName() {
		return floorName;
	}

	public void setFloorName(String floorName) {
		this.floorName = floorName;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getEnergyConsumptionPrice() {
		return energyConsumptionPrice;
	}

	public void setEnergyConsumptionPrice(String energyConsumptionPrice) {
		this.energyConsumptionPrice = energyConsumptionPrice;
	}

}
