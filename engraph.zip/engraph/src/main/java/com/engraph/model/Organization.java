package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

/**
 * A Organization Detials Entity
 */
@Entity
@Table(name = "organization_details")
public class Organization implements Serializable{

	private static final long serialVersionUID = 7569129580920063803L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="organization_id")
    private Long orgId;

    @Size(max = 100)
    @Column(name = "organization_name", length = 100)
    private String orgName;

    @Size(max = 30)
    @Column(name = "country", length = 30)
    private String country;
    
    @Size(max = 40)
    @Column(name = "state", length = 40)
    private String state;
    
    @Size(max = 40)
    @Column(name = "city", length = 40)
    private String city;
    
    @Size(max = 100)
    @Column(name = "locality", length = 100)
    private String locality;
    
    @Size(max = 100)
    @Column(name = "street_address", length = 100)
    private String streetAddress;
    
    @Size(max = 100)
    @Column(name = "building_name", length = 100)
    private String buildingName;
    
    @Size(max = 20)
    @Column(name = "pin_code", length = 20)
    private String pinCode;
    
    @Size(max = 30)
    @Column(name = "cin_number", length = 30)
    private String cinNumber;
    
    @Size(max = 30)
    @Column(name = "pan_number", length = 30)
    private String panNumber;
    
    @Size(max = 30)
    @Column(name = "gst_number", length = 30)
    private String gstNumber;
    
    @Size(max = 50)
    @Column(name = "facility_manager_name", length = 50)
    private String facilityManagerName;
    
    @Size(max = 100)
    @Column(name = "facility_manager_email", length = 100)
    private String facilityManagerEmail;
    
    @Column(name = "mobile_country_code", length = 30)
    private String mobileCountrycode;
    
    @Column(name = "facility_manager_mobile")
    private String facilityManagerMobileNumber;
    
    @Column(name = "land_country_code", length = 30)
    private String landCountrycode;
     
    @Column(name = "land_city_code", length = 30)
    private String landCitycode;
    
    
    @Column(name = "facility_manager_phone")
    private String facilityManagerPhone;
    
    @Column(name = "is_multi_site")
    private Boolean isMultiSite;
    
    @Column(name = "total_site")
    private Integer totalSite;
    
    @Column(name = "total_different_legal_site")
    private Integer totalLegalSite;

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getCinNumber() {
		return cinNumber;
	}

	public void setCinNumber(String cinNumber) {
		this.cinNumber = cinNumber;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public String getFacilityManagerName() {
		return facilityManagerName;
	}

	public void setFacilityManagerName(String facilityManagerName) {
		this.facilityManagerName = facilityManagerName;
	}

	public String getFacilityManagerEmail() {
		return facilityManagerEmail;
	}

	public void setFacilityManagerEmail(String facilityManagerEmail) {
		this.facilityManagerEmail = facilityManagerEmail;
	}


	public String getMobileCountrycode() {
		return mobileCountrycode;
	}

	public void setMobileCountrycode(String mobileCountrycode) {
		this.mobileCountrycode = mobileCountrycode;
	}

	public String getFacilityManagerMobileNumber() {
		return facilityManagerMobileNumber;
	}

	public void setFacilityManagerMobileNumber(String facilityManagerMobileNumber) {
		this.facilityManagerMobileNumber = facilityManagerMobileNumber;
	}

	public String getLandCountrycode() {
		return landCountrycode;
	}

	public void setLandCountrycode(String landCountrycode) {
		this.landCountrycode = landCountrycode;
	}

	public String getLandCitycode() {
		return landCitycode;
	}

	public void setLandCitycode(String landCitycode) {
		this.landCitycode = landCitycode;
	}

	public String getFacilityManagerPhone() {
		return facilityManagerPhone;
	}

	public void setFacilityManagerPhone(String facilityManagerPhone) {
		this.facilityManagerPhone = facilityManagerPhone;
	}

	public Boolean getIsMultiSite() {
		return isMultiSite;
	}

	public void setIsMultiSite(Boolean isMultiSite) {
		this.isMultiSite = isMultiSite;
	}

	public Integer getTotalSite() {
		return totalSite;
	}

	public void setTotalSite(Integer totalSite) {
		this.totalSite = totalSite;
	}

	public Integer getTotalLegalSite() {
		return totalLegalSite;
	}

	public void setTotalLegalSite(Integer totalLegalSite) {
		this.totalLegalSite = totalLegalSite;
	}
    
}
