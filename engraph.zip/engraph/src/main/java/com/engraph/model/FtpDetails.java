package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ftp_master_details")
public class FtpDetails implements Serializable {

	private static final long serialVersionUID = -3403938106829020294L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long ftpID;

	@Column(name = "Ftp_Url")
	private String ftpUrl;

	@Column(name = "Ftp_UID")
	private String ftpUID;

	@Column(name = "Ftp_Password")
	private String ftpPassword;

	@Column(name = "Manufacturing_ID")
	private String manufacturingID;

	public FtpDetails() {

	}

	public long getFtpID() {
		return ftpID;
	}

	public void setFtpID(long ftpID) {
		this.ftpID = ftpID;
	}

	public String getFtpUrl() {
		return ftpUrl;
	}

	public void setFtpUrl(String ftpUrl) {
		this.ftpUrl = ftpUrl;
	}

	public String getFtpUID() {
		return ftpUID;
	}

	public void setFtpUID(String ftpUID) {
		this.ftpUID = ftpUID;
	}

	public String getFtpPassword() {
		return ftpPassword;
	}

	public void setFtpPassword(String ftpPassword) {
		this.ftpPassword = ftpPassword;
	}

	public String getManufacturingID() {
		return manufacturingID;
	}

	public void setManufacturingID(String manufacturingID) {
		this.manufacturingID = manufacturingID;
	}

}
