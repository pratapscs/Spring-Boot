package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * A Discom Category Business Type Master Entity
 */
@Entity
@Table(name = "discom_category_business_type_master")
public class DiscomCategoryBusinessTypeMaster implements Serializable {

	private static final long serialVersionUID = -2164460821338179782L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "discom_category_id")
	private Long discomCategoryId;

	@Column(name = "category")
	private String category;

	@Column(name = "business_types")
	private String businessType;

	@ManyToOne
	@JoinColumn(name = "power_tension_id")
	private PowerTensionMaster powerTenctionId;

	public DiscomCategoryBusinessTypeMaster() {

	}

	public Long getDiscomCategoryId() {
		return discomCategoryId;
	}

	public void setDiscomCategoryId(Long discomCategoryId) {
		this.discomCategoryId = discomCategoryId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public PowerTensionMaster getPowerTenctionId() {
		return powerTenctionId;
	}

	public void setPowerTenctionId(PowerTensionMaster powerTenctionId) {
		this.powerTenctionId = powerTenctionId;
	}

}
