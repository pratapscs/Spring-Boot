package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * A Usage Hour Master Entity
 */
@Entity
@Table(name = "usage_hour_master")
public class UsageHourMaster implements Serializable {

	private static final long serialVersionUID = -3640368444295160094L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "usage_hour_master_id")
	private Long usageHourMasterId;

	@Column(name = "hour")
	private String hour;

	@Column(name = "hour_start")
	private String hourStart;

	@Column(name = "hour_end")
	private String hourEnd;

	@ManyToOne
	@JoinColumn(name = "discom_category_id")
	private DiscomCategoryBusinessTypeMaster discomCategoryId;

	public UsageHourMaster() {

	}

	public String getHour() {
		return hour;
	}

	public void setHour(String hour) {
		this.hour = hour;
	}

	public String getHourStart() {
		return hourStart;
	}

	public void setHourStart(String hourStart) {
		this.hourStart = hourStart;
	}

	public String getHourEnd() {
		return hourEnd;
	}

	public void setHourEnd(String hourEnd) {
		this.hourEnd = hourEnd;
	}

	public DiscomCategoryBusinessTypeMaster getDiscomCategoryId() {
		return discomCategoryId;
	}

	public void setDiscomCategoryId(DiscomCategoryBusinessTypeMaster discomCategoryId) {
		this.discomCategoryId = discomCategoryId;
	}

}
