package com.engraph.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * A Building Floor Entity
 */
@Entity
@Table(name = "building_floor")
public class BuildingFloor implements Serializable {

	private static final long serialVersionUID = -2302758742819412615L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "building_floor_id")
	private Long buildingFloorId;

	@Column(name = "building_floor_number")
	private String buildingFloorNumber;

	@Size(max = 50)
	@Column(name = "building_floor_name", length = 50)
	private String buildingFloorName;

	@Column(name = "building_floor_buildup_area")
	private Double buildingFloorBuildupArea;

	@ManyToOne(optional = false)
	@JoinColumn(name = "site_building_id")
	@JsonIgnore
	private SiteBuilding siteBuilding;

	public BuildingFloor() {
		
	}
	
	public Long getBuildingFloorId() {
		return buildingFloorId;
	}

	public void setBuildingFloorId(Long buildingFloorId) {
		this.buildingFloorId = buildingFloorId;
	}

	public String getBuildingFloorNumber() {
		return buildingFloorNumber;
	}

	public void setBuildingFloorNumber(String buildingFloorNumber) {
		this.buildingFloorNumber = buildingFloorNumber;
	}

	public String getBuildingFloorName() {
		return buildingFloorName;
	}

	public void setBuildingFloorName(String buildingFloorName) {
		this.buildingFloorName = buildingFloorName;
	}

	public Double getBuildingFloorBuildupArea() {
		return buildingFloorBuildupArea;
	}

	public void setBuildingFloorBuildupArea(Double buildingFloorBuildupArea) {
		this.buildingFloorBuildupArea = buildingFloorBuildupArea;
	}

	public SiteBuilding getSiteBuilding() {
		return siteBuilding;
	}

	public void setSiteBuilding(SiteBuilding siteBuilding) {
		this.siteBuilding = siteBuilding;
	}

}
