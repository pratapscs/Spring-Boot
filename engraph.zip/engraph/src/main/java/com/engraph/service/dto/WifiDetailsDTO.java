package com.engraph.service.dto;


import com.fasterxml.jackson.annotation.JsonProperty;

public class WifiDetailsDTO {

	@JsonProperty("siteId")
	private Long siteId;
	
	@JsonProperty("wifiName")
	private String wifiName;

	@JsonProperty("wifiPassword")
	private String wifiPassword;

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public String getWifiName() {
		return wifiName;
	}

	public void setWifiName(String wifiName) {
		this.wifiName = wifiName;
	}

	public String getWifiPassword() {
		return wifiPassword;
	}

	public void setWifiPassword(String wifiPassword) {
		this.wifiPassword = wifiPassword;
	}
	
	

}
