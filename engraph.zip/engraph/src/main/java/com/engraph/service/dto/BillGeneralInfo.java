package com.engraph.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BillGeneralInfo {

	@JsonProperty("siteId")
	private Long siteId;
	
	@JsonProperty("country")
	private String country;
	
	@JsonProperty("state")
	private String state;
	
	@JsonProperty("discomName")
	private String discomName;
	
	@JsonProperty("powerTypeName")
	private String powerTypeName;

	@JsonProperty("category")
	private Long category;
	
	@JsonProperty("sitePhaseConnection")
	private String sitePhaseConnection;
	
	@JsonProperty("electricityBillingParameter")
	private String electricityBillingParameter;
	
	@JsonProperty("billingCurrency")
	private String billingCurrency;

	@JsonProperty("meterRent")
	private Double meterRent;
	
	@JsonProperty("lastBillPaymentDate")
	private String lastBillPaymentDate;
	
	@JsonProperty("electricityBill")
	private String electricityBill;


	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDiscomName() {
		return discomName;
	}

	public void setDiscomName(String discomName) {
		this.discomName = discomName;
	}

	public String getPowerTypeName() {
		return powerTypeName;
	}

	public void setPowerTypeName(String powerTypeName) {
		this.powerTypeName = powerTypeName;
	}

	
	public String getSitePhaseConnection() {
		return sitePhaseConnection;
	}

	public void setSitePhaseConnection(String sitePhaseConnection) {
		this.sitePhaseConnection = sitePhaseConnection;
	}

	public String getElectricityBillingParameter() {
		return electricityBillingParameter;
	}

	public void setElectricityBillingParameter(String electricityBillingParameter) {
		this.electricityBillingParameter = electricityBillingParameter;
	}

	public String getBillingCurrency() {
		return billingCurrency;
	}

	public void setBillingCurrency(String billingCurrency) {
		this.billingCurrency = billingCurrency;
	}

	public Double getMeterRent() {
		return meterRent;
	}

	public void setMeterRent(Double meterRent) {
		this.meterRent = meterRent;
	}

	

	public String getLastBillPaymentDate() {
		return lastBillPaymentDate;
	}

	public void setLastBillPaymentDate(String lastBillPaymentDate) {
		this.lastBillPaymentDate = lastBillPaymentDate;
	}

	public String getElectricityBill() {
		return electricityBill;
	}

	public void setElectricityBill(String electricityBill) {
		this.electricityBill = electricityBill;
	}


}
