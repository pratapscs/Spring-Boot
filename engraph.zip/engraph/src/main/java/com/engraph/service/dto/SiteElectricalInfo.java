package com.engraph.service.dto;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SiteElectricalInfo {

	@JsonProperty("siteId")
	private Long siteId;
    	
	@JsonProperty("account_id")
	private String accountId;
	
    @JsonProperty( "rr_number")
    private String rrNumber;
    
    @JsonProperty( "connection_id")
    private String connectionId;
    
    @JsonProperty( "consumer_code")
    private String consumerCode;
    
    @JsonProperty( "phase_connection")
    private String phaseConnection;
    
    @JsonProperty( "connection_load")
    private Double connectionLoad; 
    
    @JsonProperty( "load_unit")
    String loadUnit;
    
    @JsonProperty( "total_meter")
    private Integer totalMeter; 
    
    @JsonProperty( "data_collection_frequency")
    Integer dataCollectionFrequency;
    
    @JsonProperty( "site_electrical_diagram")
    //byte[] siteElectricalDiagram;
    byte[] siteElectricalDiagram;
    
	/*
	 * @JsonProperty( "file_name") String fileName;
	 */
   
	@JsonProperty( "bill_date")
    Integer billDate;
    
    @JsonProperty( "contract_demand")
    Double contractDemand; 
    
    @JsonProperty( "contract_demand_unit")
    String contractDemandUnit;
    
    @JsonProperty( "contract_start_date")
    Date contractStartDate;
    
    @JsonProperty( "contract_end_date")
    Date contractEndDate;

    
	/*
	 * public byte[] getSiteElectricalDiagram() { return siteElectricalDiagram; }
	 * 
	 * public void setSiteElectricalDiagram(byte[] siteElectricalDiagram) {
	 * this.siteElectricalDiagram = siteElectricalDiagram; }
	 */
    
    

	/*
	 * public String getFileName() { return fileName; } public void
	 * setFileName(String fileName) { this.fileName = fileName; }
	 */
	

	
	
	public Long getSiteId() {
		return siteId;
	}

	public byte[] getSiteElectricalDiagram() {
		return siteElectricalDiagram;
	}

	public void setSiteElectricalDiagram(byte[] siteElectricalDiagram) {
		this.siteElectricalDiagram = siteElectricalDiagram;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getRrNumber() {
		return rrNumber;
	}

	public void setRrNumber(String rrNumber) {
		this.rrNumber = rrNumber;
	}

	public String getConnectionId() {
		return connectionId;
	}

	public void setConnectionId(String connectionId) {
		this.connectionId = connectionId;
	}

	public String getConsumerCode() {
		return consumerCode;
	}

	public void setConsumerCode(String consumerCode) {
		this.consumerCode = consumerCode;
	}

	public String getPhaseConnection() {
		return phaseConnection;
	}

	public void setPhaseConnection(String phaseConnection) {
		this.phaseConnection = phaseConnection;
	}

	public Double getConnectionLoad() {
		return connectionLoad;
	}

	public void setConnectionLoad(Double connectionLoad) {
		this.connectionLoad = connectionLoad;
	}

	public String getLoadUnit() {
		return loadUnit;
	}

	public void setLoadUnit(String loadUnit) {
		this.loadUnit = loadUnit;
	}

	public Integer getTotalMeter() {
		return totalMeter;
	}

	public void setTotalMeter(Integer totalMeter) {
		this.totalMeter = totalMeter;
	}

	public Integer getDataCollectionFrequency() {
		return dataCollectionFrequency;
	}

	public void setDataCollectionFrequency(Integer dataCollectionFrequency) {
		this.dataCollectionFrequency = dataCollectionFrequency;
	}


	public Integer getBillDate() {
		return billDate;
	}

	public void setBillDate(Integer billDate) {
		this.billDate = billDate;
	}

	public Double getContractDemand() {
		return contractDemand;
	}

	public void setContractDemand(Double contractDemand) {
		this.contractDemand = contractDemand;
	}

	public String getContractDemandUnit() {
		return contractDemandUnit;
	}

	public void setContractDemandUnit(String contractDemandUnit) {
		this.contractDemandUnit = contractDemandUnit;
	}

	public Date getContractStartDate() {
		return contractStartDate;
	}

	public void setContractStartDate(Date contractStartDate) {
		this.contractStartDate = contractStartDate;
	}

	public Date getContractEndDate() {
		return contractEndDate;
	}

	public void setContractEndDate(Date contractEndDate) {
		this.contractEndDate = contractEndDate;
	}

	
}
