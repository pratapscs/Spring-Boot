package com.engraph.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MeterSetupDTO {

	@JsonProperty("manufacturingID")
	private Long manufacturingID;
	
	@JsonProperty("electricityMeterId")
	private Long electricityMeterId;
	
	@JsonProperty("meterCompany")
	private String meterCompany;
	
	@JsonProperty("meterModel")
	private String meterModel;

	public Long getManufacturingID() {
		return manufacturingID;
	}

	public void setManufacturingID(Long manufacturingID) {
		this.manufacturingID = manufacturingID;
	}

	public Long getElectricityMeterId() {
		return electricityMeterId;
	}

	public void setElectricityMeterId(Long electricityMeterId) {
		this.electricityMeterId = electricityMeterId;
	}

	public String getMeterCompany() {
		return meterCompany;
	}

	public void setMeterCompany(String meterCompany) {
		this.meterCompany = meterCompany;
	}

	public String getMeterModel() {
		return meterModel;
	}

	public void setMeterModel(String meterModel) {
		this.meterModel = meterModel;
	}
	

}
