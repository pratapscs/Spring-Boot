package com.engraph.service.dto;

public class ForecastDTO {

	private String forecastDim;
	private String monthDim;
	private String yearDim;
	
	public String getForecastDim() {
		return forecastDim;
	}
	public void setForecastDim(String forecastDim) {
		this.forecastDim = forecastDim;
	}
	public String getMonthDim() {
		return monthDim;
	}
	public void setMonthDim(String monthDim) {
		this.monthDim = monthDim;
	}
	public String getYearDim() {
		return yearDim;
	}
	public void setYearDim(String yearDim) {
		this.yearDim = yearDim;
	}
	
	

}
