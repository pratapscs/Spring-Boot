package com.engraph.service.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AssetDTO {

	@JsonProperty("siteId")
	private Long siteId;

	@JsonProperty("assets")
	private List<MeterAssetDTO> meterAssets;

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public List<MeterAssetDTO> getMeterAssets() {
		return meterAssets;
	}

	public void setMeterAssets(List<MeterAssetDTO> meterAssets) {
		this.meterAssets = meterAssets;
	}

}
