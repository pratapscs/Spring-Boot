package com.engraph.service;

import java.util.List;
import com.engraph.model.AllMeterData;
import com.engraph.model.MeterTimeBill;
import com.engraph.model.ProcessAssets;
import com.engraph.model.ProcessedData;
import com.engraph.service.dto.BillUtility;
import com.engraph.service.dto.CompareDates;
import com.engraph.service.dto.ComparisonDTO;
import com.engraph.service.dto.ComponentDTO;
import com.engraph.service.dto.SiteDTO;

public interface IAllMeterDataService {

	// Dash board
	List<AllMeterData> getYesterDayKwhData() throws Exception;

	List<AllMeterData> getTodayKwhData();

	List<AllMeterData> getTomorrowKwhData();

	List<AllMeterData> getYesterDayCo2Data();

	List<AllMeterData> getTodayCo2Data();

	List<AllMeterData> getTomorrowCo2Data();

	List<ProcessedData> getTopConsumedAssets();

	// Live Monitoring - Energy Consumption
	List<AllMeterData> getTodayEnergyConsumption();

	List<ProcessAssets> getTodayEnergyConsumptionByAssets(List<List<ComponentDTO>> componentDTO);

	List<AllMeterData> getThisWeekEnergyConsumption();

	List<ProcessAssets> getThisWeekEnergyConsumptionByAssets(List<List<ComponentDTO>> componentDTO);

	List<AllMeterData> getThisMonthEnergyConsumption();

	List<ProcessAssets> getThisMonthEnergyConsumptionByAssets(List<List<ComponentDTO>> componentDTO);

	// Live Monitoring - Power Quality
	List<AllMeterData> getTodayPowerQuality();

	List<ProcessedData> getTodayPowerQualityByAssets(SiteDTO[] siteDto);

	List<AllMeterData> getThisWeekPowerQuality();

	List<ProcessedData> getThisWeekPowerQualityByAssets(SiteDTO[] siteDto);

	List<AllMeterData> getThisMonthPowerQuality();

	List<ProcessedData> getThisMonthPowerQualityByAssets(SiteDTO[] siteDto);

	// Live Monitoring - Load Profile
	List<AllMeterData> getTodayLoadProfile();

	List<ProcessedData> getTodayLoadProfileByAssets(SiteDTO[] siteDto);

	List<AllMeterData> getThisWeekLoadProfile();

	List<ProcessedData> getThisWeekLoadProfileByAssets(SiteDTO[] siteDto);

	List<AllMeterData> getThisMonthLoadProfile();

	List<ProcessedData> getThisMonthLoadProfileByAssets(SiteDTO[] siteDto);

	// Co2 Emission
	List<AllMeterData> getTodayCo2Emission();

	List<ProcessedData> getTodayCo2EmissionByAssets(SiteDTO[] siteDto);

	List<AllMeterData> getThisWeekCo2Emission();

	List<ProcessedData> getThisWeekCo2EmissionByAssets(SiteDTO[] siteDto);

	List<AllMeterData> getThisMonthCo2Emission();

	List<ProcessedData> getThisMonthCo2EmissionByAssets(SiteDTO[] siteDto);

	// Co2 Emission - Highest Emitters
	List<ProcessedData> getTodayHighestEmitters();

	List<ProcessedData> getThisWeekHighestEmitters();

	List<ProcessedData> getThisMonthHighestEmitters();

	// Co2 Emission - Greenest Units
	List<ProcessedData> getTodayGreenestUnits();

	List<ProcessedData> getThisWeekGreenestUnits();

	List<ProcessedData> getThisMonthGreenestUnits();

	
	//Historical Data - kWh
	List<AllMeterData> getKwhData(String startDate,String endDate);
	List<ProcessAssets> getKwhAssets(List<List<ComponentDTO>> componentDTO,String startDate,String endDate);
	
	
	//Historical Data - kW
	List<AllMeterData> getKwData(String startDate,String endDate);
	//List<ProcessedData> getKwAssets(List<List<ComponentDTO>> componentDTO,String startDate,String endDate);
	
	//Historical Data - kVA
	List<AllMeterData> getKvaData(String startDate,String endDate);
	//List<ProcessedData> getKvaAssets(List<List<ComponentDTO>> componentDTO,String startDate,String endDate);
	
	//Historical Data - PF
	List<AllMeterData> getPfData(String startDate,String endDate);
	//List<ProcessedData> getPfAssets(List<List<ComponentDTO>> componentDTO,String startDate,String endDate);
	
	//Historical Data - voltage
	List<AllMeterData> getVoltageData(String startDate,String endDate);
	//List<ProcessedData> getVoltageAssets(List<List<ComponentDTO>> componentDTO,String startDate,String endDate);
	
	//Historical Data - co2
	List<AllMeterData> getCo2Data(String startDate,String endDate);
	//List<ProcessedData> getCo2Assets(List<List<ComponentDTO>> componentDTO,String startDate,String endDate);
	
	
	// Historical Data - Energy Consumption
	List<AllMeterData> getYesterdayEnergyConsumption();

	List<ProcessedData> getYesterdayEnergyConsumptionByAssets(Integer[] assets);

	List<AllMeterData> getLastWeekEnergyConsumption();

	List<ProcessedData> getLastWeekEnergyConsumptionByAssets(Integer[] assets);

	List<AllMeterData> getLastMonthEnergyConsumption();

	List<ProcessedData> getLastMonthEnergyConsumptionByAssets(Integer[] assets);

	// Historical Data - kw
	List<AllMeterData> getYesterdayKw();

	List<ProcessedData> getYesterdayKwByAssets(Integer[] assets);

	List<AllMeterData> getLastWeekKw();

	List<ProcessedData> getLastWeekKwByAssets(Integer[] assets);

	List<AllMeterData> getLastMonthKw();

	List<ProcessedData> getLastMonthKwByAssets(Integer[] assets);

	// Historical Data - kVA
	List<AllMeterData> getYesterdayKva();

	List<ProcessedData> getYesterdayKvaByAssets(Integer[] assets);

	List<AllMeterData> getLastWeekKva();

	List<ProcessedData> getLastWeekKvaByAssets(Integer[] assets);

	List<AllMeterData> getLastMonthKva();

	List<ProcessedData> getLastMonthKvaByAssets(Integer[] assets);

	// Historical Data - pf
	List<AllMeterData> getYesterdayPf();

	List<ProcessedData> getYesterdayPfByAssets(Integer[] assets);

	List<AllMeterData> getLastWeekPf();

	List<ProcessedData> getLastWeekPfByAssets(Integer[] assets);

	List<AllMeterData> getLastMonthPf();

	List<ProcessedData> getLastMonthPfByAssets(Integer[] assets);

	// Historical Data - voltage
	List<AllMeterData> getYesterdayVoltage();

	List<ProcessedData> getYesterdayVoltageByAssets(Integer[] assets);

	List<AllMeterData> getLastWeekVoltage();

	List<ProcessedData> getLastWeekVoltageByAssets(Integer[] assets);

	List<AllMeterData> getLastMonthVoltage();

	List<ProcessedData> getLastMonthVoltageByAssets(Integer[] assets);

	// Historical Data - co2
	List<AllMeterData> getYesterdayCo2();

	List<ProcessedData> getYesterdayCo2ByAssets(Integer[] assets);

	List<AllMeterData> getLastWeekCo2();

	List<ProcessedData> getLastWeekCo2ByAssets(Integer[] assets);

	List<AllMeterData> getLastMonthCo2();

	List<ProcessedData> getLastMonthCo2ByAssets(Integer[] assets);

	Double getMonthYearWiseKwhBySite(String year, String month, Long siteId);
	
	
	//Real Time Analysis - Comparison
	CompareDates getRealTimeAnalysisComparison(ComparisonDTO comData);
	//CompareDates getToDayYesterDayComparisonByAssets(ComparisonDTO comData,Integer[] assets);
	
	//List<ProcessedData> getToDayYesterDayComparisonByAssets(Integer[] assets);
	
	List<MeterTimeBill> findByBillSiteId(String year,String month,String siteId);
	
	MeterTimeBill findBySiteBill(String year,String month,String siteId);
	
	List<MeterTimeBill> findByBuildingBill(String year,String month,String siteId);
	
	List<MeterTimeBill> findByFloorBill(String year,String month,String siteId);
	
	List<MeterTimeBill> findByAssetBill(String year,String month,String siteId);
	
	int saveBillUtility(BillUtility billUtility);
	
	BillUtility findBySiteBillUtility(String year,String month,Long siteId);

}