package com.engraph.service.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class BuildingFloorDTO {

	@JsonProperty("building_floor_id")
	private Long buildingFloorId;
	
	@JsonProperty("site_building_id")
	private Long siteBuildingId;

	@JsonProperty("building_floor_number")
	private String buildingFloorNumber;

	@JsonProperty("building_floor_name")
	private String buildingFloorName;

	@JsonProperty("building_floor_buildup_area")
	private Double buildingFloorBuildupArea;
	
	@JsonProperty("assets")
	private List<MeterAssetDTO>  assets;

	
	public Long getBuildingFloorId() {
		return buildingFloorId;
	}

	public void setBuildingFloorId(Long buildingFloorId) {
		this.buildingFloorId = buildingFloorId;
	}

	public List<MeterAssetDTO> getAssets() {
		return assets;
	}

	public void setAssets(List<MeterAssetDTO> assets) {
		this.assets = assets;
	}

	public Long getSiteBuildingId() {
		return siteBuildingId;
	}

	public void setSiteBuildingId(Long siteBuildingId) {
		this.siteBuildingId = siteBuildingId;
	}

	public String getBuildingFloorNumber() {
		return buildingFloorNumber;
	}

	public void setBuildingFloorNumber(String buildingFloorNumber) {
		this.buildingFloorNumber = buildingFloorNumber;
	}

	public String getBuildingFloorName() {
		return buildingFloorName;
	}

	public void setBuildingFloorName(String buildingFloorName) {
		this.buildingFloorName = buildingFloorName;
	}

	public Double getBuildingFloorBuildupArea() {
		return buildingFloorBuildupArea;
	}

	public void setBuildingFloorBuildupArea(Double buildingFloorBuildupArea) {
		this.buildingFloorBuildupArea = buildingFloorBuildupArea;
	}

}
