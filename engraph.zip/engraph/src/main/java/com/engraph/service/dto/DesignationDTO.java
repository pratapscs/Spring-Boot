package com.engraph.service.dto;

import com.engraph.model.DesignationMaster;
import com.engraph.model.RoleMaster;
import com.fasterxml.jackson.annotation.JsonProperty;

public class DesignationDTO {

	@JsonProperty("designation_id")
	private Long designationId;

	@JsonProperty("designation")
    private String designation;
	
	public DesignationDTO() {}
	
	public DesignationDTO(DesignationMaster designationMaster) {
		this.designationId = designationMaster.getDesignationId();
		this.designation = designationMaster.getDesignation();
	}

	public Long getDesignationId() {
		return designationId;
	}

	public void setDesignationId(Long designationId) {
		this.designationId = designationId;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	
}
