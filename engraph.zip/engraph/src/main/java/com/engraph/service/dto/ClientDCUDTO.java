package com.engraph.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ClientDCUDTO {


	@JsonProperty("frequency")
	private String frequency;
	
	@JsonProperty("ftpUID")
	private String ftpUID;
	
	@JsonProperty("ftpURL")
	private String ftpURL;
	
	@JsonProperty("ftpPassword")
	private String ftpPassword;
	
	@JsonProperty("ftpPortNumber")
	private String ftpPortNumber;
	
	@JsonProperty("baudRate")
	private String baudRate;
	
	@JsonProperty("parity")
	private String parity;
	
	@JsonProperty("stopBit")
	private String stopBit;
	
	@JsonProperty("siteId")
	private Long siteId;
	
	@JsonProperty("manufacturingID")
	private Long dcuId;

		
	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getFtpUID() {
		return ftpUID;
	}

	public void setFtpUID(String ftpUID) {
		this.ftpUID = ftpUID;
	}

	public String getFtpURL() {
		return ftpURL;
	}

	public void setFtpURL(String ftpURL) {
		this.ftpURL = ftpURL;
	}

	public String getFtpPassword() {
		return ftpPassword;
	}

	public void setFtpPassword(String ftpPassword) {
		this.ftpPassword = ftpPassword;
	}

	public String getFtpPortNumber() {
		return ftpPortNumber;
	}

	public void setFtpPortNumber(String ftpPortNumber) {
		this.ftpPortNumber = ftpPortNumber;
	}

	public String getBaudRate() {
		return baudRate;
	}

	public void setBaudRate(String baudRate) {
		this.baudRate = baudRate;
	}

	public String getParity() {
		return parity;
	}

	public void setParity(String parity) {
		this.parity = parity;
	}

	public String getStopBit() {
		return stopBit;
	}

	public void setStopBit(String stopBit) {
		this.stopBit = stopBit;
	}

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public Long getDcuId() {
		return dcuId;
	}

	public void setDcuId(Long dcuId) {
		this.dcuId = dcuId;
	}
	
	
	
}
