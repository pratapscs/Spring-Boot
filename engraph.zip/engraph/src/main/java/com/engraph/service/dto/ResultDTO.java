
package com.engraph.service.dto;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;

//@JsonFilter("resultDTO")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResultDTO {
	
	@JsonProperty("site")
	private SiteGeneralInfo site;
		
	public SiteGeneralInfo getSite() {
		return site;
	}

	public void setSite(SiteGeneralInfo site) {
		this.site = site;
	}

	
}
