package com.engraph.service.dto;


import com.fasterxml.jackson.annotation.JsonProperty;

public class BillUtility {
	
	private String billId;
	 
	@JsonProperty("select_year")
	private String selectYear;
	
	@JsonProperty("select_month")
	private String selectMonth;
	
	@JsonProperty("bill_File")
	private String billFile;
	
	@JsonProperty("total_consumption")
	private double totalConsumption;
	
	@JsonProperty("total_consumption_price")
	private double totalConsumptionPrice;

	public String getBillId() {
		return billId;
	}

	public void setBillId(String billId) {
		this.billId = billId;
	}

	public String getSelectYear() {
		return selectYear;
	}

	public void setSelectYear(String selectYear) {
		this.selectYear = selectYear;
	}

	public String getSelectMonth() {
		return selectMonth;
	}

	public void setSelectMonth(String selectMonth) {
		this.selectMonth = selectMonth;
	}

	public String getBillFile() {
		return billFile;
	}

	public void setBillFile(String billFile) {
		this.billFile = billFile;
	}

	public double getTotalConsumption() {
		return totalConsumption;
	}

	public void setTotalConsumption(double totalConsumption) {
		this.totalConsumption = totalConsumption;
	}

	public double getTotalConsumptionPrice() {
		return totalConsumptionPrice;
	}

	public void setTotalConsumptionPrice(double totalConsumptionPrice) {
		this.totalConsumptionPrice = totalConsumptionPrice;
	}

	
	
	
}
