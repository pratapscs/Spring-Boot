package com.engraph.service;

import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.engraph.model.BuildingFloor;
import com.engraph.repository.BuildingFloorRepository;
import com.engraph.repository.SiteBuildingRepository;
import com.engraph.service.dto.BuildingFloorDTO;

/**
 * Service class for managing building floor details.
 */
@Service
@Transactional
public class BuildingFloorDetailService {

	private static final Logger log = LoggerFactory.getLogger(BuildingFloorDetailService.class);

	@Autowired
	private BuildingFloorRepository buildingFloorRepository;

	@Autowired
	private SiteBuildingRepository siteBuildingRepository;

	public BuildingFloor saveBuildingFloorInfo(@Valid BuildingFloorDTO buildingFloorDTO, Long siteBuildingId) {
		log.debug("Save Building Floor information");
		BuildingFloor buildingFloor = new BuildingFloor();
		buildingFloor.setBuildingFloorNumber(buildingFloorDTO.getBuildingFloorNumber());
		buildingFloor.setBuildingFloorName(buildingFloorDTO.getBuildingFloorName());
		buildingFloor.setBuildingFloorBuildupArea(buildingFloorDTO.getBuildingFloorBuildupArea());
		buildingFloor.setSiteBuilding(siteBuildingRepository.findById(siteBuildingId).get());
		return buildingFloorRepository.save(buildingFloor);
	}

	public Optional<BuildingFloor> findOne(Long id) {
		log.debug("Request to get BildingFloor : {}", id);
		return buildingFloorRepository.findById(id);
	}

}
