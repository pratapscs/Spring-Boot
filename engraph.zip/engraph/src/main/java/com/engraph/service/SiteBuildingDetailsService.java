package com.engraph.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.engraph.model.SiteBuilding;
import com.engraph.model.SiteMaster;
import com.engraph.repository.SiteBuildingRepository;
import com.engraph.service.dto.BuildingDTO;
import com.engraph.service.dto.BuildingFloorDTO;
import com.engraph.service.dto.SiteBuildingDTO;

/**
 * Service class for managing site building details.
 */
@Service
@Transactional
public class SiteBuildingDetailsService {

	private static final Logger log = LoggerFactory.getLogger(SiteBuildingDetailsService.class);

	@Autowired
	private SiteBuildingRepository siteBuildingRepository;

	@Autowired
	private BuildingFloorDetailService buildingFloorService;

	public List<SiteBuilding> saveSiteBuildingInfo(@Valid BuildingDTO siteBuildingDTO, SiteMaster siteMaster) {
		log.debug("Save site Building information");

		 List<SiteBuilding> assets = new ArrayList<SiteBuilding>();

		for (SiteBuildingDTO buildingDTO : siteBuildingDTO.getSiteBuildings()) {
			SiteBuilding siteBuilding = new SiteBuilding();
			siteBuilding.setBuildingNumber(buildingDTO.getBuildingNumber());
			siteBuilding.setBuildingName(buildingDTO.getBuildingName());
			siteBuilding.setBuildingBuildupArea(buildingDTO.getBuildingBuildupArea());
			siteBuilding.setBuildingTerraceArea(buildingDTO.getBuildingTerraceArea());
			siteBuilding.setBuildingTotalMeters(buildingDTO.getBuildingTotalMeters());
			siteBuilding.setBuildingTotalFloors(buildingDTO.getBuildingTotalFloors());
			siteBuilding.setBuildingElectricalDiagram(buildingDTO.getBuildingElectricalDiagram());
			siteBuilding.setSiteId(siteMaster);
			siteBuilding = siteBuildingRepository.save(siteBuilding);

			for (BuildingFloorDTO floorDTO : buildingDTO.getFloors()) {
				buildingFloorService.saveBuildingFloorInfo(floorDTO, siteBuilding.getSiteBuildingId());
			}
		}
		return assets;
	}

	public Page<SiteBuilding> getAllBuildingsofSite(SiteMaster siteId, Pageable pageable) {
		return siteBuildingRepository.findAllBySiteId(siteId, pageable);

	}

}
