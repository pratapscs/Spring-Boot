package com.engraph.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.engraph.model.Asset;
import com.engraph.model.BuildingFloor;
import com.engraph.model.EletricityMeter;
import com.engraph.model.SiteBuilding;
import com.engraph.model.SiteMaster;
import com.engraph.repository.AssetRepository;
import com.engraph.repository.ElectricityMeterRepository;
import com.engraph.repository.SiteBuildingRepository;
import com.engraph.service.dto.AssetDTO;
import com.engraph.service.dto.MeterAssetDTO;

/**
 * Service class for managing Asset.
 */
@Service
@Transactional
public class AssetService {

	private static final Logger log = LoggerFactory.getLogger(AssetService.class);

	@Autowired
	private AssetRepository assetRepository;
	
	@Autowired
	private ElectricityMeterRepository electricityMeterRepository;
	
	@Autowired
	private SiteBuildingRepository siteBuildingRepository;
	
	
	public List<Asset> saveAssetInfo(@Valid AssetDTO assetDTO, SiteMaster siteMaster) {
		log.debug("Save Asset information");
        List<Asset> assets = new ArrayList<Asset>();
        
        
		for (MeterAssetDTO meterAssetDTO : assetDTO.getMeterAssets()) {
			
			Asset asset = new Asset();
			Optional<EletricityMeter> meterId = electricityMeterRepository.findByElectricityMeterId(meterAssetDTO.getMeterName());
			asset.setElectricityMeter(meterId.get());
			
			Optional<SiteBuilding> buildingId = siteBuildingRepository.findBySiteBuildingId(meterAssetDTO.getBuildingName());
			asset.setSiteBuilding(buildingId.get());
			
			BuildingFloor floor = buildingId.get().getFloors().stream().filter(floorId -> floorId.getBuildingFloorId() == meterAssetDTO.getFloorName()).findFirst().get();
			asset.setBuildingFloor(floor);
			
			asset.setAssetName(meterAssetDTO.getAssetName());
			asset.setAssetMacId(meterAssetDTO.getAssetMacId());
			asset.setAssetManufacturer(meterAssetDTO.getAssetManufacturer());
			asset.setAssetModelNumber(meterAssetDTO.getAssetModelNumber());
			asset.setAssetBatchNumber(meterAssetDTO.getAssetBatchNumber());
			asset.setSiteId(siteMaster);
			assetRepository.save(asset);
			assets.add(asset);
		}
		return assets;
	}
	
	public Page<Asset> getAllAssetssofSite(SiteMaster siteId, Pageable pageable) {
		return assetRepository.findAllBySiteId(siteId, pageable);

	}
}
