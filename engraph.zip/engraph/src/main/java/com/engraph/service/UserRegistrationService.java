package com.engraph.service;

import java.time.Instant;
import java.util.Objects;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.engraph.model.DesignationMaster;
import com.engraph.model.Organization;
import com.engraph.model.RoleMaster;
import com.engraph.model.UserRegistration;
import com.engraph.repository.DesignationMasterRepository;
import com.engraph.repository.OrganizationRepository;
import com.engraph.repository.RoleMasterRepository;
import com.engraph.repository.SiteMasterRepository;
import com.engraph.repository.UserRegistrationRepository;
import com.engraph.service.dto.OrganizationDTO;
import com.engraph.service.dto.UserDTO;
import com.engraph.service.util.RandomUtil;

/**
 * Service class for managing users.
 */
@Service
@Transactional
public class UserRegistrationService {
	
	private static final Logger log = LoggerFactory.getLogger(UserRegistrationService.class);
	
	@Autowired
	private UserRegistrationRepository userRegistrationRepository;
	
	@Autowired
	private OrganizationRepository organizationRepository;

	@Autowired
	private RoleMasterRepository roleRepository;
	
	@Autowired
	private DesignationMasterRepository designationRepository;
	
	@Autowired
	private SiteMasterRepository siteMasterRespository;
	
	@Autowired
	private CacheManager cacheManager;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	public UserRegistration createUser(@Valid UserDTO userDTO) {
		
		//Create an organization first for this admin.
		
		Organization organization = new Organization();
		organization.setOrgName(userDTO.getOrganizationName());
		organization.setFacilityManagerName(userDTO.getFirstName());
		organization.setFacilityManagerEmail(userDTO.getEmail());
		organization = organizationRepository.save(organization);
		
		/*
		 * SiteMaster siteMaster = new SiteMaster(); siteMaster.setOrgId(organization);
		 * siteMaster = siteMasterRespository.save(siteMaster);
		 */
		
		//Create User entity
		UserRegistration userRegistration = new UserRegistration();
        userRegistration.setFirstName(userDTO.getFirstName());
        userRegistration.setLastName(userDTO.getLastName());
        userRegistration.setSalutation(userDTO.getSalutation());
        userRegistration.setEmail(userDTO.getEmail().toLowerCase());
        userRegistration.setOrgId(organization);
        
       
        String encryptedPassword = passwordEncoder.encode(RandomUtil.generatePassword());
        userRegistration.setPassword(encryptedPassword);
        userRegistration.setActivationKey(RandomUtil.generateActivationKey());
        userRegistration.setRegistrationDate(Instant.now());
        userRegistration.setActivated(false);
        userRegistration.setRole(findRole());
        userRegistration.setDesignation(findDesignation());
        
        userRegistrationRepository.save(userRegistration);
        this.clearUserCaches(userRegistration);
        log.debug("Created Information for User: {}", userRegistration);
        return userRegistration;
	}
	
	private void clearUserCaches(UserRegistration userRegistration) {
        Objects.requireNonNull(cacheManager.getCache(userRegistrationRepository.USERS_BY_EMAIL_CACHE)).evict(userRegistration.getEmail());
	}
	
	public RoleMaster findRole() {
		return roleRepository.findOneByRoleId(Long.valueOf(1)).get();
	}
	
	public DesignationMaster findDesignation() {
		return designationRepository.findOneByDesignationId(Long.valueOf(3)).get();
	}
	
	
	public Optional<UserRegistration> requestPasswordReset(String mail) {
        return userRegistrationRepository.findOneByEmailIgnoreCase(mail)
            .filter(UserRegistration::isActivated)
            .map(userRegistration -> {
            	userRegistration.setResetKey(RandomUtil.generateResetKey());
            	userRegistration.setResetDate(Instant.now());
                this.clearUserCaches(userRegistration);
                return userRegistration;
            });
	}
	
	
	public Optional<UserRegistration> completePasswordReset(String newPassword, String key) {
        log.debug("Reset user password for reset key {}", key);
        return userRegistrationRepository.findOneByResetKey(key)
            .filter(userRegistration -> userRegistration.getResetDate().isAfter(Instant.now().minusSeconds(86400)))
            .map(userRegistration -> {
            	userRegistration.setPassword(passwordEncoder.encode(newPassword));
            	userRegistration.setResetKey(null);
            	userRegistration.setResetDate(null);
                this.clearUserCaches(userRegistration);
                return userRegistration;
            });
	}

	public Page<UserRegistration> getAllUsersofOrganization(Organization orgId, Pageable pageable) {
		return userRegistrationRepository.findAllByOrgId(orgId,pageable);
		
	}

	public Optional<UserRegistration> validateAuthKey(String authkey) {
		log.debug("validate user auth key for create password {}", authkey);
		return userRegistrationRepository.findOneByActivationKey(authkey)
        .map(user -> {
            // activate given user for the registration key.
            user.setActivated(true);
            //user.setActivationKey(null);
            this.clearUserCaches(user);
            log.debug("Activated user: {}", user);
            return user;
        });
	}

	public Organization updateOrg(Organization organization, @Valid OrganizationDTO organizationDTO) {
		organization.setCountry(organizationDTO.getCountry());
		organization.setCity(organizationDTO.getCity());
		organization.setState(organizationDTO.getState());
		organization.setLocality(organizationDTO.getLocality());
		organization.setStreetAddress(organizationDTO.getStreetAddress());
		organization.setBuildingName(organizationDTO.getBuildingName());
		organization.setPinCode(organizationDTO.getPinCode());
		organization.setPanNumber(organizationDTO.getPanNumber());
		organization.setCinNumber(organizationDTO.getCinNumber());
		organization.setGstNumber(organizationDTO.getGstNumber());
		organization.setFacilityManagerName(organizationDTO.getFacilityManagerName());
		organization.setFacilityManagerEmail(organizationDTO.getFacilityManagerEmail());
		organization.setMobileCountrycode(organizationDTO.getMobileCountrycode());
		organization.setFacilityManagerMobileNumber(organizationDTO.getFacilityManagerMobileNumber());
		organization.setLandCountrycode(organizationDTO.getLandCountrycode());
		organization.setLandCitycode(organizationDTO.getLandCitycode());
		organization.setFacilityManagerPhone(organizationDTO.getFacilityManagerPhone());
		return organizationRepository.save(organization);
	}

	public Optional<UserRegistration> setPassword(String password, String key) {
		log.debug("set user password for login key {}", key);
        return userRegistrationRepository.findOneByEmail(key)
            .filter(userRegistration -> userRegistration.getResetDate().isAfter(Instant.now().minusSeconds(86400)))
            .map(userRegistration -> {
            	userRegistration.setPassword(passwordEncoder.encode(password));
            	userRegistration.setResetKey(null);
            	userRegistration.setResetDate(null);
                this.clearUserCaches(userRegistration);
                return userRegistration;
            });
	}

	public Optional<UserRegistration> getUserByAuthKeyAndEmail(String authKey, String email) {
		return userRegistrationRepository.findOneByActivationKeyAndEmail(authKey, email);
	}

	public UserRegistration updateIntitialUserPassword(Optional<UserRegistration> user, UserRegistration oldUser) {
		UserRegistration updatedUser = user.get();
		updatedUser.setPassword(oldUser.getPassword());
		// updatedUser.setActivationKey(null);
		return userRegistrationRepository.save(updatedUser);
	 }
	
	

	public Optional<UserRegistration> authenticate(String password, String username) {
		return userRegistrationRepository.findOneByEmailAndPassword(username, password);
	}
	
	public Optional<UserRegistration> findByEmail(String emailId) {
		return userRegistrationRepository.findOneByEmail(emailId);
	}
}
