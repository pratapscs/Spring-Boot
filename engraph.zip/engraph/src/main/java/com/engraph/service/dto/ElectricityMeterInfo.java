package com.engraph.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ElectricityMeterInfo {

	@JsonProperty("siteId")
	private Long siteId;

	@JsonProperty("meter_number")
	private String meterNumber;

	@JsonProperty("meter_name")
	private String meterName;

	@JsonProperty("meter_slave_id")
	private String meterSlaveId;

	@JsonProperty("meter_mac_id")
	private String meterMacId;

	@JsonProperty("meter_manufacturer")
	private String meterManufacturer;

	@JsonProperty("meter_model_number")
	private String meterModelNumber;

	@JsonProperty("meter_batch_number")
	private String meterBatchNumber;

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public String getMeterNumber() {
		return meterNumber;
	}

	public void setMeterNumber(String meterNumber) {
		this.meterNumber = meterNumber;
	}

	public String getMeterName() {
		return meterName;
	}

	public void setMeterName(String meterName) {
		this.meterName = meterName;
	}

	public String getMeterSlaveId() {
		return meterSlaveId;
	}

	public void setMeterSlaveId(String meterSlaveId) {
		this.meterSlaveId = meterSlaveId;
	}

	public String getMeterMacId() {
		return meterMacId;
	}

	public void setMeterMacId(String meterMacId) {
		this.meterMacId = meterMacId;
	}

	public String getMeterManufacturer() {
		return meterManufacturer;
	}

	public void setMeterManufacturer(String meterManufacturer) {
		this.meterManufacturer = meterManufacturer;
	}

	public String getMeterModelNumber() {
		return meterModelNumber;
	}

	public void setMeterModelNumber(String meterModelNumber) {
		this.meterModelNumber = meterModelNumber;
	}

	public String getMeterBatchNumber() {
		return meterBatchNumber;
	}

	public void setMeterBatchNumber(String meterBatchNumber) {
		this.meterBatchNumber = meterBatchNumber;
	}

}
