package com.engraph.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.stream.Collectors;
import javax.validation.Valid;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.engraph.model.Asset;
import com.engraph.model.Organization;
import com.engraph.model.SiteBuilding;
import com.engraph.model.SiteElectrical;
import com.engraph.model.SiteMaster;
import com.engraph.model.SitePower;
import com.engraph.repository.AssetRepository;
import com.engraph.repository.SiteBuildingRepository;
import com.engraph.repository.SiteElectricalRepository;
import com.engraph.repository.SiteMasterRepository;
import com.engraph.repository.SitePowerRepository;

import com.engraph.service.dto.BuildingFloorDTO;
import com.engraph.service.dto.MeterAssetDTO;
import com.engraph.service.dto.ResultDTO;
import com.engraph.service.dto.SiteBuildingDTO;
import com.engraph.service.dto.SiteElectricalInfo;
import com.engraph.service.dto.SiteGeneralInfo;
import com.engraph.service.dto.SitePowerInfo;
import com.engraph.service.dto.SolarPanelDTO;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Service class for managing site.
 */
@Service
@Transactional
public class SiteDetailService {

	private static final Logger log = LoggerFactory.getLogger(SiteDetailService.class);

	@Autowired
	private SiteMasterRepository siteMasterRepository;

	@Autowired
	private SiteBuildingRepository siteBuildingRepository;

	@Autowired
	private SiteElectricalRepository siteElectricalRepository;

	@Autowired
	private AssetRepository assetRepository;

	@Autowired
	private SitePowerRepository sitePowerRepository;

	@Autowired
	private IAllMeterDataService allMeterDataService;

	public SiteMaster saveSiteInfo(@Valid SiteGeneralInfo siteGeneralInfo, Organization organization) {
		SiteMaster siteMaster = new SiteMaster();
		siteMaster.setSiteName(siteGeneralInfo.getSiteName());
		siteMaster.setSiteType(siteGeneralInfo.getSiteType());
		siteMaster.setSiteConnectionType(siteGeneralInfo.getSiteConnectionType());
		siteMaster.setSiteTotalArea(siteGeneralInfo.getSiteTotalArea());
		siteMaster.setSiteBuildupArea(siteGeneralInfo.getSiteBuildupArea());
		siteMaster.setSiteOpenArea(siteGeneralInfo.getSiteOpenArea());
		siteMaster.setSiteTerraceArea(siteGeneralInfo.getSiteTerraceArea());
		siteMaster.setSiteBuildingNo(siteGeneralInfo.getSiteBuildingNo());
		siteMaster.setSiteEnergyAuditing(siteGeneralInfo.getSiteEnergyAuditing());
		// siteMaster.setSiteEnergyAuditingFrequency(siteGeneralInfo.getSiteEnergyAuditingFrequency());
		// siteMaster.setSiteConsumptionGoal(siteGeneralInfo.getSiteConsumptionGoal());
		siteMaster.setSiteGoalAmount(siteGeneralInfo.getSiteGoalAmount());
		siteMaster.setOrganization(organization);

		return siteMasterRepository.save(siteMaster);
	}

	public SiteElectrical saveSiteElectricalInfo(@Valid SiteElectricalInfo siteElectricalInfo, SiteMaster siteMaster) {
		log.debug("Save site electrical information");
		SiteElectrical siteElectrical = new SiteElectrical();
		siteElectrical.setSiteMaster(siteMaster);
		siteElectrical.setAccountId(siteElectricalInfo.getAccountId());
		siteElectrical.setRrNumber(siteElectricalInfo.getRrNumber());
		siteElectrical.setConnectionId(siteElectricalInfo.getConnectionId());
		siteElectrical.setConsumerCode(siteElectricalInfo.getConsumerCode());
		siteElectrical.setPhaseConnection(siteElectricalInfo.getPhaseConnection());
		siteElectrical.setConnectionLoad(siteElectricalInfo.getConnectionLoad());
		siteElectrical.setLoadUnit(siteElectricalInfo.getLoadUnit());
		siteElectrical.setTotalMeter(siteElectricalInfo.getTotalMeter());
		siteElectrical.setDataCollectionFrequency(siteElectricalInfo.getDataCollectionFrequency());
		siteElectrical.setSiteElectricalDiagram(siteElectricalInfo.getSiteElectricalDiagram());
		// siteElectrical.setFileName(siteElectricalInfo.getFileName());
		siteElectrical.setBillDate(siteElectricalInfo.getBillDate());
		siteElectrical.setContractDemand(siteElectricalInfo.getContractDemand());
		siteElectrical.setContractDemandUnit(siteElectricalInfo.getContractDemandUnit());
		siteElectrical.setContractStartDate(siteElectricalInfo.getContractStartDate());
		siteElectrical.setContractEndDate(siteElectricalInfo.getContractEndDate());
		return siteElectricalRepository.save(siteElectrical);
	}

	public SitePower saveSitePowerInfo(@Valid SitePowerInfo sitePowerInfo, SiteMaster siteMaster) {
		log.debug("Save site electrical information");
		SitePower sitePower = new SitePower();
		sitePower.setSiteMaster(siteMaster);
		sitePower.setIsDiscom(sitePowerInfo.getIsDiscom());
		sitePower.setIsSolarEnergy(sitePowerInfo.getIsSolarEnergy());
		sitePower.setIsDieselGenerated(sitePowerInfo.getIsDieselGenerated());
		sitePower.setIsWindEnergy(sitePowerInfo.getIsWindEnergy());
		sitePower.setIsBiomassEnergy(sitePowerInfo.getIsBiomassEnergy());
		sitePower.setIsHydroelectricalEnergy(sitePowerInfo.getIsHydroelectricalEnergy());
		sitePower.setIsGeothermalEnergy(sitePowerInfo.getIsGeothermalEnergy());
		sitePower.setIsHydrogenEnergy(sitePowerInfo.getIsHydrogenEnergy());
		sitePower.setIsTidalEnergy(sitePowerInfo.getIsTidalEnergy());
		sitePower.setIsWaveEnergy(sitePowerInfo.getIsWaveEnergy());
		sitePower.setIsNuclearEnergy(sitePowerInfo.getIsNuclearEnergy());
		sitePower.setIsFuelCell(sitePowerInfo.getIsFuelCell());
		// sitePower.setAllSourceMeter(sitePowerInfo.getAllSourceMeter());
		sitePower.setNonMeterSource(sitePowerInfo.getNonMeterSource());
		return sitePowerRepository.save(sitePower);

	}

	public ResultDTO getDetailsOfSite(SiteMaster siteId, Pageable pageable) {
		ResultDTO result = new ResultDTO();

		Optional<SiteMaster> site = siteMasterRepository.findBySiteId(siteId.getSiteId());
		SiteGeneralInfo siteGeneralInfo = new SiteGeneralInfo();
		siteGeneralInfo.setSiteId(siteId.getSiteId());
		siteGeneralInfo.setSiteName(siteId.getSiteName());

		List<SiteBuildingDTO> listBuildingDTO = new ArrayList<>();
		Page<SiteBuilding> buildingList = siteBuildingRepository.findAllBySiteId(siteId, pageable);
		buildingList.stream().forEach(building -> {
			SiteBuildingDTO siteBuilding = new SiteBuildingDTO();
			siteBuilding.setBuildingId(building.getSiteBuildingId());
			siteBuilding.setBuildingName(building.getBuildingName());
			List<BuildingFloorDTO> listFloorDTO = new ArrayList<>();

			building.getFloors().stream().forEach(floor -> {
				BuildingFloorDTO buildingFloor = new BuildingFloorDTO();
				buildingFloor.setBuildingFloorId(floor.getBuildingFloorId());
				buildingFloor.setBuildingFloorName(floor.getBuildingFloorName());

				List<MeterAssetDTO> listMeterAsset = new ArrayList<>();
				List<Asset> listAsset = assetRepository.findAllBySiteIdAndSiteBuildingAndBuildingFloor(siteId, building,
						floor);

				listAsset.stream().forEach(asset -> {
					MeterAssetDTO meterAssetDTO = new MeterAssetDTO();
					meterAssetDTO.setAssetId(asset.getAssetId());
					meterAssetDTO.setAssetName(asset.getAssetName());
					listMeterAsset.add(meterAssetDTO);

				});

				buildingFloor.setAssets(listMeterAsset);
				listFloorDTO.add(buildingFloor);
			});

			siteBuilding.setFloors(listFloorDTO);
			listBuildingDTO.add(siteBuilding);
		});
		siteGeneralInfo.setBuildings(listBuildingDTO);
		result.setSite(siteGeneralInfo);

		return result;
	}

	public List<SolarPanelDTO> getSolarIrredience(String startDate, String endDate, SiteMaster siteMaster)
			throws IOException, ParseException, JSONException {

		log.info("Start getSolarJsonFromServer method ");
		double lat = 0.0, lon = 0.0;

		List<SolarPanelDTO> solarPanelDTO = new ArrayList<SolarPanelDTO>();
		// Date formatter.
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("uuuuMMdd", Locale.ENGLISH);
		DateTimeFormatter monthFormatter = DateTimeFormatter.ofPattern("uuuuMM", Locale.ENGLISH);
		DateTimeFormatter monthFormatter1 = DateTimeFormatter.ofPattern("MMM-uuuu", Locale.ENGLISH);

		lon = siteMaster.getSiteLongitude();
		lat = siteMaster.getSiteLatitude();

		URL url = new URL("https://power.larc.nasa.gov/cgi-bin/v1/DataAccess.py?&request=execute&"
				+ "identifier=SinglePoint&parameters=T2M,PS,ALLSKY_SFC_SW_DWN" + "&startDate=" + startDate + "&endDate="
				+ endDate + "&userCommunity=SSE" + "&tempAverage=DAILY&outputList=JSON,ASCII&lat=" + lat + "&lon=" + lon
				+ "&user=anonymous");

		HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
		urlConnection.setRequestMethod("GET");// optional default is GET
		int responseCode = urlConnection.getResponseCode();
		System.out.println("Response Code : " + responseCode);
		BufferedReader in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();
		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		JSONObject myResponse = new JSONObject(response.toString());
		JSONArray entry = myResponse.getJSONArray("features");
		for (int i = 0; i < entry.length(); i++) {
			JSONObject jsonObject1 = (JSONObject) entry.get(i);// 2
			JSONObject jsonObject2 = (JSONObject) jsonObject1.get("properties");// 3
			JSONObject jsonObject3 = (JSONObject) jsonObject2.get("parameter");// 4
			JSONObject jsonObject3a = (JSONObject) jsonObject3.get("ALLSKY_SFC_SW_DWN");// 5

			System.out.println("All Sky Values:" + jsonObject3a);

			Map<String, Double> resultMap = new HashMap<String, Double>();
			ObjectMapper mapperObj = new ObjectMapper();

			try {
				resultMap = mapperObj.readValue(jsonObject3a.toString(), new TypeReference<HashMap<String, Double>>() {
				});

				YearMonth endMonth = YearMonth.parse(endDate, dateFormatter);
				for (YearMonth month = YearMonth.parse(startDate, dateFormatter); !month
						.isAfter(endMonth); month = month.plusMonths(1)) {

					String month1 = month.format(monthFormatter);
					List<Double> set = resultMap.entrySet().stream()
							.filter(entry1 -> entry1.getKey().startsWith(month1))
							.filter(entry1 -> entry1.getValue() >= 0.0).map(Map.Entry::getValue)
							.collect(Collectors.toList());

					OptionalDouble average = set.stream().mapToDouble(a -> a).average();

					double kwh = allMeterDataService.getMonthYearWiseKwhBySite(month1.substring(0, 4),
							month1.substring(4, 6), siteMaster.getSiteId());

					System.out.println("kwh is " + kwh);

					Integer efficiency[] = { 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21 };

					List<Double> solarResult = new ArrayList<Double>();

					List<Double> forecastResult = new ArrayList<Double>();

					for (i = 0; i < efficiency.length; i++) {
						Double solarPannelArea = kwh / (average.getAsDouble() * efficiency[i]);

						Double solarPrecisionValue = BigDecimal.valueOf(solarPannelArea)
								.setScale(2, RoundingMode.HALF_UP).doubleValue();

						solarResult.add(solarPrecisionValue);
						System.out.println(solarResult);
						Double forecastSolarEnergy = average.getAsDouble() * solarPannelArea * efficiency[i];
						Double forecastPrecisionValue = BigDecimal.valueOf(forecastSolarEnergy)
								.setScale(2, RoundingMode.HALF_UP).doubleValue();
						forecastResult.add(forecastPrecisionValue);
						System.out.println(forecastResult);
					}

					solarPanelDTO
							.add(new SolarPanelDTO(month.format(monthFormatter1), solarResult, forecastResult, kwh));
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return solarPanelDTO;
	}

	public List<SolarPanelDTO> getSolarForecast(String startDate, String endDate, SiteMaster siteMaster,
			Long solarPannelArea) throws IOException, ParseException, JSONException {

		log.info("Start getSolarJsonFromServer method ");
		double lat = 0.0, lon = 0.0;

		List<SolarPanelDTO> solarPanelDTO = new ArrayList<SolarPanelDTO>();
		// Date formatter.
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("uuuuMMdd", Locale.ENGLISH);
		DateTimeFormatter monthFormatter = DateTimeFormatter.ofPattern("uuuuMM", Locale.ENGLISH);
		DateTimeFormatter monthFormatter1 = DateTimeFormatter.ofPattern("MMM-uuuu", Locale.ENGLISH);

		lon = siteMaster.getSiteLongitude();
		lat = siteMaster.getSiteLatitude();

		URL url = new URL("https://power.larc.nasa.gov/cgi-bin/v1/DataAccess.py?&request=execute&"
				+ "identifier=SinglePoint&parameters=T2M,PS,ALLSKY_SFC_SW_DWN" + "&startDate=" + startDate + "&endDate="
				+ endDate + "&userCommunity=SSE" + "&tempAverage=DAILY&outputList=JSON,ASCII&lat=" + lat + "&lon=" + lon
				+ "&user=anonymous");

		HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
		urlConnection.setRequestMethod("GET");// optional default is GET
		int responseCode = urlConnection.getResponseCode();
		System.out.println("Response Code : " + responseCode);
		BufferedReader in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();
		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		JSONObject myResponse = new JSONObject(response.toString());
		JSONArray entry = myResponse.getJSONArray("features");
		for (int i = 0; i < entry.length(); i++) {
			JSONObject jsonObject1 = (JSONObject) entry.get(i);// 2
			JSONObject jsonObject2 = (JSONObject) jsonObject1.get("properties");// 3
			JSONObject jsonObject3 = (JSONObject) jsonObject2.get("parameter");// 4
			JSONObject jsonObject3a = (JSONObject) jsonObject3.get("ALLSKY_SFC_SW_DWN");// 5

			System.out.println("All Sky Values:" + jsonObject3a);

			Map<String, Double> resultMap = new HashMap<String, Double>();
			ObjectMapper mapperObj = new ObjectMapper();

			try {
				resultMap = mapperObj.readValue(jsonObject3a.toString(), new TypeReference<HashMap<String, Double>>() {
				});

				YearMonth endMonth = YearMonth.parse(endDate, dateFormatter);
				for (YearMonth month = YearMonth.parse(startDate, dateFormatter); !month
						.isAfter(endMonth); month = month.plusMonths(1)) {

					String month1 = month.format(monthFormatter);
					List<Double> set = resultMap.entrySet().stream()
							.filter(entry1 -> entry1.getKey().startsWith(month1))
							.filter(entry1 -> entry1.getValue() >= 0.0).map(Map.Entry::getValue)
							.collect(Collectors.toList());

					OptionalDouble average = set.stream().mapToDouble(a -> a).average();

					double kwh = allMeterDataService.getMonthYearWiseKwhBySite(month1.substring(0, 4),
							month1.substring(4, 6), siteMaster.getSiteId());

					System.out.println("kwh is " + kwh);

					Integer efficiency[] = { 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21 };

					List<Double> forecastResult = new ArrayList<Double>();
					List<Double> solarResult = new ArrayList<Double>();

					for (i = 0; i < efficiency.length; i++) {
						Double forecastSolarEnergy = average.getAsDouble() * solarPannelArea * efficiency[i];
						Double forecastPrecisionValue = BigDecimal.valueOf(forecastSolarEnergy)
								.setScale(2, RoundingMode.HALF_UP).doubleValue();
						forecastResult.add(forecastPrecisionValue);
						System.out.println(forecastSolarEnergy);
					}

					solarPanelDTO
							.add(new SolarPanelDTO(month.format(monthFormatter1), solarResult, forecastResult, kwh));
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return solarPanelDTO;

	}

}
