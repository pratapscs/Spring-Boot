package com.engraph.service;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.engraph.model.Dcudetails;
import com.engraph.model.EletricityMeter;
import com.engraph.model.MeterSetup;
import com.engraph.model.SiteMaster;
import com.engraph.repository.MeterSetupRepository;
import com.engraph.service.dto.MeterSetupDTO;

/**
 * Service class for managing Metersetup.
 */
@Service
@Transactional
public class MetersetupService {

	private static final Logger log = LoggerFactory.getLogger(MetersetupService.class);
	
	@Autowired
	private MeterSetupRepository meterSetupRepository;

	
	public MeterSetup saveMeterSetupInfo(@Valid MeterSetupDTO meterSetupDTO,EletricityMeter meter,Dcudetails dcu) {
		MeterSetup meterSetup = new MeterSetup();
		meterSetup.setDcu(dcu);
		meterSetup.setMeter(meter);
		meterSetup.setMeterCompany(meterSetupDTO.getMeterCompany());
		meterSetup.setMeterModel(meterSetupDTO.getMeterModel());
		return meterSetupRepository.save(meterSetup);
	}

	public Page<MeterSetup> getAllMeterSetupofSite(SiteMaster siteId, Pageable pageable) {
		return meterSetupRepository.findAllBySiteId(siteId, pageable);

	}

}
