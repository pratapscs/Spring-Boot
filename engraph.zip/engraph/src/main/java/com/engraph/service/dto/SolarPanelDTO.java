package com.engraph.service.dto;

import java.util.ArrayList;
import java.util.List;

public class SolarPanelDTO {
	
	String MonthYr;
	List<Double> requiredArea =  new ArrayList<>();
	List<Double> forcastEnergy =  new ArrayList<>();
	double kwh;
	
	public SolarPanelDTO(String monthYr, List<Double> requiredArea, List<Double> forcastEnergy, double kwh) {
		MonthYr = monthYr;
		this.requiredArea = requiredArea;
		this.forcastEnergy = forcastEnergy;
		this.kwh = kwh;
	}
	
	public String getMonthYr() {
		return MonthYr;
	}
	public void setMonthYr(String monthYr) {
		MonthYr = monthYr;
	}
	public List<Double> getRequiredArea() {
		return requiredArea;
	}
	public void setRequiredArea(List<Double> requiredArea) {
		this.requiredArea = requiredArea;
	}
	public List<Double> getForcastEnergy() {
		return forcastEnergy;
	}
	public void setForcastEnergy(List<Double> forcastEnergy) {
		this.forcastEnergy = forcastEnergy;
	}
	public double getKwh() {
		return kwh;
	}
	public void setKwh(double kwh) {
		this.kwh = kwh;
	}

	

}
