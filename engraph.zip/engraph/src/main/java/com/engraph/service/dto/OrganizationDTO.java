package com.engraph.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OrganizationDTO {

	@JsonProperty("orgId")
    private Long orgId;

	@JsonProperty("organizationName")
    private String orgName;

    @JsonProperty("country")
    private String country;

    @JsonProperty("state")
    private String state;
    
    @JsonProperty("city")
    private String city;

    @JsonProperty("locality")
    private String locality;
    
    @JsonProperty("streetAddress")
    private String streetAddress;
    
    @JsonProperty("buildingName")
    private String buildingName;
    
    @JsonProperty("pinCode")
    private String pinCode;
    
    @JsonProperty("CINNumber")
    private String cinNumber;
   
    @JsonProperty("PANNumber")
    private String panNumber;
    
    @JsonProperty("GSTNumber")
    private String gstNumber;
    
    @JsonProperty("facilityManagerName")
    private String facilityManagerName;
    
    @JsonProperty("facilityManagerEmail")
    private String facilityManagerEmail;
    
    @JsonProperty("mobileCountrycode")
    private String mobileCountrycode;
    
    @JsonProperty("facilityManagerMobileNumber")
    private String facilityManagerMobileNumber;

    @JsonProperty("landCountrycode")
    private String landCountrycode;
        
    @JsonProperty("landCitycode")
    private String landCitycode;
    
    @JsonProperty("landlineNumber")
    private String facilityManagerPhone;

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getCinNumber() {
		return cinNumber;
	}

	public void setCinNumber(String cinNumber) {
		this.cinNumber = cinNumber;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public String getFacilityManagerName() {
		return facilityManagerName;
	}

	public void setFacilityManagerName(String facilityManagerName) {
		this.facilityManagerName = facilityManagerName;
	}

	public String getFacilityManagerEmail() {
		return facilityManagerEmail;
	}

	public void setFacilityManagerEmail(String facilityManagerEmail) {
		this.facilityManagerEmail = facilityManagerEmail;
	}

	public String getMobileCountrycode() {
		return mobileCountrycode;
	}

	public void setMobileCountrycode(String mobileCountrycode) {
		this.mobileCountrycode = mobileCountrycode;
	}

	public String getFacilityManagerMobileNumber() {
		return facilityManagerMobileNumber;
	}

	public void setFacilityManagerMobileNumber(String facilityManagerMobileNumber) {
		this.facilityManagerMobileNumber = facilityManagerMobileNumber;
	}

	public String getLandCountrycode() {
		return landCountrycode;
	}

	public void setLandCountrycode(String landCountrycode) {
		this.landCountrycode = landCountrycode;
	}

	public String getLandCitycode() {
		return landCitycode;
	}

	public void setLandCitycode(String landCitycode) {
		this.landCitycode = landCitycode;
	}

	public String getFacilityManagerPhone() {
		return facilityManagerPhone;
	}

	public void setFacilityManagerPhone(String facilityManagerPhone) {
		this.facilityManagerPhone = facilityManagerPhone;
	}

	
}
