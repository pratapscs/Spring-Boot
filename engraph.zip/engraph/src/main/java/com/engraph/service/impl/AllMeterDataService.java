package com.engraph.service.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import com.engraph.service.dto.SiteDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import com.engraph.model.AllMeterData;
import com.engraph.model.MeterTimeBill;
import com.engraph.model.ProcessAssets;
import com.engraph.model.ProcessedData;
import com.engraph.service.IAllMeterDataService;
import com.engraph.service.dto.BillUtility;
import com.engraph.service.dto.CompareDates;
import com.engraph.service.dto.ComparisonDTO;
import com.engraph.service.dto.ComponentDTO;


@Repository
public class AllMeterDataService implements IAllMeterDataService {

	private static final Logger log = LoggerFactory.getLogger(AllMeterDataService.class);
	
	@Autowired
	@Qualifier("jdbcTemplatePhoenix")
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private NamedParameterJdbcTemplate namedJdbcTemplate;

	// Dash board - Yesterday's kWh
	@Override
	public List<AllMeterData> getYesterDayKwhData() throws Exception {

		String sql = "select SITE_ID, TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy')  AS DATE, "
				+ "COALESCE(TO_NUMBER(ALL_METER_KWH_SUM),0) AS ALL_METER_KWH_SUM  FROM ALL_METER_DATA "
				+ "WHERE DATE = TO_CHAR (current_date() -1, 'yyyy-MM-dd') order by NORMAL_TIMESTAMP DESC LIMIT 1";

		List<AllMeterData> yesterdayKwhData = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return yesterdayKwhData;
	}

	// Dashboard - today's kWh
	@Override
	public List<AllMeterData> getTodayKwhData() {

		String sql = "select TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS DATE, SITE_ID,"
				+ "COALESCE(TO_NUMBER(ALL_METER_KWH_SUM),0) AS ALL_METER_KWH_SUM from ALL_METER_DATA "
				+ "WHERE DATE = TO_CHAR(current_date(), 'yyyy-MM-dd') order by NORMAL_TIMESTAMP DESC LIMIT 1";

		List<AllMeterData> todayKwhData = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return todayKwhData;
	}

	// Dashboard - Tomorrow's kWh
	@Override
	public List<AllMeterData> getTomorrowKwhData() {

		return null;
	}

	// Dashboard - Yesterday's Co2
	@Override
	public List<AllMeterData> getYesterDayCo2Data() {

		String sql = "select SITE_ID, TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy')  AS DATE, "
				+ "COALESCE(TO_NUMBER( ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE),0) "
				+ "AS ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE FROM ALL_METER_DATA WHERE "
				+ "DATE = TO_CHAR(current_date() -1, 'yyyy-MM-dd') order by NORMAL_TIMESTAMP DESC LIMIT 1";

		List<AllMeterData> yesterdayCo2Data = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return yesterdayCo2Data;
	}

	// Dash board - Today's Co2
	@Override
	public List<AllMeterData> getTodayCo2Data() {

		String sql = "select SITE_ID,TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP,TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS DATE, "
				+ "COALESCE(TO_NUMBER( ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE),0) AS "
				+ "ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE from ALL_METER_DATA  WHERE "
				+ "DATE = TO_CHAR(current_date(), 'yyyy-MM-dd') order by NORMAL_TIMESTAMP DESC LIMIT 1";

		List<AllMeterData> todayCo2Data = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return todayCo2Data;
	}

	// Dashboard - Tomorrow's Co2
	@Override
	public List<AllMeterData> getTomorrowCo2Data() {

		return null;
	}

	// Dashboard - Top consumed assets
	@Override
	public List<ProcessedData> getTopConsumedAssets() {

		String sql = "select SITE_ID,TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS DATE, "
				+ "ASSET_NAME, COALESCE(TO_NUMBER(EXACT_KWH),0) AS HIGHEST_KWH FROM PROCESSED_TABLE "
				+ "WHERE DATE = TO_CHAR(current_date(), 'yyyy-MM-dd') order by EXACT_KWH DESC LIMIT 5";

		List<ProcessedData> consumedAssets = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return consumedAssets;
	}

	// Live Monitoring - Energy Consumption - Today - All Assets
	@Override
	public List<AllMeterData> getTodayEnergyConsumption() {

		String sql = "SELECT DISTINCT SITE_ID,TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP,TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS DATE, TIME, "
				+ "COALESCE(TO_NUMBER(ALL_METER_KWH_SUM),0) AS ALL_METER_KWH_SUM FROM ALL_METER_DATA WHERE "
				+ "DATE = TO_CHAR(current_date(), 'yyyy-MM-dd')  ORDER BY (TIME) ASC";

		List<AllMeterData> todayEC = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return todayEC;
	}

	public String getColumnName(String identifier) {
		String val = identifier;
		switch (identifier) {
		case "site":
			val = "SITE_ID";
			break;
		case "building":
			val = "SITE_BUILDING_ID";
			break;
		case "floor":
			val = "BUILDING_FLOOR_ID";
			break;
		case "asset":
			val = "ASSET_ID";
			break;
		}
		return val;
	}

	public String listOfComponents(List<ComponentDTO> filter) {

		StringBuffer sBuffer = new StringBuffer();

		for (int i = 0; i < filter.size(); i++) {
			sBuffer.append(getColumnName(filter.get(i).getType()) + " = '" + filter.get(i).getValue() + "'");
			if (i != filter.size() - 1) {
				sBuffer.append(" AND ");
			}
		}
		return "(" + sBuffer.toString() + ")";
	}

	// Live Monitoring - Energy Consumption - Today - Selected
	@Override
	public List<ProcessAssets> getTodayEnergyConsumptionByAssets(List<List<ComponentDTO>> componentDTO) {
		
		StringBuffer sBuffer = new StringBuffer();

		sBuffer.append("SELECT DISTINCT SITE_ID,SITE_NAME,TO_DATE(DATE) AS DATES, TIME, "
				+ "COALESCE(SUM(TO_NUMBER(EXACT_KWH)),0) AS EXACT_KWH,"
				+ "COALESCE(SUM(TO_NUMBER(VRY_PHASE)),0) AS VRY_PHASE, "
				+ "COALESCE(SUM(TO_NUMBER(VYB_PHASE)),0) AS VYB_PHASE, "
				+ "COALESCE(SUM(TO_NUMBER(VBR_PHASE)),0) AS VBR_PHASE,"
				+ "COALESCE(SUM(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_KW_AVG)),0) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_KW_AVG, "
				+ "COALESCE(SUM(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG)),0) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG, "
				+ "COALESCE(SUM(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG)),0) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG,COALESCE(SUM(TO_NUMBER(CARBON_EMISSION)),0) "
				+ "AS CO2_EMISSION FROM PROCESSED_TABLE "
				+ "WHERE DATE = TO_CHAR(current_date(), 'yyyy-MM-dd') AND ");

		StringBuffer sBuffer2 = new StringBuffer();

		for (int i = 0; i < componentDTO.size(); i++) {
			sBuffer2.append(listOfComponents(componentDTO.get(i)));
			if (i != componentDTO.size() - 1) {
				sBuffer2.append(" OR ");
			}
		}
		
		sBuffer.append("(" + sBuffer2.toString() + ")");
		sBuffer.append(" GROUP BY SITE_ID, SITE_NAME ,DATES, TIME ORDER BY (TIME) ASC ");

		List<ProcessAssets> toDay = jdbcTemplate.query(sBuffer.toString(),
				new BeanPropertyRowMapper<ProcessAssets>(ProcessAssets.class));

		return toDay;
	}

	// Live Monitoring - Energy Consumption - This Week - All Assets
	@Override
	public List<AllMeterData> getThisWeekEnergyConsumption() {

		String sql = "SELECT DISTINCT SITE_ID, WEEK, WEEKDAY, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS WEEK_DATE, MAX(COALESCE(TO_NUMBER(DAILY_ALL_METER_KWH_SUM),0)) "
				+ "AS DAILY_ALL_METER_KWH_SUM FROM ALL_METER_DATA WHERE TO_NUMBER (WEEK) = WEEK(now()) "
				+ "GROUP BY SITE_ID,DATE,WEEK, WEEKDAY  ORDER BY (DATE) ASC";

	List<AllMeterData> thisWeekEC = jdbcTemplate.query(sql,
					new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
	
	return thisWeekEC;
	}

	// Live Monitoring - Energy Consumption - This Week - Selected Assets
	@Override
	public List<ProcessAssets> getThisWeekEnergyConsumptionByAssets(List<List<ComponentDTO>> componentDTO) {
		
		StringBuffer sBuffer = new StringBuffer();

		sBuffer.append("SELECT DISTINCT SITE_ID,SITE_NAME,TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS WEEK_DATE, "
				+ "WEEK, WEEKDAY, MAX(COALESCE(TO_NUMBER(INDIVIDUAL_METER_DAILY_KWH_SUM),0)) AS "
				+ "INDIVIDUAL_METER_DAILY_KWH_SUM, MAX(COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_VRY_VOLTAGE_AVG),0)) "
				+ "AS DAILY_INDIVIDUAL_METER_VRY_VOLTAGE_AVG,"
				+ "MAX(COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_VYB_VOLTAGE_AVG),0)) AS "
				+ "DAILY_INDIVIDUAL_METER_VYB_VOLTAGE_AVG,"
				+ "MAX(COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_VBR_VOLTAGE_AVG),0)) AS "
				+ "DAILY_INDIVIDUAL_METER_VBR_VOLTAGE_AVG,"
				+ "MAX(COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_KW_AVG),0)) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_KW_AVG, "
				+ "MAX(COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG),0)) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG, "
				+ "MAX(COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG),0)) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG,"
				+ "MAX(COALESCE(TO_NUMBER(DAILY_METER_WISE_CARBON_EMISSION_SUM),0)) AS "
				+ "DAILY_METER_WISE_CO2_SUM FROM PROCESSED_TABLE WHERE TO_NUMBER (WEEK) = WEEK(now()) AND ");

		StringBuffer sBuffer2 = new StringBuffer();

		for (int i = 0; i < componentDTO.size(); i++) {
			sBuffer2.append(listOfComponents(componentDTO.get(i)));
			if (i != componentDTO.size() - 1) {
				sBuffer2.append(" OR ");
			}
		}
		
		sBuffer.append("(" + sBuffer2.toString() + ")");
		sBuffer.append(" GROUP BY SITE_ID,SITE_NAME,DATE,WEEK,WEEKDAY ORDER BY (DATE) ASC ");

		List<ProcessAssets> thisWeek = jdbcTemplate.query(sBuffer.toString(),
				new BeanPropertyRowMapper<ProcessAssets>(ProcessAssets.class));

		return thisWeek;
	}

	// Live Monitoring - Energy Consumption - This Month - All Assets
	@Override
	public List<AllMeterData> getThisMonthEnergyConsumption() {

		String sql = "SELECT DISTINCT SITE_ID,DATE,MONTH, MAX(COALESCE(TO_NUMBER(DAILY_ALL_METER_KWH_SUM),0)) "
				+ "AS MONTHLY_KWH FROM ALL_METER_DATA WHERE TO_NUMBER (MONTH) = MONTH(now()) "
				+ "GROUP BY SITE_ID, DATE, MONTH ORDER BY (DATE) ASC";

		List<AllMeterData> thisMonthEC = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return thisMonthEC;
	}

	// Live Monitoring - Energy Consumption - This Month - Selected Assets
	@Override
	public List<ProcessAssets> getThisMonthEnergyConsumptionByAssets(List<List<ComponentDTO>> componentDTO) {
		
		StringBuffer sBuffer = new StringBuffer();

		sBuffer.append("SELECT DISTINCT SITE_ID,SITE_NAME,TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS MONTH_DATE, "
				+ "MONTH, MAX(COALESCE(TO_NUMBER(INDIVIDUAL_METER_DAILY_KWH_SUM),0)) AS "
				+ "INDIVIDUAL_METER_DAILY_KWH_SUM,"
				+ "MAX(COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_VRY_VOLTAGE_AVG),0)) AS "
				+ "DAILY_INDIVIDUAL_METER_VRY_VOLTAGE_AVG, "
				+ "MAX(COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_VYB_VOLTAGE_AVG),0)) AS "
				+ "DAILY_INDIVIDUAL_METER_VYB_VOLTAGE_AVG, "
				+ "MAX(COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_VBR_VOLTAGE_AVG ),0)) AS "
				+ "DAILY_INDIVIDUAL_METER_VBR_VOLTAGE_AVG,"
				+ "MAX(COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_KW_AVG),0)) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_KW_AVG, "
				+ "MAX(COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG),0)) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG, "
				+ "MAX(COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG),0)) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG, "
				+ "MAX(COALESCE(TO_NUMBER(DAILY_METER_WISE_CARBON_EMISSION_SUM),0)) AS "
				+ "DAILY_METER_WISE_CO2_SUM FROM PROCESSED_TABLE WHERE TO_NUMBER (MONTH) = MONTH(now()) AND ");

		StringBuffer sBuffer2 = new StringBuffer();

		for (int i = 0; i < componentDTO.size(); i++) {
			sBuffer2.append(listOfComponents(componentDTO.get(i)));
			if (i != componentDTO.size() - 1) {
				sBuffer2.append(" OR ");
			}
		}
		
		sBuffer.append("(" + sBuffer2.toString() + ")");
		sBuffer.append(" GROUP BY SITE_ID,SITE_NAME,MONTH_DATE, MONTH ORDER BY (MONTH_DATE) ASC");

		List<ProcessAssets> thisMonth = jdbcTemplate.query(sBuffer.toString(),
				new BeanPropertyRowMapper<ProcessAssets>(ProcessAssets.class));

		return thisMonth;		
	}

	
	@Override
	public List<ProcessAssets> getKwhAssets(List<List<ComponentDTO>> componentDTO, String startDate, String endDate) {
		
		StringBuffer sBuffer = new StringBuffer();

		sBuffer.append("SELECT DISTINCT SITE_ID, SITE_NAME, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS HDATE, "
				+ "COALESCE(SUM(TO_NUMBER(INDIVIDUAL_METER_DAILY_KWH_SUM)),0) AS "
				+ "INDIVIDUAL_METER_DAILY_KWH_SUM,COALESCE(SUM(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_KW_AVG)),0) "
				+ "AS DAILY_INDIVIDUAL_METER_TOTAL_KW_AVG,"
				+ "COALESCE(SUM(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG)),0) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG,"
				+ "COALESCE(SUM(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG)),0) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG,"
				+ "COALESCE(SUM(TO_NUMBER(DAILY_INDIVIDUAL_METER_LINE_TO_LINE_VOLTAGE_AVG)),0) AS "
				+ "DAILY_INDIVIDUAL_METER_LINE_TO_LINE_VOLTAGE_AVG,"
				+ "COALESCE(SUM(TO_NUMBER(DAILY_METER_WISE_CARBON_EMISSION_SUM)),0) AS "
				+ "DAILY_METER_WISE_CO2_SUM FROM PROCESSED_TABLE WHERE "
				+ "TO_DATE (DATE) >= TO_DATE (\'" + startDate + "\')  AND TO_DATE (DATE) <= TO_DATE (\'" + endDate + "\') AND ");

		StringBuffer sBuffer2 = new StringBuffer();

		for (int i = 0; i < componentDTO.size(); i++) {
			sBuffer2.append(listOfComponents(componentDTO.get(i)));
			if (i != componentDTO.size() - 1) {
				sBuffer2.append(" OR ");
			}
		}
		
		sBuffer.append("(" + sBuffer2.toString() + ")");
		sBuffer.append(" GROUP BY SITE_ID,SITE_NAME,HDATE ORDER BY (HDATE) ASC");

		List<ProcessAssets> kwhData = jdbcTemplate.query(sBuffer.toString(),
				new BeanPropertyRowMapper<ProcessAssets>(ProcessAssets.class));

		return kwhData;	
	}
	
	
	/*
	 * @Override public List<ProcessAssets> getKwAssets(List<List<ComponentDTO>>
	 * componentDTO, String startDate, String endDate) {
	 * 
	 * 
	 * return processedData; }
	 * 
	 * @Override public List<ProcessedData> getKvaAssets(Integer[] assets, String
	 * startDate, String endDate) { List<Integer> selectedAssets =
	 * Arrays.asList(assets);
	 * 
	 * MapSqlParameterSource parameters = new MapSqlParameterSource();
	 * parameters.addValue("assetId", selectedAssets);
	 * 
	 * String sql =
	 * "SELECT DISTINCT SITE_ID, ASSET_ID, ASSET_NAME, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS HDATE, TIME, WEEK, "
	 * +
	 * "WEEKDAY, MONTH, COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG),0) "
	 * + "AS DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG FROM PROCESSED_TABLE " +
	 * "WHERE TO_NUMBER (ASSET_ID) IN (:assetId) AND TO_DATE (DATE) >= TO_DATE (\'"
	 * + startDate + "\')  AND" + " TO_DATE (DATE) <= TO_DATE (\'" + endDate +
	 * "\') AND (DATE,TIME) IN " +
	 * "(SELECT DATE, MAX(TIME) FROM PROCESSED_TABLE GROUP BY SITE_ID,DATE) " +
	 * "ORDER BY TO_NUMBER(MONTH) ASC, TO_DATE(HDATE) ASC, TIME ASC";
	 * 
	 * List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
	 * new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
	 * 
	 * return processedData; }
	 * 
	 * @Override public List<ProcessedData> getPfAssets(Integer[] assets, String
	 * startDate, String endDate) { List<Integer> selectedAssets =
	 * Arrays.asList(assets);
	 * 
	 * MapSqlParameterSource parameters = new MapSqlParameterSource();
	 * parameters.addValue("assetId", selectedAssets);
	 * 
	 * String sql =
	 * "SELECT DISTINCT SITE_ID, ASSET_ID,ASSET_NAME, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS HDATE, "
	 * +
	 * "TIME, WEEK, WEEKDAY, MONTH, COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG),0) "
	 * + "AS DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG FROM PROCESSED_TABLE WHERE " +
	 * "TO_NUMBER (ASSET_ID) IN (:assetId) AND TO_DATE (DATE) >= TO_DATE (\'" +
	 * startDate + "\')  AND " + "TO_DATE (DATE) <= TO_DATE (\'" + endDate +
	 * "\') AND (DATE,TIME) IN (SELECT DATE, MAX(TIME) " +
	 * "FROM PROCESSED_TABLE GROUP BY SITE_ID,DATE) ORDER BY TO_NUMBER(MONTH) ASC, TO_DATE(HDATE) ASC, TIME ASC"
	 * ;
	 * 
	 * List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
	 * new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
	 * 
	 * return processedData; }
	 * 
	 * @Override public List<ProcessedData> getVoltageAssets(Integer[] assets,
	 * String startDate, String endDate) { List<Integer> selectedAssets =
	 * Arrays.asList(assets);
	 * 
	 * MapSqlParameterSource parameters = new MapSqlParameterSource();
	 * parameters.addValue("assetId", selectedAssets);
	 * 
	 * String sql =
	 * "SELECT DISTINCT SITE_ID, ASSET_ID,ASSET_NAME,TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS HDATE, "
	 * +
	 * "TIME, WEEK, WEEKDAY, MONTH, COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_LINE_TO_LINE_VOLTAGE_AVG),0) "
	 * + "AS DAILY_INDIVIDUAL_METER_LINE_TO_LINE_VOLTAGE_AVG FROM PROCESSED_TABLE "
	 * +
	 * "WHERE TO_NUMBER (ASSET_ID) IN  (:assetId) AND TO_DATE (DATE) >= TO_DATE (\'"
	 * + startDate + "\')  AND " + "TO_DATE (DATE) <= TO_DATE (\'" + endDate +
	 * "\') AND (DATE,TIME) IN (SELECT DATE, MAX(TIME) " +
	 * "FROM PROCESSED_TABLE GROUP BY SITE_ID,DATE)" +
	 * "ORDER BY TO_NUMBER(MONTH) ASC, TO_DATE(HDATE) ASC, TIME ASC";
	 * 
	 * List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
	 * new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
	 * 
	 * return processedData; }
	 * 
	 * @Override public List<ProcessedData> getCo2Assets(Integer[] assets, String
	 * startDate, String endDate) { List<Integer> selectedAssets =
	 * Arrays.asList(assets);
	 * 
	 * MapSqlParameterSource parameters = new MapSqlParameterSource();
	 * parameters.addValue("assetId", selectedAssets);
	 * 
	 * String sql =
	 * "SELECT DISTINCT SITE_ID, ASSET_ID, ASSET_NAME,TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS HDATE, "
	 * +
	 * "TIME, WEEK, WEEKDAY, MONTH, COALESCE(TO_NUMBER(DAILY_METER_WISE_CARBON_EMISSION_SUM),0) "
	 * + "AS DAILY_METER_WISE_CO2_SUM FROM PROCESSED_TABLE WHERE " +
	 * "TO_NUMBER (ASSET_ID) IN (:assetId) AND TO_DATE (DATE) >= TO_DATE (\'" +
	 * startDate + "\')  AND " + "TO_DATE (DATE) <= TO_DATE (\'" + endDate +
	 * "\') AND (DATE,TIME) IN (SELECT DATE, MAX(TIME) " +
	 * "FROM PROCESSED_TABLE GROUP BY SITE_ID,DATE) ORDER BY TO_NUMBER(MONTH) ASC, TO_DATE(HDATE) ASC, TIME ASC"
	 * ;
	 * 
	 * List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
	 * new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
	 * 
	 * return processedData; }
	 */
	
	// Live Monitoring - Power Quality - Today - All Assets
	@Override
	public List<AllMeterData> getTodayPowerQuality() {

		String sql = "SELECT DISTINCT SITE_ID, TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, TO_DATE(DATE) AS DATE, TIME, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VRY_PHASE_AVG),0) AS ALL_METER_VRY_PHASE_AVG, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VYB_PHASE_AVG),0) AS ALL_METER_VYB_PHASE_AVG, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VBR_PHASE_AVG ),0) AS ALL_METER_VBR_PHASE_AVG "
				+ "FROM ALL_METER_DATA WHERE DATE = TO_CHAR (current_date(), 'yyyy-MM-dd') ORDER BY (TIME) ASC";

		List<AllMeterData> toDayPQ = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return toDayPQ;
	}

	// Live Monitoring - Power Quality - Today - Selected Assets
	@Override
	public List<ProcessedData> getTodayPowerQualityByAssets(SiteDTO[] site) {

		String query = null;

		List<Integer> selectedAssets = new ArrayList<Integer>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		if (site[0].getType().equalsIgnoreCase("site")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("building")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("floor")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("asset")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		}

		List<ProcessedData> processedData = namedJdbcTemplate.query(query, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return processedData;

	}

	// Live Monitoring - Power Quality - This Week - All Assets
	@Override
	public List<AllMeterData> getThisWeekPowerQuality() {

		String sql = "SELECT DISTINCT SITE_ID,TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS DATE, TIME, WEEK, WEEKDAY, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VRY_PHASE_AVG),0) AS ALL_METER_VRY_PHASE_AVG, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VYB_PHASE_AVG),0) AS ALL_METER_VYB_PHASE_AVG, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VBR_PHASE_AVG),0) AS ALL_METER_VBR_PHASE_AVG "
				+ "FROM ALL_METER_DATA WHERE TO_NUMBER (WEEK) = WEEK(now()) AND (DATE,TIME) "
				+ "IN (SELECT DATE,MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";

		List<AllMeterData> thisWeekPQ = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return thisWeekPQ;
	}

	// Live Monitoring - Power Quality - This Week - Selected Assets
	@Override
	public List<ProcessedData> getThisWeekPowerQualityByAssets(SiteDTO[] site) {

		String query = null;

		List<Integer> selectedAssets = new ArrayList<Integer>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		if (site[0].getType().equalsIgnoreCase("site")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("building")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("floor")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("asset")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		}

		List<ProcessedData> processedData = namedJdbcTemplate.query(query, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return processedData;

	}

	// Live Monitoring - Power Quality - This Month - All Assets
	@Override
	public List<AllMeterData> getThisMonthPowerQuality() {

		String sql = "SELECT DISTINCT SITE_ID,TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS DATE, TIME, WEEK, WEEKDAY, MONTH, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VRY_PHASE_AVG),0) AS ALL_METER_VRY_PHASE_AVG, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VYB_PHASE_AVG),0) AS ALL_METER_VYB_PHASE_AVG, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VBR_PHASE_AVG),0) AS ALL_METER_VBR_PHASE_AVG "
				+ "FROM ALL_METER_DATA WHERE TO_NUMBER (MONTH) = MONTH(now()) AND (DATE,TIME) "
				+ "IN (SELECT DATE,MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";

		List<AllMeterData> thisMonthPQ = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return thisMonthPQ;
	}

	// Live Monitoring - Power Quality - This Month - Selected Assets
	@Override
	public List<ProcessedData> getThisMonthPowerQualityByAssets(SiteDTO[] site) {

		String query = null;

		List<Integer> selectedAssets = new ArrayList<Integer>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		if (site[0].getType().equalsIgnoreCase("site")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("building")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("floor")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("asset")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		}

		List<ProcessedData> processedData = namedJdbcTemplate.query(query, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return processedData;

	}

	// Live Monitoring - Load Profile - Today - All Assets
	@Override
	public List<AllMeterData> getTodayLoadProfile() {

		String sql = "SELECT DISTINCT SITE_ID, TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, TO_DATE(DATE) AS DATE, TIME, "
				+ "COALESCE(TO_NUMBER(ALL_METER_TOTAL_KW_AVG),0) AS ALL_METER_TOTAL_KW_AVG, "
				+ "COALESCE(TO_NUMBER(ALL_METER_KVA_AVG),0) AS ALL_METER_KVA_AVG, "
				+ "COALESCE(TO_NUMBER(ALL_METER_PF_INST_AVG),0) AS ALL_METER_PF_INST_AVG "
				+ "FROM ALL_METER_DATA WHERE  DATE = TO_CHAR (current_date(), 'yyyy-MM-dd')  ORDER BY (TIME) ASC";

		List<AllMeterData> todayLP = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return todayLP;
	}

	// Live Monitoring - Load Profile - Today - Selected Assets
	@Override
	public List<ProcessedData> getTodayLoadProfileByAssets(SiteDTO[] site) {

		String query = null;

		List<Integer> selectedAssets = new ArrayList<Integer>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		if (site[0].getType().equalsIgnoreCase("site")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("building")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("floor")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("asset")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		}

		List<ProcessedData> processedData = namedJdbcTemplate.query(query, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return processedData;

	}

	// Live Monitoring - Load Profile - This Week - All Assets
	@Override
	public List<AllMeterData> getThisWeekLoadProfile() {

		String sql = "SELECT DISTINCT SITE_ID, DATE, TIME, WEEK, WEEKDAY, "
				+ "COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KW_AVG),0) AS DAILY_ALL_METER_TOTAL_KW_AVG, "
				+ "COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KVA_AVG),0) AS DAILY_ALL_METER_TOTAL_KVA_AVG, C"
				+ "OALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_PF_AVG),0) AS DAILY_ALL_METER_TOTAL_PF_AVG "
				+ "FROM ALL_METER_DATA WHERE TO_NUMBER (WEEK) = WEEK(now()) AND (DATE,TIME) "
				+ "IN (SELECT DATE,MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";

		List<AllMeterData> thisWeekLP = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return thisWeekLP;
	}

	// Live Monitoring - Load Profile - This Week - Selected Assets
	@Override
	public List<ProcessedData> getThisWeekLoadProfileByAssets(SiteDTO[] site) {

		String query = null;

		List<Integer> selectedAssets = new ArrayList<Integer>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		if (site[0].getType().equalsIgnoreCase("site")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("building")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("floor")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("asset")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		}

		List<ProcessedData> processedData = namedJdbcTemplate.query(query, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return processedData;

	}

	// Live Monitoring - Load Profile - This Month All Assets
	@Override
	public List<AllMeterData> getThisMonthLoadProfile() {
		String sql = "SELECT DISTINCT SITE_ID, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy')  AS DATE, TIME, WEEK, WEEKDAY, MONTH, "
				+ "COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KW_AVG),0) AS DAILY_ALL_METER_TOTAL_KW_AVG, "
				+ "COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KVA_AVG),0) AS DAILY_ALL_METER_TOTAL_KVA_AVG, "
				+ "COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_PF_AVG),0) AS DAILY_ALL_METER_TOTAL_PF_AVG "
				+ "FROM ALL_METER_DATA WHERE TO_NUMBER (MONTH) = MONTH(now()) AND (DATE,TIME) "
				+ "IN (SELECT DATE,MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";

		List<AllMeterData> thisMonthLP = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return thisMonthLP;
	}

	// Live Monitoring - Load Profile - This Month - Selected Assets
	@Override
	public List<ProcessedData> getThisMonthLoadProfileByAssets(SiteDTO[] site) {
		String query = null;

		List<Integer> selectedAssets = new ArrayList<Integer>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		if (site[0].getType().equalsIgnoreCase("site")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("building")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("floor")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("asset")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		}

		List<ProcessedData> processedData = namedJdbcTemplate.query(query, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return processedData;

	}

	// Co2 Emission - Today - All Assets
	@Override
	public List<AllMeterData> getTodayCo2Emission() {

		String sql = "SELECT DISTINCT SITE_ID,TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, TO_DATE(DATE) AS DATE, TIME, "
				+ "COALESCE(TO_NUMBER(ALL_METER_CARBON_EMISSION_SUM),0) AS ALL_METER_CARBON_EMISSION_SUM "
				+ "FROM ALL_METER_DATA WHERE DATE = TO_CHAR (current_date(), 'yyyy-MM-dd') ORDER BY (TIME) ASC";

		List<AllMeterData> todayCo2 = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return todayCo2;
	}

	// Co2 Emission - Today - Selected Assets
	@Override
	public List<ProcessedData> getTodayCo2EmissionByAssets(SiteDTO[] site) {

		String query = null;

		List<Integer> selectedAssets = new ArrayList<Integer>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		if (site[0].getType().equalsIgnoreCase("site")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("building")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("floor")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("asset")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		}

		List<ProcessedData> processedData = namedJdbcTemplate.query(query, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return processedData;

	}

	// Co2 Emission - This Week - All Assets
	@Override
	public List<AllMeterData> getThisWeekCo2Emission() {

		String sql = "SELECT DISTINCT SITE_ID, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS DATE, TIME, WEEK, WEEKDAY, "
				+ "COALESCE(TO_NUMBER(ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE),0) AS "
				+ "ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE FROM ALL_METER_DATA WHERE "
				+ "TO_NUMBER (WEEK) = WEEK(now()) AND (DATE,TIME) IN (SELECT DATE,MAX(TIME) "
				+ "FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";

		List<AllMeterData> thisWeekCo2 = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return thisWeekCo2;
	}

	// Co2 Emission - This Week - Selected Assets
	@Override
	public List<ProcessedData> getThisWeekCo2EmissionByAssets(SiteDTO[] site) {

		String query = null;

		List<Integer> selectedAssets = new ArrayList<Integer>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		if (site[0].getType().equalsIgnoreCase("site")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("building")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("floor")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("asset")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		}

		List<ProcessedData> processedData = namedJdbcTemplate.query(query, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return processedData;

	}

	// Co2 Emission - This Month - All Assets
	@Override
	public List<AllMeterData> getThisMonthCo2Emission() {
		String sql = "SELECT DISTINCT SITE_ID, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS DATE, TIME, WEEK, WEEKDAY, MONTH, "
				+ "COALESCE(TO_NUMBER(ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE),0) "
				+ "AS ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE FROM ALL_METER_DATA "
				+ "WHERE TO_NUMBER (MONTH) = MONTH(now()) AND (DATE,TIME) IN (SELECT DATE,MAX(TIME) "
				+ "FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";
		List<AllMeterData> thisMonthCo2 = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return thisMonthCo2;
	}

	// Co2 Emission - This Month - Selected assets
	@Override
	public List<ProcessedData> getThisMonthCo2EmissionByAssets(SiteDTO[] site) {

		String query = null;

		List<Integer> selectedAssets = new ArrayList<Integer>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		if (site[0].getType().equalsIgnoreCase("site")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("building")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("floor")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		} else if (site[0].getType().equalsIgnoreCase("asset")) {
			selectedAssets = Arrays.asList(site[0].getSiteData());
			parameters.addValue("ids", selectedAssets);
			query = "";
		}

		List<ProcessedData> processedData = namedJdbcTemplate.query(query, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return processedData;

	}

	// Co2 Emission - Highest Emitters - Today
	@Override
	public List<ProcessedData> getTodayHighestEmitters() {

		String sql = "SELECT DISTINCT SITE_ID,ASSET_ID, SITE_NAME, ASSET_NAME, UNIX_TIMESTAMP,TO_DATE(NORMAL_TIMESTAMP) AS "
				+ "TIMESTAMP, TO_DATE(DATE) AS DATE, TIME, COALESCE(TO_NUMBER(CARBON_EMISSION),0) "
				+ "AS CO2_EMISSION FROM PROCESSED_TABLE WHERE DATE = TO_CHAR (current_date(), 'yyyy-MM-dd') "
				+ "ORDER BY CO2_EMISSION DESC LIMIT 5";

		List<ProcessedData> highestEmitters = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return highestEmitters;
	}

	// Co2 Emission - Highest Emitters - This Week
	@Override
	public List<ProcessedData> getThisWeekHighestEmitters() {

		String sql = "SELECT DISTINCT SITE_ID, ASSET_ID,SITE_NAME, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS DATE, ASSET_NAME, "
				+ "WEEK, WEEKDAY, COALESCE(TO_NUMBER(DAILY_METER_WISE_CARBON_EMISSION_SUM),0) "
				+ "AS DAILY_METER_WISE_CO2_SUM FROM PROCESSED_TABLE WHERE TO_NUMBER (WEEK) = WEEK(now()) "
				+ "AND (DATE,TIME) IN (SELECT DATE, MAX(TIME) FROM PROCESSED_TABLE "
				+ "GROUP BY SITE_ID,DATE) ORDER BY DAILY_METER_WISE_CO2_SUM DESC LIMIT 5";

		List<ProcessedData> highestEmitters = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return highestEmitters;
	}

	// Co2 Emission - Highest Emitters - This Month
	@Override
	public List<ProcessedData> getThisMonthHighestEmitters() {

		String sql = "SELECT DISTINCT SITE_ID,ASSET_ID, SITE_NAME,TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS DATE, ASSET_NAME, "
				+ "WEEK, WEEKDAY, COALESCE(TO_NUMBER(DAILY_METER_WISE_CARBON_EMISSION_SUM),0) "
				+ "AS DAILY_METER_WISE_CO2_SUM FROM PROCESSED_TABLE WHERE TO_NUMBER (MONTH) = MONTH(now()) "
				+ "AND (DATE,TIME) IN (SELECT DATE, MAX(TIME) FROM PROCESSED_TABLE GROUP BY SITE_ID,DATE) "
				+ "ORDER BY DAILY_METER_WISE_CO2_SUM DESC LIMIT 5";

		List<ProcessedData> highestEmitters = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return highestEmitters;
	}

	// Co2 Emission - Greenest Units - Today
	@Override
	public List<ProcessedData> getTodayGreenestUnits() {
		String sql = "select DISTINCT SITE_ID, ASSET_ID,SITE_NAME, BUILDING_NAME || '-' || ASSET_NAME "
				+ "AS ASSET_NAME, UNIX_TIMESTAMP,TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, TO_DATE(DATE) "
				+ "AS DATE, TIME, COALESCE(TO_NUMBER(CARBON_EMISSION),0) AS CO2_EMISSION"
				+ " FROM PROCESSED_TABLE WHERE DATE = TO_CHAR (current_date(), 'yyyy-MM-dd')"
				+ " ORDER BY CO2_EMISSION DESC LIMIT 5";

		List<ProcessedData> greenestEmitters = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return greenestEmitters;
	}

	// Co2 Emission - Greenest Units - this Week
	public List<ProcessedData> getThisWeekGreenestUnits() {
		String sql = "SELECT DISTINCT SITE_ID, ASSET_ID,SITE_NAME, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS DATE, ASSET_NAME, "
				+ "WEEK, WEEKDAY, COALESCE(TO_NUMBER(DAILY_METER_WISE_CARBON_EMISSION_SUM),0) "
				+ "AS DAILY_METER_WISE_CO2_SUM FROM PROCESSED_TABLE WHERE TO_NUMBER (WEEK) = WEEK(now()) "
				+ "AND (DATE,TIME) IN (SELECT DATE, MAX(TIME) FROM PROCESSED_TABLE GROUP BY SITE_ID,DATE)"
				+ "ORDER BY DAILY_METER_WISE_CO2_SUM ASC LIMIT 5";

		List<ProcessedData> greenestEmitters = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return greenestEmitters;
	}

	// Co2 Emission - Greenest Units -this month
	public List<ProcessedData> getThisMonthGreenestUnits() {
		String sql = "SELECT DISTINCT SITE_ID,ASSET_ID, SITE_NAME, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS DATE, ASSET_NAME, WEEK, "
				+ "WEEKDAY, COALESCE(TO_NUMBER(DAILY_METER_WISE_CARBON_EMISSION_SUM),0) AS "
				+ "DAILY_METER_WISE_CO2_SUM FROM PROCESSED_TABLE WHERE TO_NUMBER (MONTH) = MONTH(now()) "
				+ "AND (DATE,TIME) IN (SELECT DATE, MAX(TIME) FROM PROCESSED_TABLE GROUP BY SITE_ID,DATE) "
				+ "ORDER BY DAILY_METER_WISE_CO2_SUM ASC LIMIT 5";

		List<ProcessedData> greenestEmitters = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return greenestEmitters;
	}

	// Historical Data - kWh - selected assets
	@Override
	public List<AllMeterData> getKwhData(String startDate, String endDate) {

		String sql = "SELECT DISTINCT SITE_ID, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS HDATE, TIME, WEEK, WEEKDAY, "
				+ "MONTH, COALESCE(TO_NUMBER(DAILY_ALL_METER_KWH_SUM),0) AS DAILY_ALL_METER_KWH_SUM "
				+ "FROM ALL_METER_DATA WHERE TO_DATE (DATE) >= TO_DATE (\'" + startDate + "\')  AND "
				+ "TO_DATE (DATE) <= TO_DATE (\'" + endDate + "\') AND (DATE,TIME)  IN "
				+ "(SELECT DATE, MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE) ORDER BY TO_NUMBER(MONTH) ASC, "
				+ "TO_DATE(HDATE) ASC, TIME ASC";

		List<AllMeterData> allMeterData = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return allMeterData;
	}

	/*
	 * @Override public List<ProcessedData> getKwhAssets(Integer[] assets, String
	 * startDate, String endDate) {
	 * 
	 * List<Integer> selectedAssets = Arrays.asList(assets);
	 * 
	 * MapSqlParameterSource parameters = new MapSqlParameterSource();
	 * parameters.addValue("assetId", selectedAssets);
	 * 
	 * String sql =
	 * "SELECT DISTINCT SITE_ID, ASSET_ID,ASSET_NAME,TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS HDATE, "
	 * +
	 * "TIME, WEEK, WEEKDAY, MONTH, COALESCE(TO_NUMBER(INDIVIDUAL_METER_DAILY_KWH_SUM),0) "
	 * +
	 * "AS INDIVIDUAL_METER_DAILY_KWH_SUM FROM PROCESSED_TABLE WHERE TO_NUMBER (ASSET_ID) IN (:assetId) AND "
	 * + "TO_DATE (DATE) >= TO_DATE (\'" + startDate +
	 * "\')  AND TO_DATE (DATE) <= TO_DATE ( \'" + endDate + "\') " +
	 * "AND (DATE,TIME) IN (SELECT DATE, MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)"
	 * + "ORDER BY TO_NUMBER(MONTH) ASC, TO_DATE(HDATE) ASC, TIME ASC";
	 * 
	 * List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
	 * new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
	 * 
	 * return processedData; }
	 */

	// Historical Data - kW - selected assets
	@Override
	public List<AllMeterData> getKwData(String startDate, String endDate) {

		String sql = "SELECT DISTINCT SITE_ID, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS HDATE, TIME, WEEK, WEEKDAY, "
				+ "MONTH, COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KW_AVG),0) AS DAILY_ALL_METER_TOTAL_KW_AVG "
				+ "FROM ALL_METER_DATA WHERE TO_DATE (DATE) >= TO_DATE (\'" + startDate + "\')  AND "
				+ "TO_DATE (DATE) <= TO_DATE (\'" + endDate + "\') AND (DATE,TIME) IN "
				+ "(SELECT DATE, MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE) ORDER BY TO_NUMBER(MONTH) ASC, TO_DATE(HDATE) ASC, "
				+ "TIME ASC";

		List<AllMeterData> allMeterData = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return allMeterData;
	}


	// Historical Data - kVA - selected assets
	@Override
	public List<AllMeterData> getKvaData(String startDate, String endDate) {

		String sql = "SELECT DISTINCT SITE_ID, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS HDATE, TIME, WEEK, WEEKDAY, "
				+ "MONTH, COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KVA_AVG),0) AS DAILY_ALL_METER_TOTAL_KVA_AVG"
				+ " FROM ALL_METER_DATA WHERE TO_DATE (DATE) >= TO_DATE (\'" + startDate + "\')  AND "
				+ "TO_DATE (DATE) <= TO_DATE (\'" + endDate + "\') AND (DATE,TIME) IN (SELECT DATE, MAX(TIME) "
				+ "FROM ALL_METER_DATA GROUP BY SITE_ID,DATE) ORDER BY TO_NUMBER(MONTH) ASC, TO_DATE(HDATE) ASC, TIME ASC";

		List<AllMeterData> allMeterData = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return allMeterData;
	}

	

	// Historical Data - PF - selected assets
	@Override
	public List<AllMeterData> getPfData(String startDate, String endDate) {

		String sql = "SELECT DISTINCT SITE_ID, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS HDATE, TIME, WEEK, WEEKDAY, "
				+ "MONTH, COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_PF_AVG),0) AS DAILY_ALL_METER_TOTAL_PF_AVG "
				+ "FROM ALL_METER_DATA WHERE TO_DATE (DATE) >= TO_DATE (\'" + startDate + "\')  AND "
				+ "TO_DATE (DATE) <= TO_DATE (\'" + endDate + "\') AND (DATE,TIME) IN (SELECT DATE, MAX(TIME) "
				+ "FROM ALL_METER_DATA GROUP BY SITE_ID,DATE) ORDER BY TO_NUMBER(MONTH) ASC, TO_DATE(HDATE) ASC, TIME ASC";

		List<AllMeterData> allMeterData = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return allMeterData;
	}

	

	// Historical Data - voltage - selected assets
	@Override
	public List<AllMeterData> getVoltageData(String startDate, String endDate) {

		String sql = "SELECT DISTINCT SITE_ID, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS HDATE, TIME, WEEK, "
				+ "WEEKDAY, MONTH, COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_LL_VOLTAGE_AVG),0) AS "
				+ "DAILY_ALL_METER_TOTAL_LL_VOLTAGE_AVG FROM ALL_METER_DATA WHERE " + "TO_DATE (DATE) >= TO_DATE (\'"
				+ startDate + "\')  AND TO_DATE (DATE) <= TO_DATE (\'" + endDate + "\') "
				+ "AND (DATE,TIME) IN (SELECT DATE, MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)"
				+ "ORDER BY TO_NUMBER(MONTH) ASC, TO_DATE(HDATE) ASC, TIME ASC";

		List<AllMeterData> allMeterData = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return allMeterData;
	}

	

	// Historical Data - co2 - selected assets
	@Override
	public List<AllMeterData> getCo2Data(String startDate, String endDate) {

		String sql = "SELECT DISTINCT SITE_ID, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS HDATE, TIME, WEEK, WEEKDAY, "
				+ "MONTH, COALESCE(TO_NUMBER(ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE),0)"
				+ "AS ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE FROM ALL_METER_DATA "
				+ "WHERE TO_DATE (DATE) >= TO_DATE (\'" + startDate + "\')  AND " + "TO_DATE (DATE) <= TO_DATE (\'"
				+ endDate + "\') AND (DATE,TIME) IN (SELECT DATE, MAX(TIME)"
				+ " FROM ALL_METER_DATA GROUP BY SITE_ID,DATE) ORDER BY TO_NUMBER(MONTH) ASC, TO_DATE(HDATE) ASC, TIME ASC";

		List<AllMeterData> allMeterData = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		return allMeterData;
	}

	

	// Historical Data - Energy Consumption - YesterDay - All Assets
	@Override
	public List<AllMeterData> getYesterdayEnergyConsumption() {
		String sql = "SELECT DISTINCT SITE_ID,TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, TO_DATE(DATE) AS DATE, TIME, "
				+ "COALESCE(TO_NUMBER(ALL_METER_KWH_SUM),0) AS ALL_METER_KWH_SUM FROM ALL_METER_DATA "
				+ "WHERE DATE = TO_CHAR(current_date() -1, 'yyyy-MM-dd')";
		List<AllMeterData> yesterDayEC = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return yesterDayEC;
	}

	// Historical Data - Energy Consumption - YesterDay - Selected Assets
	@Override
	public List<ProcessedData> getYesterdayEnergyConsumptionByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "SELECT DISTINCT SITE_ID,ASSET_ID, UNIX_TIMESTAMP, TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP,"
				+ " TO_DATE(DATE) AS DATE, TIME, COALESCE(TO_NUMBER(EXACT_KWH),0) AS EXACT_KWH "
				+ "FROM PROCESSED_TABLE WHERE DATE = TO_CHAR(current_date() -1, 'yyyy-MM-dd') "
				+ "AND TO_NUMBER (ASSET_ID) IN  (:assetId)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - Energy Consumption - Last Week - all Assets
	@Override
	public List<AllMeterData> getLastWeekEnergyConsumption() {
		String sql = "SELECT DISTINCT SITE_ID, WEEK, WEEKDAY, TO_DATE(DATE) AS WEEK_DATE, "
				+ "MAX(COALESCE(TO_NUMBER(DAILY_ALL_METER_KWH_SUM),0)) AS DAILY_ALL_METER_KWH_SUM "
				+ "FROM ALL_METER_DATA WHERE TO_NUMBER (WEEK) = WEEK(now())-1  "
				+ "GROUP BY SITE_ID,DATE,WEEK, WEEKDAY";
		List<AllMeterData> lastWeekEC = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return lastWeekEC;
	}

	// Historical Data - Energy Consumption - Last Week - Selected Assets
	@Override
	public List<ProcessedData> getLastWeekEnergyConsumptionByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "SELECT DISTINCT SITE_ID,ASSET_ID,TO_DATE(DATE) AS WEEK_DATE, WEEK, WEEKDAY, "
				+ "MAX(COALESCE(TO_NUMBER(INDIVIDUAL_METER_DAILY_KWH_SUM),0)) AS "
				+ "INDIVIDUAL_METER_DAILY_KWH_SUM FROM PROCESSED_TABLE WHERE "
				+ "TO_NUMBER (WEEK) = WEEK(now())-1 AND TO_NUMBER(ASSET_ID) IN (:assetId) "
				+ "GROUP BY SITE_ID,DATE,WEEK, WEEKDAY, ASSET_ID";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - Energy Consumption - Last Month - All Assets
	@Override
	public List<AllMeterData> getLastMonthEnergyConsumption() {
		String sql = "SELECT DISTINCT SITE_ID, TO_DATE(DATE) AS MONTH_DATE,MONTH, "
				+ "MAX(COALESCE(TO_NUMBER(DAILY_ALL_METER_KWH_SUM),0)) AS MONTHLY_KWH FROM ALL_METER_DATA "
				+ "WHERE TO_NUMBER (MONTH) = MONTH(now()) -1 GROUP BY SITE_ID, DATE, MONTH";
		List<AllMeterData> lastMonthEC = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return lastMonthEC;
	}

	// Historical Data - Energy Consumption - Last Month - Selected Assets
	@Override
	public List<ProcessedData> getLastMonthEnergyConsumptionByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "SELECT DISTINCT SITE_ID, ASSET_ID,TO_DATE(DATE) AS MONTH_DATE, MONTH,  "
				+ "MAX(COALESCE(TO_NUMBER(INDIVIDUAL_METER_DAILY_KWH_SUM),0)) AS "
				+ "INDIVIDUAL_METER_DAILY_KWH_SUM FROM PROCESSED_TABLE WHERE TO_NUMBER "
				+ "(MONTH) = MONTH(now())  -1 AND TO_NUMBER (ASSET_ID) IN (:assetId) GROUP BY "
				+ "SITE_ID,DATE,MONTH,ASSET_ID";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - kw - Yesterday - All Assets
	@Override
	public List<AllMeterData> getYesterdayKw() {
		String sql = "select DISTINCT SITE_ID, TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, TO_DATE(DATE) AS DATE, TIME, "
				+ "COALESCE(TO_NUMBER(ALL_METER_TOTAL_KW_AVG),0) AS ALL_METER_TOTAL_KW_AVG "
				+ "FROM ALL_METER_DATA WHERE  DATE = TO_CHAR (current_date() -1, 'yyyy-MM-dd')";
		List<AllMeterData> yesterDayKw = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return yesterDayKw;
	}

	// Historical Data - kw - Yesterday - Selected Assets
	@Override
	public List<ProcessedData> getYesterdayKwByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "select DISTINCT SITE_ID, ASSET_ID,UNIX_TIMESTAMP, TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, "
				+ "TO_DATE(DATE) AS DATE, TIME, COALESCE(TO_NUMBER(WATTS_TOTAL),0) AS WATTS_TOTAL "
				+ "FROM PROCESSED_TABLE WHERE DATE = TO_CHAR (current_date() -1, 'yyyy-MM-dd') "
				+ "AND TO_NUMBER (ASSET_ID) IN (:assetId) ";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - kw - Last week - All Assets
	@Override
	public List<AllMeterData> getLastWeekKw() {
		String sql = "SELECT DISTINCT SITE_ID, DATE, TIME, WEEK, WEEKDAY, "
				+ "COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KW_AVG),0) AS DAILY_ALL_METER_TOTAL_KW_AVG "
				+ "FROM ALL_METER_DATA WHERE TO_NUMBER (WEEK) = WEEK(now())-1 AND (DATE,TIME) "
				+ "IN (SELECT DATE, MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";
		List<AllMeterData> lastWeekKw = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return lastWeekKw;
	}

	// Historical Data - kw - Last week - Selected Assets
	@Override
	public List<ProcessedData> getLastWeekKwByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "SELECT DISTINCT SITE_ID, ASSET_ID,DATE, TIME, WEEK, WEEKDAY, "
				+ "COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_KW_AVG),0) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_KW_AVG FROM PROCESSED_TABLE WHERE "
				+ "TO_NUMBER (WEEK) = WEEK(now())-1 AND TO_NUMBER (ASSET_ID) IN (:assetId) AND "
				+ "(DATE, TIME) IN (SELECT DATE, MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - kw - Last month- All Assets
	@Override
	public List<AllMeterData> getLastMonthKw() {
		String sql = "SELECT DISTINCT SITE_ID, TO_DATE(DATE) AS DATE, TIME, WEEK, WEEKDAY, MONTH, "
				+ "COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KW_AVG),0) AS DAILY_ALL_METER_TOTAL_KW_AVG "
				+ "FROM ALL_METER_DATA WHERE TO_NUMBER (MONTH) = MONTH(now())-1 AND (DATE,TIME) "
				+ "IN (SELECT DATE,MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";
		List<AllMeterData> lastMonthKw = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return lastMonthKw;
	}

	// Historical Data - kw - Last month- Selected Assets
	@Override
	public List<ProcessedData> getLastMonthKwByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "SELECT DISTINCT SITE_ID, ASSET_ID,TO_DATE(DATE) AS DATE, TIME, WEEK, WEEKDAY, MONTH, "
				+ "COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_KW_AVG),0) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_KW_AVG FROM PROCESSED_TABLE WHERE "
				+ "TO_NUMBER (MONTH) = MONTH(now())-1 AND TO_NUMBER (ASSET_ID) IN (:assetId) AND "
				+ "(DATE,TIME) IN (SELECT DATE,MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - kva - yesterday- All Assets
	@Override
	public List<AllMeterData> getYesterdayKva() {
		String sql = "select DISTINCT SITE_ID, TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, TO_DATE(DATE) AS DATE, "
				+ "TIME,COALESCE(TO_NUMBER(ALL_METER_KVA_AVG),0) AS ALL_METER_KVA_AVG FROM ALL_METER_DATA "
				+ "WHERE  DATE = TO_CHAR (current_date() -1, 'yyyy-MM-dd')";
		List<AllMeterData> yesterDayKva = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return yesterDayKva;
	}

	// Historical Data - kva - yesterday- Selected Assets
	@Override
	public List<ProcessedData> getYesterdayKvaByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "select DISTINCT SITE_ID, ASSET_ID,UNIX_TIMESTAMP, TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, "
				+ "TO_DATE(DATE) AS DATE, TIME,  COALESCE(TO_NUMBER(VA_TOTAL),0) AS VA_TOTAL "
				+ "FROM PROCESSED_TABLE WHERE DATE = TO_CHAR (current_date() -1, 'yyyy-MM-dd')"
				+ " AND TO_NUMBER (ASSET_ID) IN (:assetId)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - kva - last week- all Assets
	@Override
	public List<AllMeterData> getLastWeekKva() {
		String sql = "SELECT DISTINCT SITE_ID, DATE, TIME, WEEK, WEEKDAY, "
				+ "COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KVA_AVG),0) AS DAILY_ALL_METER_TOTAL_KVA_AVG "
				+ "FROM ALL_METER_DATA WHERE TO_NUMBER (WEEK) = WEEK(now())-1 AND (DATE,TIME) "
				+ "IN (SELECT DATE, MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";
		List<AllMeterData> lastWeekKva = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return lastWeekKva;
	}

	// Historical Data - kva - last week- Selected Assets
	@Override
	public List<ProcessedData> getLastWeekKvaByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "SELECT DISTINCT SITE_ID,ASSET_ID, DATE, TIME, WEEK, WEEKDAY, "
				+ "COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG),0) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG FROM PROCESSED_TABLE "
				+ "WHERE TO_NUMBER (WEEK) = WEEK(now())-1 AND TO_NUMBER (ASSET_ID) "
				+ "IN (:assetId) AND (DATE,TIME) IN (SELECT DATE, MAX(TIME) FROM ALL_METER_DATA "
				+ "GROUP BY SITE_ID,DATE)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - kva - last month- all Assets
	@Override
	public List<AllMeterData> getLastMonthKva() {
		String sql = "SELECT DISTINCT SITE_ID, TO_DATE(DATE) AS DATE, TIME, WEEK, WEEKDAY, MONTH,  "
				+ "COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KVA_AVG),0) AS "
				+ "DAILY_ALL_METER_TOTAL_KVA_AVG FROM ALL_METER_DATA WHERE TO_NUMBER "
				+ "(MONTH) = MONTH(now())-1 AND (DATE,TIME) IN (SELECT  DATE, MAX(TIME) "
				+ "FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";
		List<AllMeterData> lastMonthKva = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return lastMonthKva;
	}

	// Historical Data - kva - last month- Selected Assets
	@Override
	public List<ProcessedData> getLastMonthKvaByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "SELECT DISTINCT SITE_ID,ASSET_ID, TO_DATE(DATE) AS DATE, TIME, WEEK, WEEKDAY, MONTH, "
				+ "COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG),0) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_KVA_AVG FROM PROCESSED_TABLE WHERE "
				+ "TO_NUMBER (MONTH) = MONTH(now())-1 AND TO_NUMBER (ASSET_ID) IN (:assetId) AND "
				+ "(DATE,TIME) IN (SELECT DATE, MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - pf - yesterday- all Assets
	@Override
	public List<AllMeterData> getYesterdayPf() {
		String sql = "select DISTINCT SITE_ID, TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, TO_DATE(DATE) AS DATE, TIME,  "
				+ "COALESCE(TO_NUMBER(ALL_METER_PF_INST_AVG),0) AS ALL_METER_PF_INST_AVG "
				+ "FROM ALL_METER_DATA WHERE  DATE = TO_CHAR (current_date() -1, 'yyyy-MM-dd')";
		List<AllMeterData> yesterDayPf = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return yesterDayPf;
	}

	// Historical Data - pf - yesterday- selected Assets
	@Override
	public List<ProcessedData> getYesterdayPfByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "select DISTINCT SITE_ID,ASSET_ID, UNIX_TIMESTAMP, TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, "
				+ "TO_DATE(DATE) AS DATE, TIME, COALESCE(TO_NUMBER(PF_AVG_INST),0) AS PF_AVG_INST "
				+ "FROM PROCESSED_TABLE WHERE DATE = TO_CHAR (current_date() -1, 'yyyy-MM-dd') "
				+ "AND TO_NUMBER (ASSET_ID) IN  (:assetId)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - pf - last week- all Assets
	@Override
	public List<AllMeterData> getLastWeekPf() {
		String sql = "SELECT DISTINCT SITE_ID, DATE, TIME, WEEK, WEEKDAY, "
				+ "COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_PF_AVG),0) AS DAILY_ALL_METER_TOTAL_PF_AVG "
				+ "FROM ALL_METER_DATA WHERE TO_NUMBER (WEEK) = WEEK(now())-1 AND (DATE,TIME)"
				+ " IN (SELECT DATE, MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";
		List<AllMeterData> lastWeekPf = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return lastWeekPf;
	}

	// Historical Data - pf - last week- selected Assets
	@Override
	public List<ProcessedData> getLastWeekPfByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "SELECT DISTINCT SITE_ID, ASSET_ID,DATE, TIME, WEEK, WEEKDAY, "
				+ "COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG),0) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG FROM PROCESSED_TABLE WHERE "
				+ "TO_NUMBER (WEEK) = WEEK(now())-1 AND TO_NUMBER (ASSET_ID) IN (:assetId)"
				+ "AND (DATE, TIME) IN (SELECT DATE, MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - pf - last month - all Assets
	@Override
	public List<AllMeterData> getLastMonthPf() {
		String sql = "SELECT DISTINCT SITE_ID, TO_DATE(DATE) AS DATE, TIME, WEEK, WEEKDAY, MONTH, "
				+ "COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_PF_AVG),0) AS DAILY_ALL_METER_TOTAL_PF_AVG FROM "
				+ "ALL_METER_DATA WHERE TO_NUMBER (MONTH) = MONTH(now())-1 AND (DATE, TIME) "
				+ "IN (SELECT DATE, MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";
		List<AllMeterData> lastMonthPf = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return lastMonthPf;
	}

	// Historical Data - pf - last month - selected Assets
	@Override
	public List<ProcessedData> getLastMonthPfByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "SELECT DISTINCT SITE_ID, ASSET_ID,TO_DATE(DATE) AS DATE, TIME, WEEK, WEEKDAY, MONTH, "
				+ "COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG),0) AS "
				+ "DAILY_INDIVIDUAL_METER_TOTAL_PF_AVG FROM PROCESSED_TABLE WHERE TO_NUMBER "
				+ "(MONTH) = MONTH(now())-1 AND TO_NUMBER (ASSET_ID) IN (:assetId) AND (DATE, TIME) "
				+ "IN (SELECT DATE, MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - voltage - yesterday- All Assets
	@Override
	public List<AllMeterData> getYesterdayVoltage() {
		String sql = "select DISTINCT SITE_ID, TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, TO_DATE(DATE) AS DATE, TIME, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VRY_PHASE_AVG),0) AS ALL_METER_VRY_PHASE_AVG, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VYB_PHASE_AVG),0) AS ALL_METER_VYB_PHASE_AVG, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VBR_PHASE_AVG ),0) AS ALL_METER_VBR_PHASE_AVG "
				+ "FROM ALL_METER_DATA WHERE DATE = TO_CHAR (current_date() -1, 'yyyy-MM-dd')";
		List<AllMeterData> yesterDayVoltage = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return yesterDayVoltage;
	}

	// Historical Data - voltage - yesterday- selected Assets
	@Override
	public List<ProcessedData> getYesterdayVoltageByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "select DISTINCT SITE_ID,ASSET_ID, UNIX_TIMESTAMP, TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, "
				+ "TO_DATE(DATE) AS DATE, TIME, COALESCE(TO_NUMBER(VRY_PHASE),0) AS VRY_PHASE, "
				+ "COALESCE(TO_NUMBER(VYB_PHASE),0) AS VYB_PHASE, COALESCE(TO_NUMBER(VBR_PHASE),0) "
				+ "AS VBR_PHASE FROM PROCESSED_TABLE WHERE DATE = TO_CHAR (current_date() -1, 'yyyy-MM-dd') "
				+ "AND TO_NUMBER (ASSET_ID) IN (:assetId)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - voltage - last week- all Assets
	@Override
	public List<AllMeterData> getLastWeekVoltage() {
		String sql = "SELECT DISTINCT SITE_ID, TO_DATE(DATE) AS DATE, TIME, WEEK, WEEKDAY, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VRY_PHASE_AVG),0) AS ALL_METER_VRY_PHASE_AVG, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VYB_PHASE_AVG),0) AS ALL_METER_VYB_PHASE_AVG, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VBR_PHASE_AVG),0) AS ALL_METER_VBR_PHASE_AVG "
				+ "FROM ALL_METER_DATA WHERE TO_NUMBER (WEEK) = WEEK(now())-1 AND (DATE,TIME) "
				+ "IN (SELECT DATE,MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";
		List<AllMeterData> lastWeekVoltage = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return lastWeekVoltage;
	}

	// Historical Data - voltage - last week- selected Assets
	@Override
	public List<ProcessedData> getLastWeekVoltageByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "SELECT DISTINCT SITE_ID, ASSET_ID,TO_DATE(DATE) AS DATE, TIME, WEEK, WEEKDAY, "
				+ "COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_VRY_VOLTAGE_AVG),0) "
				+ "AS DAILY_INDIVIDUAL_METER_VRY_VOLTAGE_AVG, "
				+ "COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_VYB_VOLTAGE_AVG),0) AS "
				+ "DAILY_INDIVIDUAL_METER_VYB_VOLTAGE_AVG,"
				+ " COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_VBR_VOLTAGE_AVG),0) AS "
				+ "DAILY_INDIVIDUAL_METER_VBR_VOLTAGE_AVG FROM PROCESSED_TABLE WHERE "
				+ "TO_NUMBER (WEEK) = WEEK(now())-1 AND TO_NUMBER (ASSET_ID) IN  (:assetId)"
				+ "AND (DATE,TIME) IN (SELECT DATE,MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - voltage - last month- all Assets
	@Override
	public List<AllMeterData> getLastMonthVoltage() {
		String sql = "SELECT DISTINCT SITE_ID, TO_DATE(DATE) AS DATE, TIME, WEEK, WEEKDAY, MONTH, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VRY_PHASE_AVG),0) AS ALL_METER_VRY_PHASE_AVG, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VYB_PHASE_AVG),0) AS ALL_METER_VYB_PHASE_AVG, "
				+ "COALESCE(TO_NUMBER(ALL_METER_VBR_PHASE_AVG),0) AS ALL_METER_VBR_PHASE_AVG "
				+ "FROM ALL_METER_DATA WHERE TO_NUMBER (MONTH) = MONTH(now())-1 AND (DATE,TIME) "
				+ "IN (SELECT DATE,MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";
		List<AllMeterData> lastMonthVoltage = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return lastMonthVoltage;
	}

	// Historical Data - voltage - last month- selected Assets
	@Override
	public List<ProcessedData> getLastMonthVoltageByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "SELECT DISTINCT SITE_ID, ASSET_ID,TO_DATE(DATE) AS DATE, TIME, WEEK, WEEKDAY, "
				+ "MONTH,COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_VRY_VOLTAGE_AVG),0) "
				+ "AS DAILY_INDIVIDUAL_METER_VRY_VOLTAGE_AVG, "
				+ "COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_VYB_VOLTAGE_AVG),0) AS "
				+ "DAILY_INDIVIDUAL_METER_VYB_VOLTAGE_AVG, "
				+ "COALESCE(TO_NUMBER(DAILY_INDIVIDUAL_METER_VBR_VOLTAGE_AVG ),0) AS "
				+ "DAILY_INDIVIDUAL_METER_VBR_VOLTAGE_AVG FROM PROCESSED_TABLE WHERE "
				+ "TO_NUMBER (MONTH) = MONTH(now())-1 AND TO_NUMBER (ASSET_ID) IN  (:assetId) AND "
				+ "(DATE,TIME) IN (SELECT DATE,MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - co2 - yesterday- all Assets
	@Override
	public List<AllMeterData> getYesterdayCo2() {
		String sql = "select DISTINCT SITE_ID,TO_DATE(NORMAL_TIMESTAMP) AS TIMESTAMP, TO_DATE(DATE) AS DATE, TIME, "
				+ "COALESCE(TO_NUMBER(ALL_METER_CARBON_EMISSION_SUM),0) AS ALL_METER_CARBON_EMISSION_SUM "
				+ "FROM ALL_METER_DATA WHERE DATE = TO_CHAR (current_date()-1, 'yyyy-MM-dd')";
		List<AllMeterData> yesterDayCo2 = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return yesterDayCo2;
	}

	// Historical Data - co2 - yesterday- selected Assets
	@Override
	public List<ProcessedData> getYesterdayCo2ByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "select DISTINCT SITE_ID, ASSET_ID,UNIX_TIMESTAMP,TO_DATE(NORMAL_TIMESTAMP) "
				+ "AS TIMESTAMP, DATE, TIME, COALESCE(TO_NUMBER(CARBON_EMISSION),0) "
				+ "AS CARBON_EMISSION FROM PROCESSED_TABLE WHERE DATE = TO_CHAR"
				+ " (current_date()-1, 'yyyy-MM-dd') AND TO_NUMBER (ASSET_ID) IN  (:assetId)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));

		return processedData;
	}

	// Historical Data - co2 - last week- all Assets
	@Override
	public List<AllMeterData> getLastWeekCo2() {
		String sql = "SELECT DISTINCT SITE_ID, TO_DATE(DATE) AS DATE, TIME, WEEK, WEEKDAY, "
				+ "COALESCE(TO_NUMBER(ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE),0) AS "
				+ "ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE FROM ALL_METER_DATA WHERE "
				+ "TO_NUMBER (WEEK) = WEEK(now())-1 AND (DATE,TIME) IN (SELECT DATE,MAX(TIME) "
				+ "FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";
		List<AllMeterData> lastWeekCo2 = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return lastWeekCo2;
	}

	// Historical Data - co2 - last week- selected Assets
	@Override
	public List<ProcessedData> getLastWeekCo2ByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "SELECT DISTINCT SITE_ID, ASSET_ID,TO_DATE(DATE) AS DATE, TIME, WEEK, WEEKDAY, "
				+ "COALESCE(TO_NUMBER(DAILY_METER_WISE_CARBON_EMISSION_SUM),0) AS "
				+ "DAILY_METER_WISE_CO2_SUM FROM PROCESSED_TABLE WHERE "
				+ "TO_NUMBER (WEEK) = WEEK(now())-1 AND TO_NUMBER (ASSET_ID) IN  (:assetId)"
				+ "AND (DATE,TIME) IN (SELECT DATE,MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	// Historical Data - co2 - last month- all Assets
	@Override
	public List<AllMeterData> getLastMonthCo2() {
		String sql = "SELECT DISTINCT SITE_ID, TO_DATE(DATE) AS DATE, TIME, WEEK, WEEKDAY, MONTH, "
				+ "COALESCE(TO_NUMBER(ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE),0) AS "
				+ "ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE FROM ALL_METER_DATA WHERE "
				+ "TO_NUMBER (MONTH) = MONTH(now())-1 AND (DATE,TIME) IN (SELECT DATE,MAX(TIME) "
				+ "FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";
		List<AllMeterData> lastMonthCo2 = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));
		return lastMonthCo2;
	}

	// Historical Data - co2 - last month- selected Assets
	@Override
	public List<ProcessedData> getLastMonthCo2ByAssets(Integer[] assets) {
		List<Integer> selectedAssets = Arrays.asList(assets);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("assetId", selectedAssets);

		String sql = "SELECT DISTINCT SITE_ID, ASSET_ID, TO_DATE(DATE) AS DATE, TIME, WEEK, WEEKDAY, MONTH, "
				+ "COALESCE(TO_NUMBER(DAILY_METER_WISE_CARBON_EMISSION_SUM),0) AS "
				+ "DAILY_METER_WISE_CO2_SUM FROM PROCESSED_TABLE WHERE "
				+ "TO_NUMBER (MONTH) = MONTH(now())-1 AND TO_NUMBER (ASSET_ID) IN  (:assetId)AND "
				+ "(DATE,TIME) IN (SELECT DATE,MAX(TIME) FROM ALL_METER_DATA GROUP BY SITE_ID,DATE)";

		List<ProcessedData> processedData = namedJdbcTemplate.query(sql, parameters,
				new BeanPropertyRowMapper<ProcessedData>(ProcessedData.class));
		return processedData;
	}

	@Override
	public Double getMonthYearWiseKwhBySite(String year, String month, Long siteId) {

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		
		String changeMonth = null;
		
		if (month.equalsIgnoreCase("01")) {
			changeMonth = "1";
		}
		if (month.equalsIgnoreCase("02")) {
			changeMonth = "2";
		}
		if (month.equalsIgnoreCase("03")) {
			changeMonth = "3";
		}
		
		parameters.addValue("year", year);
		parameters.addValue("month", changeMonth);
		parameters.addValue("sId", Long.toString(siteId));
		String sId = Long.toString(siteId);

		String sql = "SELECT SUM (TO_NUMBER(EXACT_KWH)) AS KWH_SUM " + " FROM PROCESSED_TABLE where YEAR =   \'" + year
				+ "\' AND MONTH =  \'" + changeMonth + "\' " + " AND SITE_ID = \'" + sId + "\' ";

		Double sumKwh = jdbcTemplate.queryForObject(sql, Double.class);

		if (sumKwh != null)
			return sumKwh;
		else
			return 0.0;
	}

	public CompareDates getRealTimeAnalysisComparison(ComparisonDTO comData) {

		StringBuffer sBuffer = new StringBuffer();

		// Select
		if ((comData.getDateRanges().equalsIgnoreCase("1")) || (comData.getDateRanges().equalsIgnoreCase("5"))) {
			sBuffer.append("SELECT DISTINCT TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS DATE, \n"
					+ "TIME,COALESCE(TO_NUMBER(ALL_METER_KWH_SUM),0) AS ALL_METER_KWH_SUM,\n"
					+ "COALESCE(TO_NUMBER(ALL_METER_TOTAL_KW_AVG),0) AS ALL_METER_TOTAL_KW_AVG,\n"
					+ "COALESCE(TO_NUMBER(ALL_METER_KVA_AVG),0) AS ALL_METER_KVA_AVG,\n"
					+ "COALESCE(TO_NUMBER(ALL_METER_PF_INST_AVG),0) AS ALL_METER_PF_INST_AVG,\n"
					+ "COALESCE(TO_NUMBER(ALL_METER_CARBON_EMISSION_SUM),0) AS ALL_METER_CARBON_EMISSION_SUM ");
		} else if ((comData.getDateRanges().equalsIgnoreCase("2")) || (comData.getDateRanges().equalsIgnoreCase("6"))) {
			sBuffer.append(
					"SELECT DISTINCT SITE_ID, WEEK, WEEKDAY, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS WEEK_DATE, \n"
							+ "MAX(COALESCE(TO_NUMBER(DAILY_ALL_METER_KWH_SUM),0)) AS DAILY_ALL_METER_KWH_SUM,\n"
							+ "MAX(COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KW_AVG),0)) AS DAILY_ALL_METER_TOTAL_KW_AVG,\n"
							+ "MAX(COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KVA_AVG),0)) AS DAILY_ALL_METER_TOTAL_KVA_AVG,\n"
							+ "MAX(COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_PF_AVG),0)) AS DAILY_ALL_METER_TOTAL_PF_AVG,\n"
							+ "MAX(COALESCE(TO_NUMBER(ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE),0)) AS ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE ");
		} else if ((comData.getDateRanges().equalsIgnoreCase("3")) || (comData.getDateRanges().equalsIgnoreCase("7"))) {
			sBuffer.append(
					"SELECT DISTINCT SITE_ID,  MONTH, (case when MONTH = '1' then 'January' when MONTH = '2' then 'February' when MONTH = '3' then 'March'  when MONTH = '4' then 'April'  when MONTH = '5' then 'May'  when MONTH = '6' then 'June'  when MONTH = '7' then 'July'  when MONTH = '8' then 'August'  when MONTH = '9' then 'September'  when MONTH = '10' then 'October'  when MONTH = '11' then 'November' when MONTH = '12' then 'December' end) as monthname, TO_CHAR(TO_DATE(DATE),'dd-MM-yyyy') AS MONTH_DATE,\n"
							+ "MAX(COALESCE(TO_NUMBER(DAILY_ALL_METER_KWH_SUM),0)) AS DAILY_ALL_METER_KWH_SUM,\n"
							+ "MAX(COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KW_AVG),0)) AS DAILY_ALL_METER_TOTAL_KW_AVG,\n"
							+ "MAX(COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KVA_AVG),0)) AS DAILY_ALL_METER_TOTAL_KVA_AVG,\n"
							+ "MAX(COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_PF_AVG),0)) AS DAILY_ALL_METER_TOTAL_PF_AVG,\n"
							+ "MAX(COALESCE(TO_NUMBER(ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE),0)) AS ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE");
		} else if ((comData.getDateRanges().equalsIgnoreCase("4"))
				|| ((comData.getDateRanges().equalsIgnoreCase("8")))) {
			sBuffer.append("SELECT DISTINCT SITE_ID, MONTH || '-' || YEAR AS MONTH_NAME, YEAR, \n"
					+ "SUM(COALESCE(TO_NUMBER(DAILY_ALL_METER_KWH_SUM),0)) AS DAILY_ALL_METER_KWH_SUM,\n"
					+ "SUM(COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KW_AVG),0)) AS DAILY_ALL_METER_TOTAL_KW_AVG, \n"
					+ "SUM(COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_KVA_AVG),0)) AS DAILY_ALL_METER_TOTAL_KVA_AVG,\n"
					+ "SUM(COALESCE(TO_NUMBER(DAILY_ALL_METER_TOTAL_PF_AVG),0)) AS DAILY_ALL_METER_TOTAL_PF_AVG,\n"
					+ "SUM(COALESCE(TO_NUMBER(ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE),0)) AS ALL_METER_DAILY_CARBON_EMISSION_CUMULATIVE_VALUE ");
		}

		// from
		if (comData.getDateRanges().equalsIgnoreCase("1")) {
			sBuffer.append(" FROM ALL_METER_DATA WHERE DATE IN (TO_CHAR(current_date(), 'yyyy-MM-dd')) ORDER BY TIME");
		} else if (comData.getDateRanges().equalsIgnoreCase("2")) {
			sBuffer.append(
					" FROM ALL_METER_DATA WHERE TO_NUMBER (WEEK) IN (WEEK(now())) GROUP BY SITE_ID,DATE,WEEK, WEEKDAY ORDER BY WEEK_DATE");
		} else if (comData.getDateRanges().equalsIgnoreCase("3")) {
			sBuffer.append(
					" FROM ALL_METER_DATA WHERE TO_NUMBER (MONTH) IN (MONTH(now())) GROUP BY SITE_ID,DATE,MONTH ORDER BY MONTH_DATE");
		} else if (comData.getDateRanges().equalsIgnoreCase("4")) {
			sBuffer.append(
					" FROM ALL_METER_DATA WHERE TO_NUMBER (YEAR) IN (YEAR(now())) GROUP BY SITE_ID,MONTH, YEAR ORDER BY YEAR ASC, MONTH DESC");
		} else if (comData.getDateRanges().equalsIgnoreCase("5")) {
			sBuffer.append(" FROM ALL_METER_DATA WHERE DATE IN (\'" + comData.getFirstDate() + "\') ORDER BY TIME ");
		} else if (comData.getDateRanges().equalsIgnoreCase("6")) {
			sBuffer.append("");
		} else if (comData.getDateRanges().equalsIgnoreCase("7")) {
			sBuffer.append(" FROM ALL_METER_DATA WHERE MONTH IN (\'" + comData.getFirstDate()
					+ "\') GROUP BY SITE_ID,DATE,MONTH ORDER BY MONTH_DATE");
		} else if (comData.getDateRanges().equalsIgnoreCase("8")) {
			sBuffer.append(" FROM ALL_METER_DATA WHERE YEAR IN (\'" + comData.getFirstDate()
					+ "\') GROUP BY SITE_ID,MONTH, YEAR ORDER BY YEAR ASC, MONTH ASC ");
		}

		// System.out.println(sBuffer.toString());

		List<AllMeterData> firstComparison = jdbcTemplate.query(sBuffer.toString(),
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		// System.out.println(firstComparison.toString());

		String query = null;

		if (comData.getDateRanges().equalsIgnoreCase("1")) {
			query = sBuffer.toString().replace("current_date()", "current_date()-1");
		} else if (comData.getDateRanges().equalsIgnoreCase("2")) {
			query = sBuffer.toString().replace("WEEK(now())", "WEEK(current_date() - DAYOFWEEK((current_date())))");
		} else if (comData.getDateRanges().equalsIgnoreCase("3")) {
			query = sBuffer.toString().replace("MONTH(now())", "MONTH(current_date() - DAYOFMONTH((current_date())))");
		} else if (comData.getDateRanges().equalsIgnoreCase("4")) {
			query = sBuffer.toString().replace("YEAR(now())", "YEAR(current_date() - DAYOFYEAR((current_date())))");
		} else if (comData.getDateRanges().equalsIgnoreCase("5")) {
			query = sBuffer.toString().replace(comData.getFirstDate(), comData.getSecondDate());
		} else if (comData.getDateRanges().equalsIgnoreCase("6")) {
			query = sBuffer.toString().replace(comData.getFirstDate(), comData.getSecondDate());
		} else if (comData.getDateRanges().equalsIgnoreCase("7")) {
			query = sBuffer.toString().replace(comData.getFirstDate(), comData.getSecondDate());
		} else if (comData.getDateRanges().equalsIgnoreCase("8")) {
			query = sBuffer.toString().replace(comData.getFirstDate(), comData.getSecondDate());
		}

		List<AllMeterData> secondComparison = jdbcTemplate.query(query,
				new BeanPropertyRowMapper<AllMeterData>(AllMeterData.class));

		// System.out.println(secondComparison.toString());

		CompareDates comDates = new CompareDates();

		// Today - Yesterday and custom dates
		if ((comData.getDateRanges().equalsIgnoreCase("1") && comData.getReading().equalsIgnoreCase("kWh"))
				|| (comData.getDateRanges().equalsIgnoreCase("5") && comData.getReading().equalsIgnoreCase("kWh"))) {
			comDates.getFirstData().addAll(firstComparison.stream().filter(line -> line.getAllMeterKwhSum() != null)
					.map(AllMeterData::getAllMeterKwhSum).collect(Collectors.toList()));
			comDates.getSecondData().addAll(secondComparison.stream().filter(line -> line.getAllMeterKwhSum() != null)
					.map(AllMeterData::getAllMeterKwhSum).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData().addAll(firstComparison.stream().filter(line -> line.getTime() != null)
					.map(AllMeterData::getTime).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData().addAll(secondComparison.stream().filter(line -> line.getTime() != null)
					.map(AllMeterData::getTime).collect(Collectors.toList()));

		} else if ((comData.getDateRanges().equalsIgnoreCase("1") && comData.getReading().equalsIgnoreCase("kW"))
				|| (comData.getDateRanges().equalsIgnoreCase("5") && comData.getReading().equalsIgnoreCase("kW"))) {
			comDates.getFirstData().addAll(firstComparison.stream().filter(line -> line.getAllMeterTotalKwAvg() != null)
					.map(AllMeterData::getAllMeterTotalKwAvg).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getAllMeterTotalKwAvg() != null)
							.map(AllMeterData::getAllMeterTotalKwAvg).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData().addAll(firstComparison.stream().filter(line -> line.getTime() != null)
					.map(AllMeterData::getTime).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData().addAll(secondComparison.stream().filter(line -> line.getTime() != null)
					.map(AllMeterData::getTime).collect(Collectors.toList()));
		} else if ((comData.getDateRanges().equalsIgnoreCase("1") && comData.getReading().equalsIgnoreCase("kVA"))
				|| (comData.getDateRanges().equalsIgnoreCase("5") && comData.getReading().equalsIgnoreCase("kVA"))) {
			comDates.getFirstData().addAll(firstComparison.stream().filter(line -> line.getAllMeterKvaAvg() != null)
					.map(AllMeterData::getAllMeterKvaAvg).collect(Collectors.toList()));
			comDates.getSecondData().addAll(secondComparison.stream().filter(line -> line.getAllMeterKvaAvg() != null)
					.map(AllMeterData::getAllMeterKvaAvg).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData().addAll(firstComparison.stream().filter(line -> line.getTime() != null)
					.map(AllMeterData::getTime).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData().addAll(secondComparison.stream().filter(line -> line.getTime() != null)
					.map(AllMeterData::getTime).collect(Collectors.toList()));
		} else if ((comData.getDateRanges().equalsIgnoreCase("1") && comData.getReading().equalsIgnoreCase("pf"))
				|| (comData.getDateRanges().equalsIgnoreCase("5") && comData.getReading().equalsIgnoreCase("pf"))) {
			comDates.getFirstData().addAll(firstComparison.stream().filter(line -> line.getAllMeterPfInstAvg() != null)
					.map(AllMeterData::getAllMeterPfInstAvg).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getAllMeterPfInstAvg() != null)
							.map(AllMeterData::getAllMeterPfInstAvg).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData().addAll(firstComparison.stream().filter(line -> line.getTime() != null)
					.map(AllMeterData::getTime).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData().addAll(secondComparison.stream().filter(line -> line.getTime() != null)
					.map(AllMeterData::getTime).collect(Collectors.toList()));
		} else if (comData.getDateRanges().equalsIgnoreCase("1") && comData.getReading().equalsIgnoreCase("Tariff")) {

		} else if ((comData.getDateRanges().equalsIgnoreCase("1") && comData.getReading().equalsIgnoreCase("Co2"))
				|| (comData.getDateRanges().equalsIgnoreCase("5") && comData.getReading().equalsIgnoreCase("Co2"))) {
			comDates.getFirstData()
					.addAll(firstComparison.stream().filter(line -> line.getAllMeterCarbonEmissionSum() != null)
							.map(AllMeterData::getAllMeterCarbonEmissionSum).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getAllMeterCarbonEmissionSum() != null)
							.map(AllMeterData::getAllMeterCarbonEmissionSum).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData().addAll(firstComparison.stream().filter(line -> line.getTime() != null)
					.map(AllMeterData::getTime).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData().addAll(secondComparison.stream().filter(line -> line.getTime() != null)
					.map(AllMeterData::getTime).collect(Collectors.toList()));
		}

		// This Week - LastWeek
		if (comData.getDateRanges().equalsIgnoreCase("2") && comData.getReading().equalsIgnoreCase("kWh")) {
			comDates.getFirstData()
					.addAll(firstComparison.stream().filter(line -> line.getDailyAllMeterKwhSum() != null)
							.map(AllMeterData::getDailyAllMeterKwhSum).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getDailyAllMeterKwhSum() != null)
							.map(AllMeterData::getDailyAllMeterKwhSum).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getWeekDay() != null)
							.map(AllMeterData::getWeekDay).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getWeekDay() != null)
							.map(AllMeterData::getWeekDay).collect(Collectors.toList()));
		} else if (comData.getDateRanges().equalsIgnoreCase("2") && comData.getReading().equalsIgnoreCase("kW")) {
			comDates.getFirstData()
					.addAll(firstComparison.stream().filter(line -> line.getDailyAllMeterTotalKwAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalKwAvg).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getDailyAllMeterTotalKwAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalKwAvg).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getWeekDay() != null)
							.map(AllMeterData::getWeekDay).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getWeekDay() != null)
							.map(AllMeterData::getWeekDay).collect(Collectors.toList()));
		} else if (comData.getDateRanges().equalsIgnoreCase("2") && comData.getReading().equalsIgnoreCase("kVA")) {
			comDates.getFirstData()
					.addAll(firstComparison.stream().filter(line -> line.getDailyAllMeterTotalKvaAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalKvaAvg).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getDailyAllMeterTotalKvaAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalKvaAvg).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getWeekDay() != null)
							.map(AllMeterData::getWeekDay).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getWeekDay() != null)
							.map(AllMeterData::getWeekDay).collect(Collectors.toList()));
		} else if (comData.getDateRanges().equalsIgnoreCase("2") && comData.getReading().equalsIgnoreCase("pf")) {
			comDates.getFirstData()
					.addAll(firstComparison.stream().filter(line -> line.getDailyAllMeterTotalPfAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalPfAvg).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getDailyAllMeterTotalPfAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalPfAvg).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getWeekDay() != null)
							.map(AllMeterData::getWeekDay).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getWeekDay() != null)
							.map(AllMeterData::getWeekDay).collect(Collectors.toList()));
		} else if (comData.getDateRanges().equalsIgnoreCase("2") && comData.getReading().equalsIgnoreCase("Tariff")) {

		} else if (comData.getDateRanges().equalsIgnoreCase("2") && comData.getReading().equalsIgnoreCase("Co2")) {
			comDates.getFirstData().addAll(firstComparison.stream()
					.filter(line -> line.getAllMeterDailyCarbonEmissionCumulativeValue() != null)
					.map(AllMeterData::getAllMeterDailyCarbonEmissionCumulativeValue).collect(Collectors.toList()));
			comDates.getSecondData().addAll(secondComparison.stream()
					.filter(line -> line.getAllMeterDailyCarbonEmissionCumulativeValue() != null)
					.map(AllMeterData::getAllMeterDailyCarbonEmissionCumulativeValue).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getWeekDay() != null)
							.map(AllMeterData::getWeekDay).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getWeekDay() != null)
							.map(AllMeterData::getWeekDay).collect(Collectors.toList()));
		}

		// This Month - Last Month
		if ((comData.getDateRanges().equalsIgnoreCase("3") && comData.getReading().equalsIgnoreCase("kWh"))
				|| (comData.getDateRanges().equalsIgnoreCase("7") && comData.getReading().equalsIgnoreCase("kWh"))) {
			comDates.getFirstData()
					.addAll(firstComparison.stream().filter(line -> line.getDailyAllMeterKwhSum() != null)
							.map(AllMeterData::getDailyAllMeterKwhSum).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getDailyAllMeterKwhSum() != null)
							.map(AllMeterData::getDailyAllMeterKwhSum).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getMonthDate() != null)
							.map(AllMeterData::getMonthDate).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getMonthDate() != null)
							.map(AllMeterData::getMonthDate).collect(Collectors.toList()));
		} else if ((comData.getDateRanges().equalsIgnoreCase("3") && comData.getReading().equalsIgnoreCase("kW"))
				|| (comData.getDateRanges().equalsIgnoreCase("7") && comData.getReading().equalsIgnoreCase("kW"))) {
			comDates.getFirstData()
					.addAll(firstComparison.stream().filter(line -> line.getDailyAllMeterTotalKwAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalKwAvg).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getDailyAllMeterTotalKwAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalKwAvg).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getMonthDate() != null)
							.map(AllMeterData::getMonthDate).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getMonthDate() != null)
							.map(AllMeterData::getMonthDate).collect(Collectors.toList()));
		} else if ((comData.getDateRanges().equalsIgnoreCase("3") && comData.getReading().equalsIgnoreCase("kVA"))
				|| (comData.getDateRanges().equalsIgnoreCase("7") && comData.getReading().equalsIgnoreCase("kVA"))) {
			comDates.getFirstData()
					.addAll(firstComparison.stream().filter(line -> line.getDailyAllMeterTotalKvaAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalKvaAvg).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getDailyAllMeterTotalKvaAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalKvaAvg).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getMonthDate() != null)
							.map(AllMeterData::getMonthDate).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getMonthDate() != null)
							.map(AllMeterData::getMonthDate).collect(Collectors.toList()));
		} else if ((comData.getDateRanges().equalsIgnoreCase("3") && comData.getReading().equalsIgnoreCase("pf"))
				|| (comData.getDateRanges().equalsIgnoreCase("7") && comData.getReading().equalsIgnoreCase("pf"))) {
			comDates.getFirstData()
					.addAll(firstComparison.stream().filter(line -> line.getDailyAllMeterTotalPfAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalPfAvg).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getDailyAllMeterTotalPfAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalPfAvg).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getMonthDate() != null)
							.map(AllMeterData::getMonthDate).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getMonthDate() != null)
							.map(AllMeterData::getMonthDate).collect(Collectors.toList()));
		} else if (comData.getDateRanges().equalsIgnoreCase("3") && comData.getReading().equalsIgnoreCase("Tariff")) {

		} else if ((comData.getDateRanges().equalsIgnoreCase("3") && comData.getReading().equalsIgnoreCase("Co2"))
				|| ((comData.getDateRanges().equalsIgnoreCase("7") && comData.getReading().equalsIgnoreCase("Co2")))) {
			comDates.getFirstData().addAll(firstComparison.stream()
					.filter(line -> line.getAllMeterDailyCarbonEmissionCumulativeValue() != null)
					.map(AllMeterData::getAllMeterDailyCarbonEmissionCumulativeValue).collect(Collectors.toList()));
			comDates.getSecondData().addAll(secondComparison.stream()
					.filter(line -> line.getAllMeterDailyCarbonEmissionCumulativeValue() != null)
					.map(AllMeterData::getAllMeterDailyCarbonEmissionCumulativeValue).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getMonthDate() != null)
							.map(AllMeterData::getMonthDate).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getMonthDate() != null)
							.map(AllMeterData::getMonthDate).collect(Collectors.toList()));
		}

		// This year - Last year
		if ((comData.getDateRanges().equalsIgnoreCase("4") && comData.getReading().equalsIgnoreCase("kWh"))
				|| (comData.getDateRanges().equalsIgnoreCase("8") && comData.getReading().equalsIgnoreCase("kWh"))) {
			comDates.getFirstData()
					.addAll(firstComparison.stream().filter(line -> line.getDailyAllMeterKwhSum() != null)
							.map(AllMeterData::getDailyAllMeterKwhSum).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getDailyAllMeterKwhSum() != null)
							.map(AllMeterData::getDailyAllMeterKwhSum).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getMonthName() != null)
							.map(AllMeterData::getMonthName).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getMonthName() != null)
							.map(AllMeterData::getMonthName).collect(Collectors.toList()));
		} else if ((comData.getDateRanges().equalsIgnoreCase("4") && comData.getReading().equalsIgnoreCase("kW"))
				|| (comData.getDateRanges().equalsIgnoreCase("8") && comData.getReading().equalsIgnoreCase("kW"))) {
			comDates.getFirstData()
					.addAll(firstComparison.stream().filter(line -> line.getDailyAllMeterTotalKwAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalKwAvg).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getDailyAllMeterTotalKwAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalKwAvg).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getMonthName() != null)
							.map(AllMeterData::getMonthName).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getMonthName() != null)
							.map(AllMeterData::getMonthName).collect(Collectors.toList()));
		} else if ((comData.getDateRanges().equalsIgnoreCase("4") && comData.getReading().equalsIgnoreCase("kVA"))
				|| (comData.getDateRanges().equalsIgnoreCase("8") && comData.getReading().equalsIgnoreCase("kVA"))) {
			comDates.getFirstData()
					.addAll(firstComparison.stream().filter(line -> line.getDailyAllMeterTotalKvaAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalKvaAvg).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getDailyAllMeterTotalKvaAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalKvaAvg).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getMonthName() != null)
							.map(AllMeterData::getMonthName).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getMonthName() != null)
							.map(AllMeterData::getMonthName).collect(Collectors.toList()));
		} else if ((comData.getDateRanges().equalsIgnoreCase("4") && comData.getReading().equalsIgnoreCase("pf"))
				|| (comData.getDateRanges().equalsIgnoreCase("8") && comData.getReading().equalsIgnoreCase("pf"))) {
			comDates.getFirstData()
					.addAll(firstComparison.stream().filter(line -> line.getDailyAllMeterTotalPfAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalPfAvg).collect(Collectors.toList()));
			comDates.getSecondData()
					.addAll(secondComparison.stream().filter(line -> line.getDailyAllMeterTotalPfAvg() != null)
							.map(AllMeterData::getDailyAllMeterTotalPfAvg).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getMonthName() != null)
							.map(AllMeterData::getMonthName).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getMonthName() != null)
							.map(AllMeterData::getMonthName).collect(Collectors.toList()));
		} else if ((comData.getDateRanges().equalsIgnoreCase("4") && comData.getReading().equalsIgnoreCase("Tariff"))
				|| (comData.getDateRanges().equalsIgnoreCase("8") && comData.getReading().equalsIgnoreCase("Tariff"))) {

		} else if ((comData.getDateRanges().equalsIgnoreCase("4") && comData.getReading().equalsIgnoreCase("Co2"))
				|| (comData.getDateRanges().equalsIgnoreCase("8") && comData.getReading().equalsIgnoreCase("Co2"))) {
			comDates.getFirstData().addAll(firstComparison.stream()
					.filter(line -> line.getAllMeterDailyCarbonEmissionCumulativeValue() != null)
					.map(AllMeterData::getAllMeterDailyCarbonEmissionCumulativeValue).collect(Collectors.toList()));
			comDates.getSecondData().addAll(secondComparison.stream()
					.filter(line -> line.getAllMeterDailyCarbonEmissionCumulativeValue() != null)
					.map(AllMeterData::getAllMeterDailyCarbonEmissionCumulativeValue).collect(Collectors.toList()));
			comDates.getFirstTimeIntervelData()
					.addAll(firstComparison.stream().filter(line -> line.getMonthName() != null)
							.map(AllMeterData::getMonthName).collect(Collectors.toList()));
			comDates.getSecondTimeIntervelData()
					.addAll(secondComparison.stream().filter(line -> line.getMonthName() != null)
							.map(AllMeterData::getMonthName).collect(Collectors.toList()));
		}

		return comDates;
	}

	@Override
	public List<MeterTimeBill> findByBillSiteId(String year,String month,String siteId) {

		String sql = "SELECT SITE_ID,SITE_NAME,SITE_BUILDING_ID,BUILDING_NAME,BUILDING_FLOOR_ID,"
				+ "FLOOR_NAME,ASSET_ID,ASSET_NAME,YEAR,MONTH,SUM (TO_NUMBER(ENERGY_CONSUMPTION_PRICE)) "
				+ "AS ENERGY_CONSUMPTION_PRICE FROM METER_AND_TIME_WISE_BILL_TABLE WHERE "
				+ "YEAR= \'"+ year + "\' AND MONTH= \'"+ month + "\' AND SITE_ID= \'"+ siteId + "\' GROUP BY "
				+ "SITE_ID,SITE_NAME,SITE_BUILDING_ID,BUILDING_NAME,BUILDING_FLOOR_ID,FLOOR_NAME,"
				+ "ASSET_ID,ASSET_NAME,YEAR,MONTH";

		List<MeterTimeBill> billSiteId = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<MeterTimeBill>(MeterTimeBill.class));

		return billSiteId;
	}
	
	public MeterTimeBill findBySiteBill(String year,String month,String siteId) {

		String sql = "SELECT SITE_ID,SITE_NAME,YEAR,MONTH,SUM (TO_NUMBER(ENERGY_CONSUMPTION_PRICE)) "
				+ "AS ENERGY_CONSUMPTION_PRICE FROM METER_AND_TIME_WISE_BILL_TABLE WHERE "
				+ "YEAR= \'"+ year + "\' AND MONTH= \'"+ month + "\' AND SITE_ID= \'"+ siteId + "\' GROUP BY "
				+ "SITE_ID,SITE_NAME,YEAR,MONTH";

		MeterTimeBill billSiteId = jdbcTemplate.queryForObject(sql,
				new BeanPropertyRowMapper<MeterTimeBill>(MeterTimeBill.class));

		return billSiteId;
	}
	
	public List<MeterTimeBill> findByBuildingBill(String year,String month,String siteId) {

		String sql = "SELECT SITE_BUILDING_ID,BUILDING_NAME,YEAR,MONTH,SUM (TO_NUMBER(ENERGY_CONSUMPTION_PRICE)) "
				+ "AS ENERGY_CONSUMPTION_PRICE FROM METER_AND_TIME_WISE_BILL_TABLE WHERE "
				+ "YEAR= \'"+ year + "\' AND MONTH= \'"+ month + "\' AND SITE_ID= \'"+ siteId + "\' GROUP BY "
				+ "SITE_BUILDING_ID,BUILDING_NAME,YEAR,MONTH";

		List<MeterTimeBill> billSiteId = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<MeterTimeBill>(MeterTimeBill.class));

		return billSiteId;
	}
	
	
	public List<MeterTimeBill> findByFloorBill(String year,String month,String siteId) {

		String sql = "SELECT BUILDING_FLOOR_ID,FLOOR_NAME,YEAR,MONTH,SUM (TO_NUMBER(ENERGY_CONSUMPTION_PRICE)) "
				+ "AS ENERGY_CONSUMPTION_PRICE FROM METER_AND_TIME_WISE_BILL_TABLE WHERE "
				+ "YEAR= \'"+ year + "\' AND MONTH= \'"+ month + "\' AND SITE_ID= \'"+ siteId + "\' GROUP BY "
				+ "BUILDING_FLOOR_ID,FLOOR_NAME,YEAR,MONTH";

		List<MeterTimeBill> billSiteId = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<MeterTimeBill>(MeterTimeBill.class));

		return billSiteId;
	}
	
	public List<MeterTimeBill> findByAssetBill(String year,String month,String siteId) {

		String sql = "SELECT ASSET_ID,ASSET_NAME,YEAR,MONTH,SUM (TO_NUMBER(ENERGY_CONSUMPTION_PRICE)) "
				+ "AS ENERGY_CONSUMPTION_PRICE FROM METER_AND_TIME_WISE_BILL_TABLE WHERE "
				+ "YEAR= \'"+ year + "\' AND MONTH= \'"+ month + "\' AND SITE_ID= \'"+ siteId + "\' GROUP BY "
				+ "ASSET_ID,ASSET_NAME,YEAR,MONTH";

		List<MeterTimeBill> billSiteId = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper<MeterTimeBill>(MeterTimeBill.class));

		return billSiteId;
	}
	
	@Override
	public int saveBillUtility(BillUtility billUtility) {
		
	   String sql = "UPSERT INTO BILL_UTIL(BILL_ID,YEAR,MONTH,BILL_FILE,TOTAL_CONSUMPTION,"
	    		+ "TOTAL_CONSUMPTION_PRICE) VALUES (?,?,?,?,?,?)";

	    System.out.println(sql);
	    
	    int bill = jdbcTemplate.update(sql, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement stmt) throws SQLException {
			
				    String uniqueID = UUID.randomUUID().toString();
				    uniqueID = uniqueID.replace("-", "");
				
				    stmt.setString(1, uniqueID);
				    stmt.setString(2, billUtility.getSelectYear());
	                stmt.setString(3, billUtility.getSelectMonth());
	                stmt.setString(4, billUtility.getBillFile());
	                stmt.setDouble(5, billUtility.getTotalConsumption());
	                stmt.setDouble(6, billUtility.getTotalConsumptionPrice());
	              
			} 
	    });
		return bill;
	}
	
	
	public BillUtility findBySiteBillUtility(String year,String month,Long siteId) {
        
		
		String sql = "SELECT SITE_ID,YEAR,MONTH,TOTAL_CONSUMPTION,TOTAL_CONSUMPTION_PRICE FROM BILL_UTIL WHERE "
				+ "YEAR= \'"+ year + "\' AND MONTH= \'"+ month + "\' AND SITE_ID= 2 ";

		BillUtility billSiteId = jdbcTemplate.queryForObject(sql,
				new BeanPropertyRowMapper<BillUtility>(BillUtility.class));

		return billSiteId;
	}
	
	
}