package com.engraph.service.dto;

import java.util.ArrayList;
import java.util.List;


public class CompareDates {

	private List<Double> firstData = new ArrayList<Double>();
	private List<Double> secondData = new ArrayList<Double>();
	private List<String> firstTimeIntervelData= new ArrayList<String>();
	private List<String> secondTimeIntervelData= new ArrayList<String>();
	
	
	public List<Double> getFirstData() {
		return firstData;
	}
	public void setFirstData(List<Double> firstData) {
		this.firstData = firstData;
	}
	public List<Double> getSecondData() {
		return secondData;
	}
	public void setSecondData(List<Double> secondData) {
		this.secondData = secondData;
	}
	public List<String> getFirstTimeIntervelData() {
		return firstTimeIntervelData;
	}
	public void setFirstTimeIntervelData(List<String> firstTimeIntervelData) {
		this.firstTimeIntervelData = firstTimeIntervelData;
	}
	public List<String> getSecondTimeIntervelData() {
		return secondTimeIntervelData;
	}
	public void setSecondTimeIntervelData(List<String> secondTimeIntervelData) {
		this.secondTimeIntervelData = secondTimeIntervelData;
	}
	
}
