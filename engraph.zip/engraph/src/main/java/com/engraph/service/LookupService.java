package com.engraph.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.engraph.repository.DesignationMasterRepository;
import com.engraph.repository.RoleMasterRepository;
import com.engraph.repository.SiteBuildingRepository;
import com.engraph.service.dto.DesignationDTO;
import com.engraph.service.dto.LookupDTO;
import com.engraph.service.dto.RoleDTO;


/**
 * Service class for managing lookups.
 */
@Service
@Transactional
public class LookupService {
	
	private static final Logger log = LoggerFactory.getLogger(LookupService.class);
	
	@Autowired
	private RoleMasterRepository roleMasterRepository; 
	
	@Autowired
	private DesignationMasterRepository designationMasterRepository;
	
	@Autowired
	private SiteBuildingRepository siteBuildingRepository;

	public Page<RoleDTO> getAllRole(Pageable pageable) {
		return roleMasterRepository.findAll(pageable).map(RoleDTO::new);
	}

	public Page<DesignationDTO> getAllDesignation(Pageable pageable) {
		return designationMasterRepository.findAll(pageable).map(DesignationDTO::new);
	}

	public List<LookupDTO> getBuildingFloorForSite(Long siteId) {
		return siteBuildingRepository.findLookupForSite(siteId);
		
	}
	
	

}
