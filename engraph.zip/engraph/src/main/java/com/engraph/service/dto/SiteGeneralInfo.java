package com.engraph.service.dto;

import java.util.List;

import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SiteGeneralInfo {

	// @Max(5)
	@JsonProperty("orgId")
	private Long orgId;
	
	@JsonProperty("site_id")
	private Long siteId;

	@JsonProperty("is_multi_site")
	private Boolean isMultiSite;

	@JsonProperty("total_site")
	private Integer totalSite;

	@JsonProperty("total_different_legal_site")
	private Integer totalLegalSite;

	@Size(max = 100)
	@JsonProperty("site_name")
	private String siteName;

	@Size(max = 50)
	@JsonProperty("site_type")
	private String siteType;

	@Size(max = 50)
	@JsonProperty("site_connection_type")
	private String siteConnectionType;

	@JsonProperty("site_total_area")
	private Double siteTotalArea;

	@JsonProperty("site_buildup_area")
	private Double siteBuildupArea;

	@JsonProperty("site_open_area")
	private Double siteOpenArea;

	@JsonProperty("site_terrace_area")
	private Double siteTerraceArea;

	@JsonProperty("site_building_no")
	private Integer siteBuildingNo;

	@JsonProperty("site_energy_auditing")
	private String siteEnergyAuditing;

	/*
	 * @JsonProperty("site_energy_auditing_frequency") private Integer
	 * siteEnergyAuditingFrequency;
	 */

	/*
	 * @JsonProperty("site_consumption_goal") private String siteConsumptionGoal;
	 */

	@JsonProperty("site_goal_amount")
	private String siteGoalAmount;
	
	@JsonProperty("buildings")
	private List<SiteBuildingDTO> buildings;
	

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}
	public List<SiteBuildingDTO> getBuildings() {
		return buildings;
	}

	public void setBuildings(List<SiteBuildingDTO> buildings) {
		this.buildings = buildings;
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public Boolean getIsMultiSite() {
		return isMultiSite;
	}

	public void setIsMultiSite(Boolean isMultiSite) {
		this.isMultiSite = isMultiSite;
	}

	public Integer getTotalSite() {
		return totalSite;
	}

	public void setTotalSite(Integer totalSite) {
		this.totalSite = totalSite;
	}

	public Integer getTotalLegalSite() {
		return totalLegalSite;
	}

	public void setTotalLegalSite(Integer totalLegalSite) {
		this.totalLegalSite = totalLegalSite;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getSiteType() {
		return siteType;
	}

	public void setSiteType(String siteType) {
		this.siteType = siteType;
	}

	public String getSiteConnectionType() {
		return siteConnectionType;
	}

	public void setSiteConnectionType(String siteConnectionType) {
		this.siteConnectionType = siteConnectionType;
	}

	public Double getSiteTotalArea() {
		return siteTotalArea;
	}

	public void setSiteTotalArea(Double siteTotalArea) {
		this.siteTotalArea = siteTotalArea;
	}

	public Double getSiteBuildupArea() {
		return siteBuildupArea;
	}

	public void setSiteBuildupArea(Double siteBuildupArea) {
		this.siteBuildupArea = siteBuildupArea;
	}

	public Double getSiteOpenArea() {
		return siteOpenArea;
	}

	public void setSiteOpenArea(Double siteOpenArea) {
		this.siteOpenArea = siteOpenArea;
	}

	public Double getSiteTerraceArea() {
		return siteTerraceArea;
	}

	public void setSiteTerraceArea(Double siteTerraceArea) {
		this.siteTerraceArea = siteTerraceArea;
	}

	public Integer getSiteBuildingNo() {
		return siteBuildingNo;
	}

	public void setSiteBuildingNo(Integer siteBuildingNo) {
		this.siteBuildingNo = siteBuildingNo;
	}

	public String getSiteEnergyAuditing() {
		return siteEnergyAuditing;
	}

	public void setSiteEnergyAuditing(String siteEnergyAuditing) {
		this.siteEnergyAuditing = siteEnergyAuditing;
	}

	/*
	 * public Integer getSiteEnergyAuditingFrequency() { return
	 * siteEnergyAuditingFrequency; }
	 * 
	 * public void setSiteEnergyAuditingFrequency(Integer
	 * siteEnergyAuditingFrequency) { this.siteEnergyAuditingFrequency =
	 * siteEnergyAuditingFrequency; }
	 */

	/*
	 * public String getSiteConsumptionGoal() { return siteConsumptionGoal; }
	 * 
	 * public void setSiteConsumptionGoal(String siteConsumptionGoal) {
	 * this.siteConsumptionGoal = siteConsumptionGoal; }
	 */

	public String getSiteGoalAmount() {
		return siteGoalAmount;
	}

	public void setSiteGoalAmount(String siteGoalAmount) {
		this.siteGoalAmount = siteGoalAmount;
	}

}
