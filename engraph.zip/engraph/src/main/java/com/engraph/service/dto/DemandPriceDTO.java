package com.engraph.service.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DemandPriceDTO {

	@JsonProperty("start_date")
	private Date startDate;
	
	@JsonProperty("end_date")
	private Date endDate;
	
	@JsonProperty("contract_demand")
	private String contractDemand;
	
	@JsonProperty("demand_parameter")
	private String demandParameter;
	
	@JsonProperty("demand_rate")
	private String demandRate;
	
	@JsonProperty("over_usage_rate")
	private String overUsageRate;
	
	@JsonProperty("demand_percentage")
	private String demandPercentage;
	
	@JsonProperty("demand_interval")
	private String demandInterval;

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getContractDemand() {
		return contractDemand;
	}

	public void setContractDemand(String contractDemand) {
		this.contractDemand = contractDemand;
	}

	public String getDemandParameter() {
		return demandParameter;
	}

	public void setDemandParameter(String demandParameter) {
		this.demandParameter = demandParameter;
	}

	public String getDemandRate() {
		return demandRate;
	}

	public void setDemandRate(String demandRate) {
		this.demandRate = demandRate;
	}

	public String getOverUsageRate() {
		return overUsageRate;
	}

	public void setOverUsageRate(String overUsageRate) {
		this.overUsageRate = overUsageRate;
	}

	public String getDemandPercentage() {
		return demandPercentage;
	}

	public void setDemandPercentage(String demandPercentage) {
		this.demandPercentage = demandPercentage;
	}

	public String getDemandInterval() {
		return demandInterval;
	}

	public void setDemandInterval(String demandInterval) {
		this.demandInterval = demandInterval;
	}
	
}
