package com.engraph.service.dto;


public class SiteDTO {

	public Integer[] siteData;
	public String type;
	
	public Integer[] getSiteData() {
		return siteData;
	}
	public void setSiteData(Integer[] siteData) {
		this.siteData = siteData;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
}
