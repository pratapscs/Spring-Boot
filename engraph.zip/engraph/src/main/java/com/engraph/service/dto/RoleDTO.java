package com.engraph.service.dto;

import com.engraph.model.RoleMaster;
import com.fasterxml.jackson.annotation.JsonProperty;

public class RoleDTO {

	@JsonProperty("role_id")
	private Long roleId;

	@JsonProperty("role_name")
    private String roleName;

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public RoleDTO() {}
	
	public RoleDTO(RoleMaster roleMaster) {
		this.roleId = roleMaster.getRoleId();
		this.roleName = roleMaster.getRoleName();
	}

	
	
	
}
