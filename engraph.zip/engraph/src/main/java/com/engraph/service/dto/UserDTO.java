package com.engraph.service.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

import com.engraph.model.UserRegistration;
import com.fasterxml.jackson.annotation.JsonProperty;

/*
 * A DTO represent user for sign up.
 * 
 * */
public class UserDTO {

	@Size(max = 45)
    private String salutation;
	
    @Size(max = 100)
    @JsonProperty("organizationName")
    private String organizationName;
	
	@Size(max = 100)
	@JsonProperty("firstName")
    private String firstName;

    @Size(max = 100)
    @JsonProperty("lastName")
    private String lastName;

    @Email
    @Size(min = 5, max = 254)
    @JsonProperty("email")
    private String email;

    public UserDTO() {
        // Empty constructor needed for Jackson.
    }
    
	public UserDTO(UserRegistration userRegistration) {
		this.salutation = userRegistration.getSalutation();
		this.organizationName = userRegistration.getOrgId().getOrgName();
		this.firstName = userRegistration.getFirstName();
		this.lastName = userRegistration.getLastName();
		this.email = userRegistration.getEmail();
	}




	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
    
    
    
    
}
