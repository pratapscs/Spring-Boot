package com.engraph.service;

import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.engraph.model.NotificationMaster;
import com.engraph.model.SiteMaster;
import com.engraph.repository.NotificationRepository;
import com.engraph.service.dto.NotificationDTO;

/**
 * Service class for managing site notification details.
 */
@Service
@Transactional
public class NotificationService {

	private static final Logger log = LoggerFactory.getLogger(SiteBuildingDetailsService.class);
	
	@Autowired
	private NotificationRepository notificationRepository;
	
	public NotificationMaster createNotification(@Valid NotificationDTO siteNotificationDTO, SiteMaster siteMaster) {
		 
		 log.debug("Save site notification information");

		NotificationMaster notification = new NotificationMaster();
		
		notification.setParameterType(siteNotificationDTO.getPrameterType());
		notification.setHighestLimit(siteNotificationDTO.getHigherLimit());
   		notification.setLowerLimit(siteNotificationDTO.getLowerLimit());
   		notification.setSiteId(siteMaster);
   		
   		notification = notificationRepository.save(notification);
   		
		return notification;
	}
	
	public Page<NotificationMaster> getAllAlertssofSite(SiteMaster siteId, Pageable pageable) {
		return notificationRepository.findAllBySiteId(siteId, pageable);

	}
}
