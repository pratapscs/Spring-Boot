package com.engraph.service.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MeterAssetDTO {
	
	@JsonProperty("meter_id")
	private Long meterName;
		
	@JsonProperty("building_id")
	private Long buildingName;
	
	@JsonProperty("floor_id")
	private Long floorName;
	
	@JsonProperty("asset_id")
	private Long assetId;

	@JsonProperty("asset_name")
	private String assetName;
	
	@JsonProperty("asset_mac_id")
	private String assetMacId;

	@JsonProperty("asset_manufacturer")
	private String assetManufacturer;

	@JsonProperty("asset_model_no")
	private String assetModelNumber;

	@JsonProperty("asset_batch_no")
	private String assetBatchNumber;

	
	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public Long getMeterName() {
		return meterName;
	}

	public void setMeterName(Long meterName) {
		this.meterName = meterName;
	}

	public Long getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(Long buildingName) {
		this.buildingName = buildingName;
	}

	public Long getFloorName() {
		return floorName;
	}

	public void setFloorName(Long floorName) {
		this.floorName = floorName;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetMacId() {
		return assetMacId;
	}

	public void setAssetMacId(String assetMacId) {
		this.assetMacId = assetMacId;
	}

	public String getAssetManufacturer() {
		return assetManufacturer;
	}

	public void setAssetManufacturer(String assetManufacturer) {
		this.assetManufacturer = assetManufacturer;
	}

	public String getAssetModelNumber() {
		return assetModelNumber;
	}

	public void setAssetModelNumber(String assetModelNumber) {
		this.assetModelNumber = assetModelNumber;
	}

	public String getAssetBatchNumber() {
		return assetBatchNumber;
	}

	public void setAssetBatchNumber(String assetBatchNumber) {
		this.assetBatchNumber = assetBatchNumber;
	}

	
}
