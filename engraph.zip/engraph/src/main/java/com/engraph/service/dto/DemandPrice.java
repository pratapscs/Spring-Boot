package com.engraph.service.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DemandPrice {

	@JsonProperty("demandPrices")
	private List<DemandPriceDTO> demandPrices;

	public List<DemandPriceDTO> getDemandPrices() {
		return demandPrices;
	}

	public void setDemandPrices(List<DemandPriceDTO> demandPrices) {
		this.demandPrices = demandPrices;
	}
	
	

}
