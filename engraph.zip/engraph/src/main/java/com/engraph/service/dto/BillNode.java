package com.engraph.service.dto;

import java.util.ArrayList;
import java.util.List;

public class BillNode {

	private String name;
	private String value;
	private String type;
	private String price;
	private String billData;
	private List<BillNode> children = new ArrayList<BillNode>();


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getBillData() {
		return billData;
	}
	public void setBillData(String billData) {
		this.billData = billData;
	}
	public List<BillNode> getChildren() {
		return children;
	}
	public void setChildren(List<BillNode> children) {
		this.children = children;
	}
	
}
