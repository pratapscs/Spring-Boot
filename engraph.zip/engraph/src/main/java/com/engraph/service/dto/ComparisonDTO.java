package com.engraph.service.dto;


public class ComparisonDTO {

	private String reading;
	private String dateRanges;
	private String firstDate;
	private String secondDate;
	
	
	public String getReading() {
		return reading;
	}
	public void setReading(String reading) {
		this.reading = reading;
	}
	public String getDateRanges() {
		return dateRanges;
	}
	public void setDateRanges(String dateRanges) {
		this.dateRanges = dateRanges;
	}
	public String getFirstDate() {
		return firstDate;
	}
	public void setFirstDate(String firstDate) {
		this.firstDate = firstDate;
	}
	public String getSecondDate() {
		return secondDate;
	}
	public void setSecondDate(String secondDate) {
		this.secondDate = secondDate;
	}
	
	
}
