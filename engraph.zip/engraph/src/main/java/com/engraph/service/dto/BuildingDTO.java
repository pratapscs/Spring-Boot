
package com.engraph.service.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BuildingDTO {

	@JsonProperty("siteId")
	private Long siteId;

	@JsonProperty("buildings")
	private List<SiteBuildingDTO> siteBuildings;

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public List<SiteBuildingDTO> getSiteBuildings() {
		return siteBuildings;
	}

	public void setSiteBuildings(List<SiteBuildingDTO> siteBuildings) {
		this.siteBuildings = siteBuildings;
	}

}
