package com.engraph.service.dto;

import java.util.ArrayList;
import java.util.List;

public class Node {

	private String name;
	private Long value;
	private String type;
	private String billData;
	private List<Node> children = new ArrayList<Node>();
	
	
	public String getBillData() {
		return billData;
	}
	public void setBillData(String billData) {
		this.billData = billData;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getValue() {
		return value;
	}
	public void setValue(Long value) {
		this.value = value;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public List<Node> getChildren() {
		return children;
	}
	public void setChildren(List<Node> children) {
		this.children = children;
	}
	
	@Override
	public String toString() {
		return "Node [name=" + name + ", value=" + value + ", type=" + type + ", children=" + children + "]";
	}
	
	
	
}
