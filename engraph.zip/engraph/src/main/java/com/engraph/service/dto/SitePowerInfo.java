package com.engraph.service.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SitePowerInfo {

	@JsonProperty("siteId")
	private Long siteId;

	@JsonProperty("is_discom")
	private Boolean isDiscom;

	@JsonProperty("is_diesel_generated")
	private Boolean isDieselGenerated;

	@JsonProperty("is_solar_energy")
	private Boolean isSolarEnergy;

	@JsonProperty("is_wind_energy")
	private Boolean isWindEnergy;

	@JsonProperty("is_biomass_energy")
	private Boolean isBiomassEnergy;

	@JsonProperty("is_hydroelectrical_energy")
	private Boolean isHydroelectricalEnergy;

	@JsonProperty("is_geothermal_energy")
	private Boolean isGeothermalEnergy;

	@JsonProperty("is_hydrogen_energy")
	private Boolean isHydrogenEnergy;

	@JsonProperty("is_tidal_energy")
	private Boolean isTidalEnergy;

	@JsonProperty("is_wave_energy")
	private Boolean isWaveEnergy;

	@JsonProperty("is_nuclear_energy")
	private Boolean isNuclearEnergy;

	@JsonProperty("is_fuel_cell")
	private Boolean isFuelCell;
	
	@JsonProperty("all_source_meter")
	private Boolean allSourceMeter;
	
	@JsonProperty("powerSources")
	private List<SiteBuildingDTO> siteBuildings;
	

	public Boolean getAllSourceMeter() {
		return allSourceMeter;
	}

	public void setAllSourceMeter(Boolean allSourceMeter) {
		this.allSourceMeter = allSourceMeter;
	}

	@JsonProperty("non_meter_source")
	private String nonMeterSource;

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public Boolean getIsDiscom() {
		return isDiscom;
	}

	public void setIsDiscom(Boolean isDiscom) {
		this.isDiscom = isDiscom;
	}

	public Boolean getIsDieselGenerated() {
		return isDieselGenerated;
	}

	public void setIsDieselGenerated(Boolean isDieselGenerated) {
		this.isDieselGenerated = isDieselGenerated;
	}

	public Boolean getIsSolarEnergy() {
		return isSolarEnergy;
	}

	public void setIsSolarEnergy(Boolean isSolarEnergy) {
		this.isSolarEnergy = isSolarEnergy;
	}

	public Boolean getIsWindEnergy() {
		return isWindEnergy;
	}

	public void setIsWindEnergy(Boolean isWindEnergy) {
		this.isWindEnergy = isWindEnergy;
	}

	public Boolean getIsBiomassEnergy() {
		return isBiomassEnergy;
	}

	public void setIsBiomassEnergy(Boolean isBiomassEnergy) {
		this.isBiomassEnergy = isBiomassEnergy;
	}

	public Boolean getIsHydroelectricalEnergy() {
		return isHydroelectricalEnergy;
	}

	public void setIsHydroelectricalEnergy(Boolean isHydroelectricalEnergy) {
		this.isHydroelectricalEnergy = isHydroelectricalEnergy;
	}

	public Boolean getIsGeothermalEnergy() {
		return isGeothermalEnergy;
	}

	public void setIsGeothermalEnergy(Boolean isGeothermalEnergy) {
		this.isGeothermalEnergy = isGeothermalEnergy;
	}

	public Boolean getIsHydrogenEnergy() {
		return isHydrogenEnergy;
	}

	public void setIsHydrogenEnergy(Boolean isHydrogenEnergy) {
		this.isHydrogenEnergy = isHydrogenEnergy;
	}

	public Boolean getIsTidalEnergy() {
		return isTidalEnergy;
	}

	public void setIsTidalEnergy(Boolean isTidalEnergy) {
		this.isTidalEnergy = isTidalEnergy;
	}

	public Boolean getIsWaveEnergy() {
		return isWaveEnergy;
	}

	public void setIsWaveEnergy(Boolean isWaveEnergy) {
		this.isWaveEnergy = isWaveEnergy;
	}

	public Boolean getIsNuclearEnergy() {
		return isNuclearEnergy;
	}

	public void setIsNuclearEnergy(Boolean isNuclearEnergy) {
		this.isNuclearEnergy = isNuclearEnergy;
	}

	public Boolean getIsFuelCell() {
		return isFuelCell;
	}

	public void setIsFuelCell(Boolean isFuelCell) {
		this.isFuelCell = isFuelCell;
	}

	public String getNonMeterSource() {
		return nonMeterSource;
	}

	public void setNonMeterSource(String nonMeterSource) {
		this.nonMeterSource = nonMeterSource;
	}

}
