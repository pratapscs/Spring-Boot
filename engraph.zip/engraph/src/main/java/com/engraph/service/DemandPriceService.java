package com.engraph.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.engraph.model.DemandPriceMaster;
import com.engraph.repository.DemandPriceRepository;
import com.engraph.service.dto.DemandPrice;
import com.engraph.service.dto.DemandPriceDTO;


/**
 * Service class for managing demand price.
 */
@Service
@Transactional
public class DemandPriceService {
	
	private static final Logger log = LoggerFactory.getLogger(DemandPriceService.class);

	@Autowired
	private DemandPriceRepository demandPriceRepository;
	
	public List<DemandPriceMaster> saveDemandPriceInfo(@Valid DemandPrice demandPriceInfo) {
		
		log.debug("Save Demand Price information");
        List<DemandPriceMaster> demandPrices = new ArrayList<DemandPriceMaster>();
        
        for (DemandPriceDTO demandPriceDTO : demandPriceInfo.getDemandPrices()) {
        	
        	DemandPriceMaster demandPrice = new DemandPriceMaster();
    		
        	demandPrice.setStartDate(demandPriceDTO.getStartDate());
    		demandPrice.setEndDate(demandPriceDTO.getEndDate());
    		demandPrice.setContractDemand(demandPriceDTO.getContractDemand());
    		demandPrice.setDemandParameter(demandPriceDTO.getDemandParameter());
    		demandPrice.setDemandRate(demandPriceDTO.getDemandRate());
    		demandPrice.setOverUsageRate(demandPriceDTO.getOverUsageRate());
    		demandPrice.setDemandPercentage(demandPriceDTO.getDemandPercentage() );
    		demandPrice.setDemandIntervel(demandPriceDTO.getDemandInterval());
    	
    		demandPriceRepository.save(demandPrice);
    		demandPrices.add(demandPrice);
        }
        return demandPrices;
	}
}
