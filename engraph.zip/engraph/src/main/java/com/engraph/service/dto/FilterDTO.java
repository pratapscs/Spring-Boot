package com.engraph.service.dto;


import java.util.ArrayList;
import java.util.List;

public class FilterDTO {

	//private List<ComponentDTO> filters = new ArrayList<ComponentDTO>();
	private List<List<ComponentDTO>> filters =  new ArrayList<>();

	public List<List<ComponentDTO>> getFilters() {
		return filters;
	}

	public void setFilters(List<List<ComponentDTO>> filters) {
		this.filters = filters;
	}

	/*
	 * public List<ComponentDTO> getFilters() { return filters; }
	 * 
	 * public void setFilters(List<ComponentDTO> filters) { this.filters = filters;
	 * }
	 */

	
	
	
}
