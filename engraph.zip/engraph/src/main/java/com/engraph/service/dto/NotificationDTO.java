package com.engraph.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class NotificationDTO {

	@JsonProperty("organizationName")
	private String organizationName;
	
	@JsonProperty("prameterType")
	private String prameterType;
	
	@JsonProperty("higherLimit")
	private Integer higherLimit;
	
	@JsonProperty("lowerLimit")
	private Integer lowerLimit;
	
	@JsonProperty("siteId")
	private Long siteId;

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	
	public String getPrameterType() {
		return prameterType;
	}

	public void setPrameterType(String prameterType) {
		this.prameterType = prameterType;
	}

	public Integer getHigherLimit() {
		return higherLimit;
	}

	public void setHigherLimit(Integer higherLimit) {
		this.higherLimit = higherLimit;
	}

	public Integer getLowerLimit() {
		return lowerLimit;
	}

	public void setLowerLimit(Integer lowerLimit) {
		this.lowerLimit = lowerLimit;
	}

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}
	
	
}
