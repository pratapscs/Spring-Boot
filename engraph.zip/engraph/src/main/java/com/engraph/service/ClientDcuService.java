package com.engraph.service;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.engraph.model.ClientDCUConfig;
import com.engraph.model.Dcudetails;
import com.engraph.model.SiteMaster;
import com.engraph.repository.ClientDCURepository;
import com.engraph.service.dto.ClientDCUDTO;

/**
 * Service class for managing client DCU.
 */
@Service
@Transactional
public class ClientDcuService {
	
	private static final Logger log = LoggerFactory.getLogger(ClientDcuService.class);
	
	@Autowired
	private ClientDCURepository clientDcuRepository;
	
	public ClientDCUConfig saveClientDCUInfo(@Valid ClientDCUDTO clientDCU, SiteMaster site, Dcudetails dcu) {
		ClientDCUConfig clientDCUConfig = new ClientDCUConfig();
		clientDCUConfig.setFrequency(clientDCU.getFrequency());
		clientDCUConfig.setFtpUID(clientDCU.getFtpUID());
		clientDCUConfig.setFtpURL(clientDCU.getFtpURL());
		clientDCUConfig.setFtpPassword(clientDCU.getFtpPassword());
		clientDCUConfig.setFtpPortNumber(clientDCU.getFtpPortNumber());
		clientDCUConfig.setBaudRate(clientDCU.getBaudRate());
		clientDCUConfig.setParity(clientDCU.getParity());
		clientDCUConfig.setStopBit(clientDCU.getStopBit());
		clientDCUConfig.setSiteId(site);
		clientDCUConfig.setDcuId(dcu);
		return clientDcuRepository.save(clientDCUConfig);
	}

}
