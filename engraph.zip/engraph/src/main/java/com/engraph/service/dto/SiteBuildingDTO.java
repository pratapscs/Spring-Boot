package com.engraph.service.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

//@JsonFilter("siteBuildingDTO")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SiteBuildingDTO {

	@JsonProperty("building_id")
	private Long buildingId;
	
	@JsonProperty("building_number")
	private String buildingNumber;

	@JsonProperty("building_name")
	private String buildingName;

	@JsonProperty("building_buildup_area")
	private Double buildingBuildupArea;

	@JsonProperty("building_terrace_area")
	private Double buildingTerraceArea;

	@JsonProperty("building_total_meters")
	private Double buildingTotalMeters;

	@JsonProperty("building_total_floor")
	private Integer buildingTotalFloors;

	@JsonProperty("building_electrical_diagram")
	private String buildingElectricalDiagram;

	@JsonProperty("floors")
	private List<BuildingFloorDTO> floors;

	
	
	public Long getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(Long buildingId) {
		this.buildingId = buildingId;
	}

	public List<BuildingFloorDTO> getFloors() {
		return floors;
	}

	public void setFloors(List<BuildingFloorDTO> floors) {
		this.floors = floors;
	}

	public String getBuildingNumber() {
		return buildingNumber;
	}

	public void setBuildingNumber(String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public Double getBuildingBuildupArea() {
		return buildingBuildupArea;
	}

	public void setBuildingBuildupArea(Double buildingBuildupArea) {
		this.buildingBuildupArea = buildingBuildupArea;
	}

	public Double getBuildingTerraceArea() {
		return buildingTerraceArea;
	}

	public void setBuildingTerraceArea(Double buildingTerraceArea) {
		this.buildingTerraceArea = buildingTerraceArea;
	}

	public Double getBuildingTotalMeters() {
		return buildingTotalMeters;
	}

	public void setBuildingTotalMeters(Double buildingTotalMeters) {
		this.buildingTotalMeters = buildingTotalMeters;
	}

	public Integer getBuildingTotalFloors() {
		return buildingTotalFloors;
	}

	public void setBuildingTotalFloors(Integer buildingTotalFloors) {
		this.buildingTotalFloors = buildingTotalFloors;
	}

	public String getBuildingElectricalDiagram() {
		return buildingElectricalDiagram;
	}

	public void setBuildingElectricalDiagram(String buildingElectricalDiagram) {
		this.buildingElectricalDiagram = buildingElectricalDiagram;
	}

}
