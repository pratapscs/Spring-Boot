package com.engraph.service.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.engraph.model.EletricityMeter;
import com.engraph.service.AssetService;

public class ExcelUtils {

	private static final Logger log = LoggerFactory.getLogger(ExcelUtils.class);
	
	public static List<EletricityMeter> parseExcelFile(InputStream is) {

		try {
			XSSFWorkbook wb = new XSSFWorkbook(is);

			for (int i = 0; i < wb.getNumberOfSheets(); i++) {
				XSSFSheet sheet = wb.getSheetAt(i);

				Iterator<Row> rows = sheet.iterator();

				List<EletricityMeter> lstMeters = new ArrayList<EletricityMeter>();
				int rowNumber = i;
				while (rows.hasNext()) {
					Row currentRow = rows.next();
					// skip header
					if (rowNumber == i) {
						rowNumber++;
						continue;
					}
					Iterator<Cell> cellsInRow = currentRow.iterator();
					EletricityMeter meter = new EletricityMeter();

					int cellIndex = i;
					while (cellsInRow.hasNext()) {
						Cell currentCell = cellsInRow.next();
						if (cellIndex == i) { // meterNumber
							meter.setMeterNumber(currentCell.getStringCellValue());
						} else if (cellIndex == 1) { // meterName
							meter.setMeterName(currentCell.getStringCellValue());
						} else if (cellIndex == 2) { // meterSlaveId
							meter.setMeterSlaveId(currentCell.getStringCellValue());
						} else if (cellIndex == 3) { // meterMacId
							meter.setMeterMacId(currentCell.getStringCellValue());
						} else if (cellIndex == 4) { // meterManufacturer
							meter.setMeterManufacturer(currentCell.getStringCellValue());
						} else if (cellIndex == 5) { // meterModelNumber
							meter.setMeterModelNumber(currentCell.getStringCellValue());
						} else if (cellIndex == 6) { // meterBatchNumber
							meter.setMeterBatchNumber(currentCell.getStringCellValue());
						}
						cellIndex++;
					}
					lstMeters.add(meter);
				}
				// Close WorkBook
				wb.close();
				return lstMeters;
			}

		} catch (IOException e) {
			throw new RuntimeException("FAIL! -> message = " + e.getMessage());
		}
		return null;

	}

}
