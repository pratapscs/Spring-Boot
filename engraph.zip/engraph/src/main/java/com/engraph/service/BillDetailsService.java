package com.engraph.service;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.engraph.model.BillMaster;
import com.engraph.model.DiscomCategoryBusinessTypeMaster;
import com.engraph.model.DiscomMaster;
import com.engraph.model.LocationMaster;
import com.engraph.model.PowerTensionMaster;
import com.engraph.model.SiteMaster;
import com.engraph.repository.BillMasterRepository;
import com.engraph.service.dto.BillGeneralInfo;

/**
 * Service class for managing bill.
 */
@Service
@Transactional
public class BillDetailsService {

	private static final Logger log = LoggerFactory.getLogger(BillDetailsService.class);

	@Autowired
	@Qualifier("jdbcTemplatePhoenix")
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private BillMasterRepository billMasterRepository;

	public BillMaster saveBillInfo(@Valid BillGeneralInfo billGeneralInfo, 
										  DiscomMaster discomMaster,
										  PowerTensionMaster powerTensionMaster,
										  DiscomCategoryBusinessTypeMaster discomCategoryMaster,
										  SiteMaster siteMaster,
										  LocationMaster locationMaster
										  ) {
		log.debug("Save Bill information");
		BillMaster billMaster = new BillMaster();
		//billMaster.setCountry(billGeneralInfo.getCountry());
		//billMaster.setState(billGeneralInfo.getState());
        billMaster.setLocationId(locationMaster);
		billMaster.setDiscomId(discomMaster);
		billMaster.setPowerTensionId(powerTensionMaster);
		billMaster.setDiscomCategoryId(discomCategoryMaster);
		billMaster.setPhaseConnection(billGeneralInfo.getSitePhaseConnection());
		billMaster.setBillParameter(billGeneralInfo.getElectricityBillingParameter());
		billMaster.setBillCurrency(billGeneralInfo.getBillingCurrency());
		billMaster.setMeterRent(billGeneralInfo.getMeterRent());
		billMaster.setBillPaymentDate(billGeneralInfo.getLastBillPaymentDate());
		billMaster.setElectricityBill(billGeneralInfo.getElectricityBill());

		return billMasterRepository.save(billMaster);
	}
	
	
	
}
