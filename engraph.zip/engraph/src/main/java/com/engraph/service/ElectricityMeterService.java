package com.engraph.service;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.engraph.model.EletricityMeter;
import com.engraph.model.SiteMaster;
import com.engraph.repository.ElectricityMeterRepository;
import com.engraph.service.util.ExcelUtils;

/**
 * Service class for Electricity Meters.
 */
@Service
@Transactional
public class ElectricityMeterService {

	private static final Logger log = LoggerFactory.getLogger(ElectricityMeterService.class);

	@Autowired
	private ElectricityMeterRepository electricityMeterRepository;

	public List<EletricityMeter> storeMeterData(MultipartFile file, SiteMaster siteMater) throws IOException {

		List<EletricityMeter> lstMeters = ExcelUtils.parseExcelFile(file.getInputStream());
		// Save Meters to DataBase
		log.debug("Save electricity meter information");

		for (EletricityMeter meterDTO : lstMeters) {
			EletricityMeter electricityMeter = new EletricityMeter();
			electricityMeter.setMeterNumber(meterDTO.getMeterNumber());
			electricityMeter.setMeterName(meterDTO.getMeterName());
			electricityMeter.setMeterSlaveId(meterDTO.getMeterSlaveId());
			electricityMeter.setMeterMacId(meterDTO.getMeterMacId());
			electricityMeter.setMeterManufacturer(meterDTO.getMeterManufacturer());
			electricityMeter.setMeterModelNumber(meterDTO.getMeterModelNumber());
			electricityMeter.setMeterBatchNumber(meterDTO.getMeterBatchNumber());
			electricityMeter.setSiteId(siteMater);
			electricityMeterRepository.save(electricityMeter);
		}
		return lstMeters;
	}

	public Page<EletricityMeter> getAllMerersofSite(SiteMaster siteId, Pageable pageable) {
		return electricityMeterRepository.findAllBySiteId(siteId, pageable);

	}

}
