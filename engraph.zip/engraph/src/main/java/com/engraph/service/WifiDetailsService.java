package com.engraph.service;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.engraph.model.SiteMaster;
import com.engraph.model.WifiDetails;
import com.engraph.repository.WifiRepository;
import com.engraph.service.dto.WifiDetailsDTO;

@Service
@Transactional
public class WifiDetailsService {
	
	private static final Logger log = LoggerFactory.getLogger(WifiDetailsService.class);
	
	@Autowired
	private WifiRepository wifiRepository;
	
	public WifiDetails saveWifiDetails(@Valid WifiDetailsDTO wifiDetailsDTO,SiteMaster site) {
		WifiDetails wifiDetails = new WifiDetails();
		wifiDetails.setSiteId(site);
		wifiDetails.setWifiName(wifiDetailsDTO.getWifiName());
		wifiDetails.setWifiPassword(wifiDetailsDTO.getWifiPassword());
		return wifiRepository.save(wifiDetails);
	}
	

	public Page<WifiDetails> getAllWifiDetailsofSite(SiteMaster siteId, Pageable pageable) {
		return wifiRepository.findAllBySiteId(siteId, pageable);

	}

}
