package com.engraph.controller.error;

import java.net.URI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ErrorConstants {

	private static final Logger logger = LoggerFactory.getLogger(ErrorConstants.class);
	
	public static final String PROBLEM_BASE_URL = "localhost:8080/problem";
	public static final URI DEFAULT_TYPE = URI.create(PROBLEM_BASE_URL + "/problem-with-message");
	public static final URI EMAIL_ALREADY_USED_TYPE = URI.create(PROBLEM_BASE_URL + "/email-already-used");
	public static final URI EMAIL_NOT_FOUND_TYPE = URI.create(PROBLEM_BASE_URL + "/email-not-found");
	public static final URI INVALID_PASSWORD_TYPE = URI.create(PROBLEM_BASE_URL + "/invalid-password");
	
}
