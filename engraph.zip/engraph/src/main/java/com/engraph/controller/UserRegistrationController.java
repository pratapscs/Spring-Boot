package com.engraph.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.model.Organization;
import com.engraph.model.UserRegistration;
import com.engraph.repository.OrganizationRepository;
import com.engraph.repository.UserRegistrationRepository;
import com.engraph.service.MailService;
import com.engraph.service.UserRegistrationService;
import com.engraph.service.dto.KeyAndPasswordDTO;
import com.engraph.service.dto.LoginDTO;
import com.engraph.service.dto.OrganizationDTO;
import com.engraph.service.dto.UserDTO;
import com.engraph.config.Constants;
import com.engraph.controller.error.BadRequestAlertException;
import com.engraph.controller.error.EmailAlreadyUsedException;
import com.engraph.controller.error.EmailNotFoundException;
import com.engraph.controller.error.InvalidPasswordException;
import com.engraph.controller.error.AccountResourceException;
import com.engraph.controller.error.OrganizationResourceException;
import com.engraph.controller.util.PaginationUtil;

import com.engraph.controller.util.HeaderUtil;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
@Transactional
public class UserRegistrationController {

	private static final Logger log = LoggerFactory.getLogger(UserRegistrationController.class);

	private String ENTITY_NAME = "userManagement";

	private String applicationName = "engraph";

	@Autowired
	private UserRegistrationRepository userRegistrationRepository;

	@Autowired
	private UserRegistrationService userRegistrationService;

	@Autowired
	private OrganizationRepository organizationRepository;

	@Autowired
	private MailService mailService;

	
	/**
	 * {@code POST  /registration} : Creates a new user.
	 * 
	 * Creates a new user if the email are not already used, and sends an mail with an activation link. 
	 * The user needs to be activated on creation.
	 *
	 * @param userDTO the user to create.
	 * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with
	 *         body the new user, or with status {@code 400 (Bad Request)} if the
	 *         login or email is already in use.
	 * @throws URISyntaxException - if the Location URI syntax is incorrect.
	 * @throws BadRequestAlertException {@code 400 (Bad Request)} if the email is already in use.                               
	 */
	@PostMapping("/registration")
	public ResponseEntity<UserRegistration> createUser(@Valid @RequestBody UserDTO userDTO) throws URISyntaxException {
	
		log.debug("REST request to save User : {}", userDTO);

		if (userDTO.getEmail() == null || userDTO.getEmail().isEmpty()) {
			
			throw new BadRequestAlertException("A new user must have an Email address", ENTITY_NAME, "LoginNotexists");
		
		} else if (userRegistrationRepository.findOneByEmailIgnoreCase(userDTO.getEmail()).isPresent()) {
			
			throw new EmailAlreadyUsedException();
			
		} else {
			
			UserRegistration newUser = userRegistrationService.createUser(userDTO);
			
			mailService.sendCreationEmail(newUser);
			
			return ResponseEntity.created(new URI("/engraph/registration/" + newUser.getEmail()))
					.headers(HeaderUtil.createAlert(applicationName, ENTITY_NAME, newUser.getEmail())).body(newUser);
		}
	}

	/**
	 * {@code GET  /registration} : Creates a new user.
	 * 
	 * Creates a new user if the email are not already used, and sends an mail with an activation link. 
	 * The user needs to be activated on creation.
	 *
	 * @param userDTO the user to create.
	 * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with
	 *         body the new user, or with status {@code 400 (Bad Request)} if the
	 *         login or email is already in use.
	 * @throws URISyntaxException - if the Location URI syntax is incorrect.
	 * @throws BadRequestAlertException {@code 400 (Bad Request)} if the email is already in use.                               
	 */
	@GetMapping("/login/{authkey}")
	public ResponseEntity<?> validateAuthKey(@PathVariable String authkey) throws URISyntaxException {
	
	log.debug("Rest request of validate auth key ");
		
	Optional<UserRegistration> userRegistration = userRegistrationService.validateAuthKey(authkey);

		if (userRegistration.isPresent())
			return new ResponseEntity<>(userRegistration.map(UserDTO::new), HttpStatus.OK);
		else
			throw new BadRequestAlertException("User could not be found", ENTITY_NAME, "`	");
	}

	
	/** 
	 * Update initial password setup
	 * 
	 */
	@PostMapping(path = "/updatepassword")
     public ResponseEntity<?> updateInitialUserPassword(@RequestBody UserRegistration user) {
  
    	 Optional<UserRegistration> userRegistration = 
    			 userRegistrationService.getUserByAuthKeyAndEmail(user.getActivationKey(), user.getEmail());
    	
    	 if (userRegistration.isPresent()) {
    		 UserRegistration registration = userRegistrationService.updateIntitialUserPassword(userRegistration,user);
    		 return new ResponseEntity<>(registration, HttpStatus.OK);
    	 }
    		 
 		else
 			throw new BadRequestAlertException("User could not be found", ENTITY_NAME, "UserNotExists");
     }
  
	
	/** 
	 * User Login 
	 * 
	 */
	@PostMapping("/userlogin")
	public UserRegistration login(@RequestBody UserRegistration user){
		
		log.debug("start login method of user : ");
		
		UserRegistration existingUser = new UserRegistration();
		
		log.debug("Existring User : " + existingUser);
		
		Optional<UserRegistration> dbUserObject = userRegistrationRepository.findOneByEmail(user.getEmail());

		if(dbUserObject.isPresent()) {
			if (dbUserObject.get().getPassword().equals(user.getPassword())) {
			      user= dbUserObject.get();
			      user.setIsValidUser(true);
			      user.setMessage("Success");
			}
			else{
				user.setIsValidUser(false);
				user.setMessage("Invalid email and passoword!");
			}
		}
		else{
			user.setIsValidUser(false);
			user.setMessage("User does not exists!");
		}
		return user;
	}
	

	/**
	 * {@code POST  /org-details } : Creates a new site and save general information.
	 * <p>
	 *
	 * @param SiteGeneralInfo the site to create.
	 * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with
	 *         body the new site, or with status {@code 400 (Bad Request)} if org id
	 *         is missing or not exists.
	 * @throws URISyntaxException if the Location URI syntax is incorrect.
	 */
	@PostMapping("/org-details")
	public ResponseEntity<Organization> saveOrgDetails(@Valid @RequestBody OrganizationDTO organizationDTO) throws URISyntaxException {
		
		log.debug("REST request to save site : {} ", organizationDTO);
        
		log.debug("Organization Id : " + organizationDTO.getOrgId());
		
		if (organizationDTO.getOrgId() == null) {
			throw new BadRequestAlertException("An Org ID is must for save Organization", ENTITY_NAME, "idRequired");
		}
		
		// update the organization details.
		Optional<Organization> organization = organizationRepository.findByOrgId(organizationDTO.getOrgId());
		
		if (!organization.isPresent()) {
			throw new BadRequestAlertException("An Organization is not exists ", ENTITY_NAME, "OrgNotExists");
		}

		Organization org = userRegistrationService.updateOrg(organization.get(), organizationDTO);
		
		return ResponseEntity.created(new URI("/engraph/site-general-info/" + org.getOrgId()))
								.headers(HeaderUtil.createAlert(applicationName, ENTITY_NAME, org.getOrgName())).body(org);

	}
	
	/**
	 * {@code GET /users} : get all users of an organization.
	 *
	 * @param pageable the pagination information. @return the {@link
	 * ResponseEntity} with status {@code 200 (OK)} and with body all users. @throws
	 */
    @GetMapping("/org-users")
    public ResponseEntity<List<UserRegistration>> getAllUsersofOrganization(
    							@RequestParam(name = "orgId", required = false) Long orgId, Pageable pageable) 
    								throws URISyntaxException {
    	
        log.debug("Rest request of  get all user of organization ");
        
        //Find org object from name. 
        Optional<Organization> organization =  organizationRepository.findByOrgId(orgId);
        
        if(!organization.isPresent())
        	throw new OrganizationResourceException("No Organization was found for this org_id");
    	
        final Page<UserRegistration> page = userRegistrationService.getAllUsersofOrganization(organization.get(), pageable);
        
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/engraph/org-users");
        
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
	
	
	/**
	 * {@code POST   /account/reset-password/init} : Send an email to reset the password of the user.
	 *
	 * @param mail the mail of the user.
	 * @throws EmailNotFoundException {@code 400 (Bad Request)} if the email address is not registered.
	 * 
	 */
	@PostMapping(path = "/account/reset-password/init")
	public void requestPasswordReset(@RequestBody String mail) {
		mailService.sendPasswordResetMail(userRegistrationService.requestPasswordReset(mail)
																	.orElseThrow(EmailNotFoundException::new));
	}
	

	@PostMapping("/authenticate")
    public ResponseEntity<String> authorize(@Valid @RequestBody LoginDTO loginDTO) {
		
		log.debug("REST request to authenticate {}", loginDTO);
	    
		Optional<UserRegistration> userRegistration = 
					userRegistrationService.authenticate(loginDTO.getPassword(), loginDTO.getUsername());
	    
	    if(userRegistration.isPresent())
	    	return new ResponseEntity<>("Success", HttpStatus.OK);
	    else
	        return new ResponseEntity<>("Failed", HttpStatus.OK);
	}
    
	
	/**
	 * {@code POST   /account/reset-password/finish} : Finish to reset the password of the user.
	 *
	 * @param keyAndPassword the generated key and the new password.
	 * @throws InvalidPasswordException {@code 400 (Bad Request)} if the password is incorrect.
	 * @throws RuntimeException {@code 500 (Internal Server Error)} if the password could not be reset.
	 */
	@PostMapping(path = "/account/reset-password/finish")
	public void finishPasswordReset(@RequestBody KeyAndPasswordDTO keyAndPassword) {
		
		if (!checkPasswordLength(keyAndPassword.getPassword())) {
			throw new InvalidPasswordException();
		}
		
		Optional<UserRegistration> userRegistration = userRegistrationService.completePasswordReset(keyAndPassword.getPassword(), keyAndPassword.getKey());

		if (!userRegistration.isPresent()) {
			throw new AccountResourceException("No user was found for this reset key");
		}
	}

	private static boolean checkPasswordLength(String password) {
		return !StringUtils.isEmpty(password) && password.length() >= Constants.PASSWORD_MIN_LENGTH
				&& password.length() <= Constants.PASSWORD_MAX_LENGTH;
	}
		
	
	/**
	 * POST /account/set-password : changes the current user's password
	 *
	 * @param string current and new password
	 * @throws InvalidPasswordException 400 (Bad Request) if the new password is incorrect
	 */
	@PostMapping(path = "/account/change-password")
	public ResponseEntity<String> changePassword(@RequestBody KeyAndPasswordDTO usernameAndPassword) {
		
		if (!checkPasswordLength(usernameAndPassword.getPassword())) {
			throw new InvalidPasswordException();
		}
		
		Optional<UserRegistration> userRegistration = userRegistrationService.setPassword(usernameAndPassword.getPassword(), usernameAndPassword.getKey());

		if (userRegistration.isPresent())
			return new ResponseEntity<>("Success", HttpStatus.OK);
		else
			return new ResponseEntity<>("Failed", HttpStatus.OK);
	}
	
}