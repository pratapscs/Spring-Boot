package com.engraph.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.controller.error.BadRequestAlertException;
import com.engraph.model.BuildingFloor;
import com.engraph.service.BuildingFloorDetailService;;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class BuildingFloorController {

	private static final Logger log = LoggerFactory.getLogger(BuildingFloorController.class);

	private String ENTITY_NAME = "BuildingFloor";

	private String applicationName = "engraph";

	@Autowired
	private BuildingFloorDetailService buildingFloorService;


	/**
	 * {@code POST /building-floor} : Creates a new Floor and save building Floor
	 * information.
	 * <p>
	 *
	 * @param BuildingFloor the building to create.
	 * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with
	 *         body the new Floor, or with status {@code 400 (Bad Request)} if
	 *         Building id is missing or not exists.
	 * @throws URISyntaxException if the Location URI syntax is incorrect.
	 */

	/*
	 * @PostMapping("/building-floor") public ResponseEntity<BuildingFloor>
	 * createBuildingFloor(@Valid @RequestBody BuildingFloorDTO buildingFloorDTO)
	 * throws URISyntaxException {
	 * log.debug("REST request to save Building Floor : {}", buildingFloorDTO); if
	 * (buildingFloorDTO.getSiteBuildingId() == null) { throw new
	 * BadRequestAlertException("An Site Building ID is must for create Floor",
	 * ENTITY_NAME, "idRequired"); } // update the Site Building details.
	 * 
	 * Optional<SiteBuilding> siteBuilding = siteBuildingRepository
	 * .findBySiteBuildingId(buildingFloorDTO.getSiteBuildingId()); if
	 * (!siteBuilding.isPresent()) { throw new
	 * BadRequestAlertException("An Site Building is not exists ", ENTITY_NAME,
	 * "SiteBuildingNotExists"); }
	 * 
	 * BuildingFloor buildingFloor =
	 * buildingFloorService.saveBuildingFloorInfo(buildingFloorDTO); return
	 * ResponseEntity .created(new URI("/engraph/building-floor/" +
	 * buildingFloor.getBuildingFloorId())).headers(HeaderUtil
	 * .createAlert(applicationName, ENTITY_NAME,
	 * buildingFloor.getBuildingFloorId().toString())) .body(buildingFloor); }
	 */

	/**
	 * GET /building-floor/:id : get the "id" building and floor.
	 *
	 * @param id the id of the building to retrieve
	 * @return the ResponseEntity with status 200 (OK) and with body the
	 *         BuildingFloor, or with status 404 (Not Found)
	 */
	@GetMapping("/building-floor/{id}")
	public ResponseEntity<BuildingFloor> getBuildingFloor(@PathVariable Long id) {
		log.debug("REST request to get BuildingFloor : {}", id);
		Optional<BuildingFloor> buildingFloor = buildingFloorService.findOne(id);
		if (buildingFloor.isPresent())
			return new ResponseEntity<>(buildingFloor.get(), HttpStatus.OK);
		else
			throw new BadRequestAlertException("BuildingFloor could not be found", ENTITY_NAME,
					"BuildingFloorNotExists");

	}
}
