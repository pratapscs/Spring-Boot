package com.engraph.controller;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.engraph.controller.error.BadRequestAlertException;
import com.engraph.controller.error.SiteResourceException;
import com.engraph.controller.util.HeaderUtil;
import com.engraph.controller.util.PaginationUtil;
import com.engraph.model.EletricityMeter;
import com.engraph.model.SiteMaster;
import com.engraph.repository.SiteMasterRepository;
import com.engraph.service.ElectricityMeterService;
import com.engraph.service.FileService;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class ElectricityMeterDetailsController {

	private static final Logger log = LoggerFactory.getLogger(ElectricityMeterDetailsController.class);

	private String ENTITY_NAME = "ElectricityMeterDetails";

	private String applicationName = "engraph";
	
	@Autowired
	private FileService fileService;

	@Autowired
	private ElectricityMeterService electricityMeterService;

	@Autowired
	private SiteMasterRepository siteMasterRepository;
	
	
	@GetMapping(value = "/meterfile/{filename}")
	@ResponseStatus(HttpStatus.OK)
	public Resource getFileFromClasspath(@PathVariable String filename, HttpServletResponse response) {
		return fileService.getClassPathFile(filename, response);
	}

	@PostMapping("/electricity-meter-info")
	public ResponseEntity<List<EletricityMeter>> uploadMultipartFile(@RequestParam("file") MultipartFile file,
			SiteMaster site) throws IOException, URISyntaxException {
		log.debug("REST request to save meter : {}", site);

		if (site.getSiteId() == null) {
			throw new BadRequestAlertException("An Site ID is must for save meter details", ENTITY_NAME, "idRequired");
		}

		Optional<SiteMaster> siteMaster = siteMasterRepository.findBySiteId(site.getSiteId());
		if (!siteMaster.isPresent()) {
			throw new BadRequestAlertException("An Site is not exists ", ENTITY_NAME, "SiteNotExists");
		}
		List<EletricityMeter> meter = electricityMeterService.storeMeterData(file, siteMaster.get());
		return ResponseEntity.created(new URI("/engraph/electricity-meter-info/" + meter.get(0).getMeterNumber()))
				.headers(HeaderUtil.createAlert(applicationName, ENTITY_NAME, meter.get(0).getMeterNumber().toString()))
				.body(meter);
	}

	/**
	 * {@code GET /site-meters} : get all meters of an site.
	 *
	 * @param pageable the pagination information. @return the
	 *                 {@link ResponseEntity} with status {@code 200 (OK)} and with
	 *                 body all meters. @throws
	 */
	@GetMapping("/site-meters")
	public ResponseEntity<List<EletricityMeter>> getAllMetersofSite(
			@RequestParam(name = "siteId", required = false) Long siteId, Pageable pageable) throws URISyntaxException {
		log.debug("Rest request of  get all user of organization ");

		Optional<SiteMaster> site = siteMasterRepository.findBySiteId(siteId);

		if (!site.isPresent())
			throw new SiteResourceException("No Site was found for this siteId");
		final Page<EletricityMeter> page = electricityMeterService.getAllMerersofSite(site.get(), pageable);
		HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/engraph/site-meters");
		return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
	}

	/**
	 * {@code POST  /electricity-meter-info} : Creates a new Electricity Meter
	 * information.
	 * <p>
	 *
	 * @param ElectricityMeterInfo the electricity meter to create.
	 * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with
	 *         body the new electricity meter, or with status
	 *         {@code 400 (Bad Request)} if building Floor Id is missing or not
	 *         exists.
	 * @throws URISyntaxException if the Location URI syntax is incorrect.
	 */
	/*
	 * @PostMapping("/") public ResponseEntity<EletricityMeter>
	 * createElectricityMeterInfo(@Valid @RequestBody ElectricityMeterInfo
	 * electricityMeterInfo) throws URISyntaxException {
	 * log.debug("REST request to save electricity Meter : {}",
	 * electricityMeterInfo); if(electricityMeterInfo.getBuildingFloorId() == null)
	 * { throw new
	 * BadRequestAlertException("An Building Floor ID is must for create Electricity Meter"
	 * , ENTITY_NAME, "idRequired"); } //update the Building Floor details.
	 * Optional<BuildingFloor> buildingFloor =
	 * buildingFloorRepository.findByBuildingFloorId(electricityMeterInfo.
	 * getBuildingFloorId()); if(!buildingFloor.isPresent()) { throw new
	 * BadRequestAlertException("An BuildingFloorMaster is not exists ",
	 * ENTITY_NAME, "BuildingFloorMasterNotExists"); }
	 * 
	 * EletricityMeter electricityMater =
	 * electricityMeterService.saveEletricityMeterInfo(electricityMeterInfo); return
	 * ResponseEntity.created(new URI("/engraph/electricity-meter-info/" +
	 * electricityMater.getElectricityMeterId()))
	 * .headers(HeaderUtil.createAlert(applicationName, ENTITY_NAME,
	 * electricityMater.getElectricityMeterId().toString()))
	 * .body(electricityMater);
	 * 
	 * }
	 */

}
