package com.engraph.controller;

import java.util.Date;
import java.util.HashMap;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.rosuda.REngine.Rserve.*;
import org.rosuda.REngine.*;
import org.rosuda.REngine.Rserve.RserveException;
import com.engraph.service.dto.ForecastDTO;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class ForecastController {

	private static final Logger log = LoggerFactory.getLogger(ForecastController.class);

	@PostMapping("/forecast")
	public ResponseEntity<ForecastDTO> getForecastData(@Valid @RequestBody ForecastDTO forecastDTO) {
		log.debug("REST request to save site : {}", forecastDTO);

		try {
			RConnection conn = new RConnection("3.19.110.230", 6311);// 3.19.110.230
			System.out.println("Hello Connection" + conn);
			System.out.println(conn.parseAndEval("library('autoForecast')").toString());
			conn.eval("library('autoForecast')");
			conn.eval("tableName <- \"PROCESSED_TABLE\"");
			conn.eval("forecastSteps <- 10");
			conn.eval("dateDim <- \"NORMAL_TIMESTAMP\"");
			conn.eval("forecastDim <- \"KWH\"");
			//conn.eval("forecastDim <- \" \'" + forecastDTO.getForecastDim() + "\' \"");
			conn.eval("aggregation <- \"AVG\"");
			conn.eval("regDim <- \"WATTS_TOTAL\"");
			conn.eval("timeFrame <- \"day\"");
			conn.eval("result <- autoForecast::forecast(tableName,forecastSteps,dateDim,forecastDim,aggregation,regDim,timeFrame)");
			conn.eval("names(result)");
			conn.eval("names(result$best_model)");
			conn.eval("result$forecast");
			//conn.eval("library(Rserve)");

			REXP rexp = conn.eval("paste(capture.output(result$forecast),collapse='\\n')");
			System.out.println("rexp as String = : " + rexp.asString());
			
			REXP rexp1 = conn.eval("result$forecast");
			RList rlist = rexp1.asList();
			System.out.println("size = " + rlist.size());
			
			StringBuffer sb = new StringBuffer("\t");
			HashMap<String, Double> result = new HashMap<String, Double>();
			
			double[][] data = new double[rlist.names.size()][];
			String[][] data1 = new String[rlist.names.size()][];

			for (int i = 0; i < rlist.size(); i++) {
				String n = rlist.keyAt(i);
				System.out.println(n);
				sb.append(n + "\t");
				data[i] = rlist.at(n).asDoubles();
				// System.out.println(rlist.at("temporalDim"));
			}
			double[] forcast = new double[data[1].length];
			double[] temp = new double[data[0].length];
			
			forcast = rlist.at(rlist.keyAt(1)).asDoubles();
			temp = rlist.at(rlist.keyAt(0)).asDoubles();
			System.out.println("n is = " + data[0].length);
			sb.append("\n");
			for (int i = 0; i < data[0].length; i++) {
				sb.append((i + 1) + "\t");
				for (int j = 0; j < data.length; j++) {
					System.out.println("data[i][j]" + i + " " + j + "  =" + data[j][i]);
					sb.append(data[j][i] + "\t");
				}
				sb.append("\n");
			}
			System.out.println(sb.toString());
			for (int i = 0; i < 10; i++) {
				System.out.println("temp at [i] = " + new Date((long) temp[i] * 1000));
				System.out.println("forcast at [i] = " + i + forcast[i]);
			}
			System.out.println("END");
		} catch (RserveException rse) {
			System.out.println(rse);
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}
}
