package com.engraph.controller;

import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.controller.error.BadRequestAlertException;
import com.engraph.controller.error.SiteResourceException;
import com.engraph.controller.util.PaginationUtil;
import com.engraph.model.NotificationMaster;
import com.engraph.model.SiteMaster;
import com.engraph.repository.SiteMasterRepository;
import com.engraph.service.NotificationService;
import com.engraph.service.dto.NotificationDTO;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class NotifictionController {
	
	private static final Logger log = LoggerFactory.getLogger(SiteDetailsController.class);

	private String ENTITY_NAME = "Notification_master";

	@Autowired
	private SiteMasterRepository siteMasterRepository;
	
	@Autowired
	private NotificationService notificationService;


	@PostMapping("/site-notification")
	public NotificationMaster createSiteBuilding(@Valid @RequestBody NotificationDTO notificationDTO)
			throws URISyntaxException {
		log.debug("REST request to save Building : {}", notificationDTO);

		if (notificationDTO.getSiteId() == null) {
			throw new BadRequestAlertException("An Site ID is must for create notifiation", ENTITY_NAME, "idRequired");
		}

		Optional<SiteMaster> siteMaster = siteMasterRepository.findBySiteId(notificationDTO.getSiteId());
		if (!siteMaster.isPresent()) {
			throw new BadRequestAlertException("An Site is not exists ", ENTITY_NAME, "SiteNotExists");
		}
		
		SiteMaster site = siteMaster.get();
		
		NotificationMaster newNotification = notificationService.createNotification(notificationDTO, site );
		
		return newNotification;
	}
	
	@GetMapping("/site-alerts")
	public ResponseEntity<List<NotificationMaster>> getAllAlertsofSite(
			@RequestParam(name = "siteId", required = false) Long siteId, Pageable pageable) throws URISyntaxException {
		log.debug("Rest request of  get all notifications  of site ");

		Optional<SiteMaster> site = siteMasterRepository.findBySiteId(siteId);

		if (!site.isPresent())
			throw new SiteResourceException("No Site was found for this siteId");
		
		final Page<NotificationMaster> page = notificationService.getAllAlertssofSite(site.get(), pageable);
		
		HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/engraph/site-alerts");
		
		return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
	}
	
	

}
