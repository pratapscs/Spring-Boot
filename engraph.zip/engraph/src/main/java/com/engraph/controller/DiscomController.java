package com.engraph.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.engraph.model.DiscomMaster;
import com.engraph.model.LocationMaster;
import com.engraph.repository.DiscomRepository;
import com.engraph.repository.LocationRepository;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class DiscomController {

	private static final Logger log = LoggerFactory.getLogger(DiscomController.class);
	
	private String ENTITY_NAME = "DiscomDetails";

	private String applicationName = "engraph";

	@Autowired
	private DiscomRepository discomRepository;
	
	@Autowired
	private LocationRepository locationRepository;
	
	
	@GetMapping("/discomnames")  
    public List<DiscomMaster> getAllDiscomNames(@RequestParam("location_id") long location) {
		Optional<LocationMaster> locationMaster = locationRepository.findById(location);
        List<DiscomMaster> list = discomRepository.findAllByLocationId(locationMaster.get());
        return list;
    }
	
}