package com.engraph.controller;

import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.controller.error.BadRequestAlertException;
import com.engraph.controller.error.SiteResourceException;
import com.engraph.controller.util.PaginationUtil;
import com.engraph.model.SiteBuilding;
import com.engraph.model.SiteMaster;
import com.engraph.repository.SiteMasterRepository;
import com.engraph.service.SiteBuildingDetailsService;
import com.engraph.service.dto.BuildingDTO;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class SiteBuildingController {

	private static final Logger log = LoggerFactory.getLogger(SiteDetailsController.class);

	private String ENTITY_NAME = "SiteBuilding";

	private String applicationName = "engraph";

	@Autowired
	private SiteMasterRepository siteMasterRepository;

	@Autowired
	private SiteBuildingDetailsService siteBuildingDetailsService;

	@Autowired
	private SiteBuildingDetailsService siteBuildingService;

	/**
	 * {@code POST /site-building} : Creates a new Building and save building
	 * information.
	 * <p>
	 *
	 * @param SiteBuilding the building to create.
	 * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with
	 *         body the new building, or with status {@code 400 (Bad Request)} if
	 *         site id is missing or not exists.
	 * @throws URISyntaxException if the Location URI syntax is incorrect.
	 */
	@PostMapping("/site-building")
	public List<SiteBuilding> createSiteBuilding(@Valid @RequestBody BuildingDTO siteBuildingDTO)
			throws URISyntaxException {
		log.debug("REST request to save Building : {}", siteBuildingDTO);

		if (siteBuildingDTO.getSiteId() == null) {
			throw new BadRequestAlertException("An Site ID is must for create Building", ENTITY_NAME, "idRequired");
		}

		// update the Site details.
		Optional<SiteMaster> siteMaster = siteMasterRepository.findBySiteId(siteBuildingDTO.getSiteId());
		if (!siteMaster.isPresent()) {
			throw new BadRequestAlertException("An Site is not exists ", ENTITY_NAME, "SiteNotExists");
		}

		List<SiteBuilding> siteBuildings = siteBuildingDetailsService.saveSiteBuildingInfo(siteBuildingDTO, siteMaster.get());
		return siteBuildings;
	}

	/**
	 * {@code GET /site-buildings} : get all buildings of an site.
	 *
	 * @param pageable the pagination information. @return the
	 *                 {@link ResponseEntity} with status {@code 200 (OK)} and with
	 *                 body all buildings. @throws
	 */
	@GetMapping("/site-buildings")
	public ResponseEntity<List<SiteBuilding>> getAllBuildingsofSite(
			@RequestParam(name = "siteId", required = false) Long siteId, Pageable pageable) throws URISyntaxException {
		log.debug("Rest request of  get all user of organization ");

		Optional<SiteMaster> site = siteMasterRepository.findBySiteId(siteId);

		if (!site.isPresent())
			throw new SiteResourceException("No Site was found for this siteId");
		final Page<SiteBuilding> page = siteBuildingService.getAllBuildingsofSite(site.get(), pageable);
		HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/engraph/site-buildings");
		return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
	}

}