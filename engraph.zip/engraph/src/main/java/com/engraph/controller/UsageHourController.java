package com.engraph.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.model.DiscomCategoryBusinessTypeMaster;
import com.engraph.model.UsageHourMaster;
import com.engraph.repository.DiscomCategoryRepository;
import com.engraph.repository.UsageHourRepository;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class UsageHourController {

	private static final Logger log = LoggerFactory.getLogger(UsageHourController.class);
	
	private String ENTITY_NAME = "UsageHourDetails";

	private String applicationName = "engraph";
	
	@Autowired
	private UsageHourRepository usageHourRepository;
	
	@Autowired
	private DiscomCategoryRepository categoryRepository;
	
	@GetMapping("/usagehours")
    public List<UsageHourMaster> getAllUsageHours(@RequestParam("discom_category_id") long discomCategoryId) {
		Optional<DiscomCategoryBusinessTypeMaster> discomCaregory = categoryRepository.findById(discomCategoryId);
        List<UsageHourMaster> list = usageHourRepository.findAllByDiscomCategoryId(discomCaregory.get());
        return list;
    }
	
	
}
