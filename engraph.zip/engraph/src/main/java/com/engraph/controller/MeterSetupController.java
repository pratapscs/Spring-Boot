package com.engraph.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.controller.error.BadRequestAlertException;
import com.engraph.controller.error.SiteResourceException;
import com.engraph.controller.util.HeaderUtil;
import com.engraph.controller.util.PaginationUtil;
import com.engraph.controller.util.Producer;
import com.engraph.model.Dcudetails;
import com.engraph.model.EletricityMeter;
import com.engraph.model.MeterSetup;
import com.engraph.model.SiteMaster;
import com.engraph.repository.DcuRepository;
import com.engraph.repository.ElectricityMeterRepository;
import com.engraph.repository.SiteMasterRepository;
import com.engraph.service.MetersetupService;
import com.engraph.service.dto.MeterSetupDTO;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class MeterSetupController {

	private static final Logger log = LoggerFactory.getLogger(MeterSetupController.class);

	private String ENTITY_NAME = "MeterSetup";

	private String applicationName = "engraph";
	
	@Autowired
	private MetersetupService meterSetupService;
	
	@Autowired
	private ElectricityMeterRepository electricityMeterRepository;
	
	@Autowired
	private DcuRepository dcuRepository;
	
	@Autowired
	private SiteMasterRepository siteMasterRepository;
	
	@Autowired
	private Producer jmsProducer;
	
	@PostMapping("/metersetup/create")
	public ResponseEntity<MeterSetup> createMeterSetup(@Valid @RequestBody MeterSetupDTO meterSetupDTO)
			throws URISyntaxException {
		log.debug("REST request to save 1metersetup : {}", meterSetupDTO);
		if (meterSetupDTO.getManufacturingID() == null) {
			throw new BadRequestAlertException("An  is must for create meter setup", ENTITY_NAME, "idRequired");
		}
		
		Optional<EletricityMeter> meterDetails = electricityMeterRepository.findByElectricityMeterId(meterSetupDTO.getElectricityMeterId());
		Optional<Dcudetails> dcuDetails = dcuRepository.findById(meterSetupDTO.getManufacturingID());
		
		if (!meterDetails.isPresent() && !dcuDetails.isPresent()) {
			throw new BadRequestAlertException("An Meter Details is not exists ", ENTITY_NAME, "MeterNotExists");
		}
		EletricityMeter meter = meterDetails.get();
		meter.setElectricityMeterId(meterSetupDTO.getElectricityMeterId());
		Dcudetails dcu = dcuDetails.get();
		dcu.setManufacturingID(meterSetupDTO.getManufacturingID());

		MeterSetup meterSetup = meterSetupService.saveMeterSetupInfo(meterSetupDTO, meter,dcu);
		
		jmsProducer.send(meterSetup);
		
		return ResponseEntity.created(new URI("/engraph/metersetup/create" + meterSetup.getMeterSetupId()))
				.headers(HeaderUtil.createAlert(applicationName, ENTITY_NAME, meterSetup.getMeterSetupId().toString()))
				.body(meterSetup);

	}


	@GetMapping("/metersetup-details")
	public ResponseEntity<List<MeterSetup>> getAllMeterSetupofSite(
			@RequestParam(name = "siteId", required = false) Long siteId, Pageable pageable) throws URISyntaxException {
		log.debug("Rest request of  get all meter setup ");

		Optional<SiteMaster> site = siteMasterRepository.findBySiteId(siteId);

		if (!site.isPresent())
			throw new SiteResourceException("No Site was found for this siteId");
		
	   final Page<MeterSetup> page = meterSetupService.getAllMeterSetupofSite(site.get(), pageable);
	   
	   HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/engraph/metersetup-details");
	
	   return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
	}
}
