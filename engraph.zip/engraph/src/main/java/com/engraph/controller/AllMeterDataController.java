package com.engraph.controller;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.model.AllMeterData;
import com.engraph.model.ProcessAssets;
import com.engraph.model.ProcessedData;
import com.engraph.service.IAllMeterDataService;
import com.engraph.service.dto.CompareDates;
import com.engraph.service.dto.ComparisonDTO;
import com.engraph.service.dto.FilterDTO;
import com.engraph.service.dto.HistoricalDTO;
import com.engraph.service.dto.SiteDTO;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class AllMeterDataController {

	private static final Logger log = LoggerFactory.getLogger(AllMeterDataController.class);

	@Autowired
	private IAllMeterDataService allMeterDataService;

	@GetMapping("/yesterdaykwh")
	public MappingJacksonValue getYesterDayKwhData() throws Exception {
		
		log.debug("Rest request to get yesterday's data of kwh");
		
		List<AllMeterData> list = allMeterDataService.getYesterDayKwhData();
		
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "timestamp", "date","allMeterKwhSum");
		
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		
		mapping.setFilters(filters);
		
		return mapping;
	}

	@GetMapping("/todaykwh")
	public MappingJacksonValue getToDayKwhData() throws Exception {
		log.debug("Rest request to get today's data  of kwh");
		List<AllMeterData> list = allMeterDataService.getTodayKwhData();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "timestamp",
				"allMeterKwhSum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/yesterdayco")
	public MappingJacksonValue getYesterDayCo2Data() throws Exception {
		log.debug("Rest request to get yesterday's data  of Co2");
		List<AllMeterData> list = allMeterDataService.getYesterDayCo2Data();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "timestamp", "date",
				"allMeterDailyCarbonEmissionCumulativeValue");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/todayco")
	public MappingJacksonValue getTodayCo2Data() throws Exception {
		log.debug("Rest request to get today's data  of co2");
		List<AllMeterData> list = allMeterDataService.getTodayCo2Data();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "timestamp", "date",
				"allMeterDailyCarbonEmissionCumulativeValue");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/topassets")
	public List<ProcessedData> getTopConsumedAssets() throws Exception {

		log.debug("Rest request to get  Top five Assets");

		List<ProcessedData> list = allMeterDataService.getTopConsumedAssets();

		return list;
	}

	@GetMapping("/livemonitor/todayec")
	public MappingJacksonValue getTodayEnergyConsumption() throws Exception {
		log.debug("Rest request to get ToDay Energy Consumption");
		List<AllMeterData> list = allMeterDataService.getTodayEnergyConsumption();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "timestamp", "date",
				"time", "allMeterKwhSum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@PostMapping("/livemonitor/todayecassets")
	public List<ProcessAssets> getTodayEnergyConsumptionByAsset(@RequestBody FilterDTO requestDto) throws Exception {

		log.debug("Rest request to get ToDay Energy Consumption By Asset");

		List<ProcessAssets> result = new ArrayList<>();

		if (requestDto.getFilters().size() == 0) {
			return result;
		}

		List<ProcessAssets> list = allMeterDataService.getTodayEnergyConsumptionByAssets(requestDto.getFilters());

		return list;
	}

	@PostMapping("/livemonitor/thisweekecassets")
	public List<ProcessAssets> getThisWeekEnergyConsumptionByAsset(@RequestBody FilterDTO requestDto) throws Exception {

		log.debug("Rest request to get This Week Energy Consumption By Asset");

		List<ProcessAssets> result = new ArrayList<>();

		if (requestDto.getFilters().size() == 0) {
			return result;
		}

		List<ProcessAssets> list = allMeterDataService.getThisWeekEnergyConsumptionByAssets(requestDto.getFilters());

		return list;
	}

	@PostMapping("/livemonitor/thismonthecassets")
	public List<ProcessAssets> getThisMonthEnergyConsumptionByAsset(@RequestBody FilterDTO requestDto)
			throws Exception {

		log.debug("Rest request to get This Month Energy Consumption By Asset");

		List<ProcessAssets> result = new ArrayList<>();

		if (requestDto.getFilters().size() == 0) {
			return result;
		}

		List<ProcessAssets> list = allMeterDataService.getThisMonthEnergyConsumptionByAssets(requestDto.getFilters());

		return list;
	}

	// Historical Data - kWh - selected assets
	@PostMapping("/historical/kwhassets")
	public List<ProcessAssets> getKwhAssets(@RequestBody HistoricalDTO hisData) throws Exception {

		log.debug("Rest request to kwhassets");

		List<ProcessAssets> result = new ArrayList<>();

		if (hisData.getFilters().size() == 0) {
			return result;
		}

		List<ProcessAssets> list = allMeterDataService.getKwhAssets(hisData.getFilters(), hisData.getStartDate(),
				hisData.getEndDate());

		return list;
	}

	// Historical Data - kW - selected assets
	/*
	 * @PostMapping("/historical/kwassets") public List<ProcessAssets>
	 * getKwAssets(@RequestBody HistoricalDTO hisData) throws Exception {
	 * 
	 * log.debug("Rest request to kwassets");
	 * 
	 * List<ProcessAssets> result = new ArrayList<>();
	 * 
	 * if(hisData.getFilters().size() == 0) { return result; }
	 * 
	 * 
	 * List<ProcessAssets> list =
	 * allMeterDataService.getKwAssets(hisData.getFilters(), hisData.getStartDate(),
	 * hisData.getEndDate()); return list;
	 * 
	 * }
	 */

	@GetMapping("/livemonitor/thisweekec")
	public MappingJacksonValue getThisWeekEnergyConsumption() throws Exception {
		log.debug("Rest request to get This Week Energy Consumption");
		List<AllMeterData> list = allMeterDataService.getThisWeekEnergyConsumption();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "week", "weekDay",
				"weekDate", "dailyAllMeterKwhSum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/livemonitor/thismonthec")
	public MappingJacksonValue getThisMonthEnergyConsumption() throws Exception {
		log.debug("Rest request to get This Month Energy Consumption");
		List<AllMeterData> list = allMeterDataService.getThisMonthEnergyConsumption();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "month",
				"monthlyKwh");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/livemonitor/todaypq")
	public MappingJacksonValue getTodayPowerQuality() throws Exception {
		log.debug("Rest request to get ToDay Power Quality");
		List<AllMeterData> list = allMeterDataService.getTodayPowerQuality();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "timestamp", "date",
				"time", "allMeterVryPhaseAvg", "allMeterVybPhaseAvg", "allMeterVbrPhaseAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@PostMapping("/livemonitor/todaypqassets")
	public List<ProcessedData> getTodayPowerQualityByAsset(@RequestBody SiteDTO[] siteDto) throws Exception {
		log.debug("Rest request to get ToDay Power Quality By Asset");
		List<ProcessedData> list = allMeterDataService.getTodayPowerQualityByAssets(siteDto);
		return list;
	}

	@GetMapping("/livemonitor/thisweekpq")
	public MappingJacksonValue getThisWeekPowerQuality() throws Exception {
		log.debug("Rest request to get Thisweek Power Quality");
		List<AllMeterData> list = allMeterDataService.getThisWeekPowerQuality();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "allMeterVryPhaseAvg", "allMeterVybPhaseAvg", "allMeterVbrPhaseAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@PostMapping("/livemonitor/thisweekpqassets")
	public List<ProcessedData> getThisWeekPowerQualityByAsset(@RequestBody SiteDTO[] siteDto) throws Exception {
		log.debug("Rest request to get ToDay Power Quality By Asset");
		List<ProcessedData> list = allMeterDataService.getThisWeekPowerQualityByAssets(siteDto);
		return list;
	}

	@GetMapping("/livemonitor/thismonthpq")
	public MappingJacksonValue getThisMonthPowerQuality() throws Exception {
		log.debug("Rest request to get Thismonth Power Quality");
		List<AllMeterData> list = allMeterDataService.getThisMonthPowerQuality();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "month", "allMeterVryPhaseAvg", "allMeterVybPhaseAvg", "allMeterVbrPhaseAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@PostMapping("/livemonitor/thismonthpqassets")
	public List<ProcessedData> getThisMonthPowerQualityByAsset(@RequestBody SiteDTO[] siteDto) throws Exception {
		log.debug("Rest request to get ThisMonth Power Quality By Asset");
		List<ProcessedData> list = allMeterDataService.getThisMonthPowerQualityByAssets(siteDto);
		return list;
	}

	@GetMapping("/livemonitor/todaylp")
	public MappingJacksonValue getTodayLoadProfile() throws Exception {
		log.debug("Rest request to get ToDay Load Profile");
		List<AllMeterData> list = allMeterDataService.getTodayLoadProfile();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "timestamp", "date",
				"time", "allMeterTotalKwAvg", "allMeterKvaAvg", "allMeterPfInstAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@PostMapping("/livemonitor/todaylpassets")
	public List<ProcessedData> getTodayLoadProfileByAsset(@RequestBody SiteDTO[] siteDto) throws Exception {
		log.debug("Rest request to get ToDay Load Profile By Asset");
		List<ProcessedData> list = allMeterDataService.getTodayLoadProfileByAssets(siteDto);
		return list;
	}

	@GetMapping("/livemonitor/thisweeklp")
	public MappingJacksonValue getThisWeekLoadProfile() throws Exception {
		log.debug("Rest request to get Thisweek Load Profile");
		List<AllMeterData> list = allMeterDataService.getThisWeekLoadProfile();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "dailyAllMeterTotalKwAvg", "dailyAllMeterTotalKvaAvg", "dailyAllMeterTotalPfAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@PostMapping("/livemonitor/thisweeklpassets")
	public List<ProcessedData> getThisWeekLoadProfileByAsset(@RequestBody SiteDTO[] siteDto) throws Exception {
		log.debug("Rest request to get Thisweek Load Profile By Asset");
		List<ProcessedData> list = allMeterDataService.getThisWeekLoadProfileByAssets(siteDto);
		return list;
	}

	@GetMapping("/livemonitor/thismonthlp")
	public MappingJacksonValue getThisMonthLoadProfile() throws Exception {
		log.debug("Rest request to get Thismonth Load Profile ");
		List<AllMeterData> list = allMeterDataService.getThisMonthLoadProfile();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "month", "dailyAllMeterTotalKwAvg", "dailyAllMeterTotalKvaAvg", "dailyAllMeterTotalPfAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@PostMapping("/livemonitor/thismonthlpassets")
	public List<ProcessedData> getThisMonthLoadProfileByAsset(@RequestBody SiteDTO[] siteDto) throws Exception {
		log.debug("Rest request to get This Month  Load Profile By Asset");
		List<ProcessedData> list = allMeterDataService.getThisMonthLoadProfileByAssets(siteDto);
		return list;
	}

	@GetMapping("/co2emission/todayco2")
	public MappingJacksonValue getTodayCo2Emission() throws Exception {
		log.debug("Rest request to get ToDay Co2 Emission");
		List<AllMeterData> list = allMeterDataService.getTodayCo2Emission();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "timestamp", "date",
				"time", "allMeterCarbonEmissionSum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@PostMapping("/co2emission/todayco2assets")
	public List<ProcessedData> getTodayCo2EmissionByAsset(@RequestBody SiteDTO[] siteDto) throws Exception {
		log.debug("Rest request to get ToDay Co2 Emission By Asset");
		List<ProcessedData> list = allMeterDataService.getTodayCo2EmissionByAssets(siteDto);
		return list;
	}

	@GetMapping("/co2emission/thisweekco2")
	public MappingJacksonValue getThisWeekCo2Emission() throws Exception {
		log.debug("Rest request to get Thisweek Co2 Emission");
		List<AllMeterData> list = allMeterDataService.getThisWeekCo2Emission();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "allMeterDailyCarbonEmissionCumulativeValue");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@PostMapping("/co2emission/thisweekco2assets")
	public List<ProcessedData> getThisWeekCo2EmissionByAsset(@RequestBody SiteDTO[] siteDto) throws Exception {
		log.debug("Rest request to get Thisweek Co2 Emission By Asset");
		List<ProcessedData> list = allMeterDataService.getThisWeekCo2EmissionByAssets(siteDto);
		return list;
	}

	@GetMapping("/co2emission/thismonthco2")
	public MappingJacksonValue getThisMonthCo2Emission() throws Exception {
		log.debug("Rest request to get Thismonth Co2 Emission ");
		List<AllMeterData> list = allMeterDataService.getThisMonthCo2Emission();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "month", "allMeterDailyCarbonEmissionCumulativeValue");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@PostMapping("/co2emission/thismonthco2assets")
	public List<ProcessedData> getThisMonthCo2EmissionByAsset(@RequestBody SiteDTO[] siteDto) throws Exception {
		log.debug("Rest request to get ThisMonth  Co2 Emission By Asset");
		List<ProcessedData> list = allMeterDataService.getThisMonthCo2EmissionByAssets(siteDto);
		return list;
	}

	@GetMapping("/co2emission/todayhighestemitters")
	public MappingJacksonValue getTodayHighestEmitters() throws Exception {
		log.debug("Rest request to get Today Highest Emitters  ");
		List<ProcessedData> list = allMeterDataService.getTodayHighestEmitters();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "siteName",
				"assetName", "unixTimeStamp", "timestamp", "date", "time", "co2Emission");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/co2emission/thisweekhighestemitters")
	public MappingJacksonValue getThisWeekHighestEmitters() throws Exception {
		log.debug("Rest request to get This week Highest Emitters  ");
		List<ProcessedData> list = allMeterDataService.getThisWeekHighestEmitters();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "siteName",
				"assetName", "date", "week", "weekDay", "dailyMeterWiseCo2Sum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/co2emission/thismonthhighestemitters")
	public MappingJacksonValue getThisMonthHighestEmitters() throws Exception {
		log.debug("Rest request to get This month Highest Emitters  ");
		List<ProcessedData> list = allMeterDataService.getThisMonthHighestEmitters();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "siteName",
				"assetName", "date", "week", "weekDay", "dailyMeterWiseCo2Sum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/co2emission/todaygreenestunits")
	public MappingJacksonValue getTodayGreenestUnits() throws Exception {
		log.debug("Rest request to get Today greenest units ");
		List<ProcessedData> list = allMeterDataService.getTodayGreenestUnits();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "siteName",
				"assetName", "unixTimeStamp", "timestamp", "date", "time", "co2Emission");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/co2emission/thisweekgreenestunits")
	public MappingJacksonValue getThisWeekGreenestUnits() throws Exception {
		log.debug("Rest request to get This week Highest Emitters  ");
		List<ProcessedData> list = allMeterDataService.getThisWeekGreenestUnits();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "siteName",
				"assetName", "date", "week", "weekDay", "dailyMeterWiseCo2Sum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/co2emission/thismonthgreenestunits")
	public MappingJacksonValue getThisMonthGreenestUnits() throws Exception {
		log.debug("Rest request to get This month Highest Emitters  ");
		List<ProcessedData> list = allMeterDataService.getThisMonthGreenestUnits();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "siteName",
				"assetName", "date", "week", "weekDay", "dailyMeterWiseCo2Sum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	// Historical Data - kWh - all assets
	@GetMapping("/historical/kwhdata")
	public MappingJacksonValue getKwhData(String startDate, String endDate) throws Exception {
		log.debug("Rest request to KwhData");
		List<AllMeterData> list = allMeterDataService.getKwhData(startDate, endDate);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "hDate", "time", "week",
				"weekDay", "month", "dailyAllMeterKwhSum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	// Historical Data - Kw - all assets
	@GetMapping("/historical/kwdata")
	public MappingJacksonValue getKWData(String startDate, String endDate) throws Exception {
		log.debug("Rest request to kwdata");
		List<AllMeterData> list = allMeterDataService.getKwData(startDate, endDate);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "hDate", "time", "week",
				"weekDay", "month", "dailyAllMeterTotalKwAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	// Historical Data - kW - selected assets

	// Historical Data - KVA - all assets
	@GetMapping("/historical/kvadata")
	public MappingJacksonValue getKvaData(String startDate, String endDate) throws Exception {
		log.debug("Rest request to kvadata");
		List<AllMeterData> list = allMeterDataService.getKvaData(startDate, endDate);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "hDate", "time", "week",
				"weekDay", "month", "dailyAllMeterTotalKvaAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	// Historical Data - kVA - selected assets
	/*
	 * @PostMapping("/historical/kvaassets") public List<SelectAssets>
	 * getKvaAssets(@RequestBody HistoricalDTO hisData) throws Exception {
	 * log.debug("Rest request to kvaassets"); List<SelectAssets> result = new
	 * ArrayList<>();
	 * 
	 * if (hisData.getAssets().length == 0) { return result; }
	 * 
	 * List<ProcessedData> list =
	 * allMeterDataService.getKvaAssets(hisData.getAssets(), hisData.getStartDate(),
	 * hisData.getEndDate());
	 * 
	 * Map<String, SelectAssets> assetMap = new HashedMap();
	 * 
	 * list.stream().forEach(selectAsset -> { if
	 * (assetMap.containsKey(selectAsset.getAssetName())) {
	 * 
	 * SelectAssets sAsset = assetMap.get(selectAsset.getAssetName()); ProcessAssets
	 * processAssets = new ProcessAssets();
	 * processAssets.setSiteId(selectAsset.getSiteId());
	 * processAssets.setAssetId(selectAsset.getAssetId());
	 * processAssets.sethDate(selectAsset.gethDate());
	 * processAssets.setDailyIndividualMeterTotalKvaAvg(selectAsset.
	 * getDailyIndividualMeterTotalKvaAvg());
	 * sAsset.getProcessAssets().add(processAssets);
	 * 
	 * } else { List<ProcessAssets> listSelectedAssets = new ArrayList<>();
	 * ProcessAssets processAssets = new ProcessAssets();
	 * processAssets.setSiteId(selectAsset.getSiteId());
	 * processAssets.setAssetId(selectAsset.getAssetId());
	 * processAssets.sethDate(selectAsset.gethDate());
	 * processAssets.setDailyIndividualMeterTotalKvaAvg(selectAsset.
	 * getDailyIndividualMeterTotalKvaAvg()); listSelectedAssets.add(processAssets);
	 * SelectAssets nAsset = new SelectAssets();
	 * nAsset.setAssetName(selectAsset.getAssetName());
	 * nAsset.setProcessAssets(listSelectedAssets);
	 * assetMap.put(selectAsset.getAssetName(), nAsset); result.add(nAsset); } });
	 * return result; }
	 */

	// Historical Data - PF - all assets
	@GetMapping("/historical/pfdata")
	public MappingJacksonValue getPfData(String startDate, String endDate) throws Exception {
		log.debug("Rest request to pfdata");
		List<AllMeterData> list = allMeterDataService.getPfData(startDate, endDate);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "hDate", "time", "week",
				"weekDay", "month", "dailyAllMeterTotalPfAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	// Historical Data - PF - selected assets
	/*
	 * @PostMapping("/historical/pfassets") public List<SelectAssets>
	 * getPfAssets(@RequestBody HistoricalDTO hisData) throws Exception {
	 * log.debug("Rest request to pfassets"); List<SelectAssets> result = new
	 * ArrayList<>();
	 * 
	 * if (hisData.getAssets().length == 0) { return result; }
	 * 
	 * List<ProcessedData> list =
	 * allMeterDataService.getPfAssets(hisData.getAssets(), hisData.getStartDate(),
	 * hisData.getEndDate());
	 * 
	 * Map<String, SelectAssets> assetMap = new HashedMap();
	 * 
	 * list.stream().forEach(selectAsset -> { if
	 * (assetMap.containsKey(selectAsset.getAssetName())) {
	 * 
	 * SelectAssets sAsset = assetMap.get(selectAsset.getAssetName()); ProcessAssets
	 * processAssets = new ProcessAssets();
	 * processAssets.setSiteId(selectAsset.getSiteId());
	 * processAssets.setAssetId(selectAsset.getAssetId());
	 * processAssets.sethDate(selectAsset.gethDate());
	 * processAssets.setDailyIndividualMeterTotalPfAvg(selectAsset.
	 * getDailyIndividualMeterTotalPfAvg());
	 * sAsset.getProcessAssets().add(processAssets);
	 * 
	 * } else { List<ProcessAssets> listSelectedAssets = new ArrayList<>();
	 * ProcessAssets processAssets = new ProcessAssets();
	 * processAssets.setSiteId(selectAsset.getSiteId());
	 * processAssets.setAssetId(selectAsset.getAssetId());
	 * processAssets.sethDate(selectAsset.gethDate());
	 * processAssets.setDailyIndividualMeterTotalPfAvg(selectAsset.
	 * getDailyIndividualMeterTotalPfAvg()); listSelectedAssets.add(processAssets);
	 * SelectAssets nAsset = new SelectAssets();
	 * nAsset.setAssetName(selectAsset.getAssetName());
	 * nAsset.setProcessAssets(listSelectedAssets);
	 * assetMap.put(selectAsset.getAssetName(), nAsset); result.add(nAsset); } });
	 * return result; }
	 */

	// Historical Data - Voltage - all assets
	@GetMapping("/historical/voltagedata")
	public MappingJacksonValue getVoltageData(String startDate, String endDate) throws Exception {
		log.debug("Rest request to voltagedata");
		List<AllMeterData> list = allMeterDataService.getVoltageData(startDate, endDate);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "hDate", "time", "week",
				"weekDay", "month", "dailyAllMeterTotalLLVoltageAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	// Historical Data - Voltage - selected assets
	/*
	 * @PostMapping("/historical/voltageassets") public List<SelectAssets>
	 * getVoltageAssets(@RequestBody HistoricalDTO hisData) throws Exception {
	 * log.debug("Rest request to VoltageAssets"); List<SelectAssets> result = new
	 * ArrayList<>();
	 * 
	 * if (hisData.getAssets().length == 0) { return result; }
	 * 
	 * List<ProcessedData> list =
	 * allMeterDataService.getVoltageAssets(hisData.getAssets(),
	 * hisData.getStartDate(), hisData.getEndDate());
	 * 
	 * Map<String, SelectAssets> assetMap = new HashedMap();
	 * 
	 * list.stream().forEach(selectAsset -> { if
	 * (assetMap.containsKey(selectAsset.getAssetName())) {
	 * 
	 * SelectAssets sAsset = assetMap.get(selectAsset.getAssetName()); ProcessAssets
	 * processAssets = new ProcessAssets();
	 * processAssets.setSiteId(selectAsset.getSiteId());
	 * processAssets.setAssetId(selectAsset.getAssetId());
	 * processAssets.sethDate(selectAsset.gethDate());
	 * processAssets.setDailyIndividualMeterLineToLineVoltageAvg(
	 * selectAsset.getDailyIndividualMeterLineToLineVoltageAvg());
	 * sAsset.getProcessAssets().add(processAssets);
	 * 
	 * } else { List<ProcessAssets> listSelectedAssets = new ArrayList<>();
	 * ProcessAssets processAssets = new ProcessAssets();
	 * processAssets.setSiteId(selectAsset.getSiteId());
	 * processAssets.setAssetId(selectAsset.getAssetId());
	 * processAssets.sethDate(selectAsset.gethDate());
	 * processAssets.setDailyIndividualMeterLineToLineVoltageAvg(
	 * selectAsset.getDailyIndividualMeterLineToLineVoltageAvg());
	 * listSelectedAssets.add(processAssets); SelectAssets nAsset = new
	 * SelectAssets(); nAsset.setAssetName(selectAsset.getAssetName());
	 * nAsset.setProcessAssets(listSelectedAssets);
	 * assetMap.put(selectAsset.getAssetName(), nAsset); result.add(nAsset); } });
	 * return result; }
	 */
	// Historical Data - CO2 - all assets
	@GetMapping("/historical/co2data")
	public MappingJacksonValue getCo2Data(String startDate, String endDate) throws Exception {
		log.debug("Rest request to co2data");
		List<AllMeterData> list = allMeterDataService.getCo2Data(startDate, endDate);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "hDate", "time", "week",
				"weekDay", "month", "allMeterDailyCarbonEmissionCumulativeValue");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	// Historical Data - CO2 - selected assets
	/*
	 * @PostMapping("/historical/co2assets") public List<SelectAssets>
	 * getCo2Assets(@RequestBody HistoricalDTO hisData) throws Exception {
	 * log.debug("Rest request to co2assets"); List<SelectAssets> result = new
	 * ArrayList<>();
	 * 
	 * if (hisData.getAssets().length == 0) { return result; } List<ProcessedData>
	 * list = allMeterDataService.getCo2Assets(hisData.getAssets(),
	 * hisData.getStartDate(), hisData.getEndDate());
	 * 
	 * Map<String, SelectAssets> assetMap = new HashedMap();
	 * 
	 * list.stream().forEach(selectAsset -> { if
	 * (assetMap.containsKey(selectAsset.getAssetName())) {
	 * 
	 * SelectAssets sAsset = assetMap.get(selectAsset.getAssetName()); ProcessAssets
	 * processAssets = new ProcessAssets();
	 * processAssets.setSiteId(selectAsset.getSiteId());
	 * processAssets.setAssetId(selectAsset.getAssetId());
	 * processAssets.setDate(selectAsset.getDate());
	 * processAssets.setDailyMeterWiseCo2Sum(selectAsset.getDailyMeterWiseCo2Sum());
	 * sAsset.getProcessAssets().add(processAssets);
	 * 
	 * } else { List<ProcessAssets> listSelectedAssets = new ArrayList<>();
	 * ProcessAssets processAssets = new ProcessAssets();
	 * processAssets.setSiteId(selectAsset.getSiteId());
	 * processAssets.setAssetId(selectAsset.getAssetId());
	 * processAssets.setDate(selectAsset.getDate());
	 * processAssets.setDailyMeterWiseCo2Sum(selectAsset.getDailyMeterWiseCo2Sum());
	 * listSelectedAssets.add(processAssets); SelectAssets nAsset = new
	 * SelectAssets(); nAsset.setAssetName(selectAsset.getAssetName());
	 * nAsset.setProcessAssets(listSelectedAssets);
	 * assetMap.put(selectAsset.getAssetName(), nAsset); result.add(nAsset); } });
	 * return result; }
	 */
	// Real time Analysis - Comparison
	@PostMapping("/realtimeanalysis/comparison")
	public CompareDates getToDayYesterDayComparison(@RequestBody ComparisonDTO comData) throws Exception {
		log.debug("Rest request to get today yesterday  data");

		CompareDates list = allMeterDataService.getRealTimeAnalysisComparison(comData);

		return list;
	}

	@GetMapping("/historical/yesterdayec")
	public MappingJacksonValue getYesterdayEnergyConsumption() throws Exception {
		log.debug("Rest request to get Yesterday Energy Consumption");
		List<AllMeterData> list = allMeterDataService.getYesterdayEnergyConsumption();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "timestamp", "date",
				"time", "allMeterKwhSum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/yesterdayecassets")
	public MappingJacksonValue getYesterdayEnergyConsumptionByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Yesterday Energy Consumption By Asset");
		List<ProcessedData> list = allMeterDataService.getYesterdayEnergyConsumptionByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId",
				"unixTimestamp", "timestamp", "date", "time", "exactKwh");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastweekec")
	public MappingJacksonValue getLastWeekEnergyConsumption() throws Exception {
		log.debug("Rest request to get Last Week Energy Consumption");
		List<AllMeterData> list = allMeterDataService.getLastWeekEnergyConsumption();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "week", "weekDay",
				"weekDate", "dailyAllMeterKwhSum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastweekecassets")
	public MappingJacksonValue getLastWeekEnergyConsumptionByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Last Week Energy Consumption By Asset");
		List<ProcessedData> list = allMeterDataService.getLastWeekEnergyConsumptionByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "weekDate", "week",
				"weekDay", "individualMeterDailyKwhSum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastmonthec")
	public MappingJacksonValue getLastMonthEnergyConsumption() throws Exception {
		log.debug("Rest request to get Last Month Energy Consumption ");
		List<AllMeterData> list = allMeterDataService.getLastMonthEnergyConsumption();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "month", "monthDate",
				"monthlyKwh");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastmonthecassets")
	public MappingJacksonValue getLastMonthEnergyConsumptionByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Last Month EnergyConsumption By Asset");
		List<ProcessedData> list = allMeterDataService.getLastMonthEnergyConsumptionByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "monthDate",
				"month", "individualMeterDailyKwhSum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/yesterdaykw")
	public MappingJacksonValue getYesterdayKw() throws Exception {
		log.debug("Rest request to get Yesterday Kw");
		List<AllMeterData> list = allMeterDataService.getYesterdayKw();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "timestamp", "date",
				"time", "allMeterTotalKwAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/yesterdaykwassets")
	public MappingJacksonValue getYesterdayKwByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Yesterday Kw By Asset By Asset");
		List<ProcessedData> list = allMeterDataService.getYesterdayKwByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetID",
				"unixTimestamp", "timestamp", "date", "time", "wattsTotal");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastweekkw")
	public MappingJacksonValue getLastWeekKw() throws Exception {
		log.debug("Rest request to get Last Week Kw");
		List<AllMeterData> list = allMeterDataService.getLastWeekKw();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "dailyAllMeterTotalKwAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastweekkwassets")
	public MappingJacksonValue getLastWeekKwByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Last Week Kw By Asset");
		List<ProcessedData> list = allMeterDataService.getLastWeekKwByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "date",
				"time", "weekDate", "week", "weekDay", "dailyIndividualMeterTotalKwAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastmonthkw")
	public MappingJacksonValue getLastMonthKw() throws Exception {
		log.debug("Rest request to get Last Month Kw ");
		List<AllMeterData> list = allMeterDataService.getLastMonthKw();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "month", "dailyAllMeterTotalKwAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastmonthkwassets")
	public MappingJacksonValue getLastMonthKwByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Last Month Kw By Asset");
		List<ProcessedData> list = allMeterDataService.getLastMonthKwByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "date",
				"time", "week", "weekDay", "month", "dailyIndividualMeterTotalKwAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/yesterdaykva")
	public MappingJacksonValue getYesterdayKva() throws Exception {
		log.debug("Rest request to get Yesterday kva");
		List<AllMeterData> list = allMeterDataService.getYesterdayKva();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "timestamp", "date",
				"time", "allMeterKvaAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/yesterdaykvaassets")
	public MappingJacksonValue getYesterdayKvaByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Yesterday Kva By Asset");
		List<ProcessedData> list = allMeterDataService.getYesterdayKvaByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId",
				"unixTimestamp", "timestamp", "date", "time", "vaTotal");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastweekkva")
	public MappingJacksonValue getLastWeekKva() throws Exception {
		log.debug("Rest request to get Last Week kva");
		List<AllMeterData> list = allMeterDataService.getLastWeekKva();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "dailyAllMeterTotalKvaAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastweekkvaassets")
	public MappingJacksonValue getLastWeekKvaByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Last Week kva By Asset");
		List<ProcessedData> list = allMeterDataService.getLastWeekKvaByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "date",
				"time", "week", "weekDay", "dailyIndividualMeterTotalKvaAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastmonthkva")
	public MappingJacksonValue getLastMonthKva() throws Exception {
		log.debug("Rest request to get Last Month kva ");
		List<AllMeterData> list = allMeterDataService.getLastMonthKva();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "month", "dailyAllMeterTotalKvaAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastmonthkvaassets")
	public MappingJacksonValue getLastMonthKvaByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Last Month kva By Asset");
		List<ProcessedData> list = allMeterDataService.getLastMonthKvaByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "date",
				"time", "week", "weekDay", "month", "dailyIndividualMeterTotalKvaAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/yesterdaypf")
	public MappingJacksonValue getYesterdayPf() throws Exception {
		log.debug("Rest request to get Yesterday kva");
		List<AllMeterData> list = allMeterDataService.getYesterdayPf();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "timestamp", "date",
				"time", "allMeterPfInstAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/yesterdaypfassets")
	public MappingJacksonValue getYesterdayPfByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Yesterday pf By Asset");
		List<ProcessedData> list = allMeterDataService.getYesterdayPfByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId",
				"unixTimestamp", "timestamp", "date", "time", "pfAvgInst");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastweekpf")
	public MappingJacksonValue getLastWeekPf() throws Exception {
		log.debug("Rest request to get Last Week pf");
		List<AllMeterData> list = allMeterDataService.getLastWeekPf();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "dailyAllMeterTotalPfAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastweekpfassets")
	public MappingJacksonValue getLastWeekPfByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Last Week pf By Asset");
		List<ProcessedData> list = allMeterDataService.getLastWeekPfByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "date",
				"time", "week", "weekDay", "dailyIndividualMeterTotalPfAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastmonthpf")
	public MappingJacksonValue getLastMonthPf() throws Exception {
		log.debug("Rest request to get Last Month pf ");
		List<AllMeterData> list = allMeterDataService.getLastMonthPf();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "month", "dailyAllMeterTotalPfAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastmonthpfassets")
	public MappingJacksonValue getLastMonthPfByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Last Month pf By Asset");
		List<ProcessedData> list = allMeterDataService.getLastMonthPfByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "date",
				"time", "week", "weekDay", "month", "dailyIndividualMeterTotalPfAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/yesterdayvoltage")
	public MappingJacksonValue getYesterdayVoltage() throws Exception {
		log.debug("Rest request to get Yesterday voltge");
		List<AllMeterData> list = allMeterDataService.getYesterdayVoltage();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "timestamp", "date",
				"time", "allMeterVryPhaseAvg", "allMeterVybPhaseAvg", "allMeterVbrPhaseAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/yesterdayvoltageassets")
	public MappingJacksonValue getYesterdayVoltageByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Yesterday voltage By Asset");
		List<ProcessedData> list = allMeterDataService.getYesterdayPfByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId",
				"unixTimestamp", "timestamp", "date", "time", "vryphase", "vybphase", "vbrphase");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastweekvoltage")
	public MappingJacksonValue getLastWeekVoltage() throws Exception {
		log.debug("Rest request to get Last Week voltage");
		List<AllMeterData> list = allMeterDataService.getLastWeekVoltage();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "allMeterVryPhaseAvg", "allMeterVybPhaseAvg", "allMeterVbrPhaseAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastweekvoltageassets")
	public MappingJacksonValue getLastWeekVoltageByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Last Week voltage By Asset");
		List<ProcessedData> list = allMeterDataService.getLastWeekVoltageByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "date",
				"time", "week", "weekDay", "dailyIndividualMeterVryVoltageAvg", "dailyIndividualMeterVybVoltageAvg",
				"dailyIndividualMeterVbrVoltageAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastmonthvoltage")
	public MappingJacksonValue getLastMonthVoltage() throws Exception {
		log.debug("Rest request to get Last Month voltage ");
		List<AllMeterData> list = allMeterDataService.getLastMonthVoltage();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "month", "allMeterVryPhaseAvg", "allMeterVybPhaseAvg", "allMeterVbrPhaseAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastmonthvoltageassets")
	public MappingJacksonValue getLastMonthVoltageByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Last Month voltage By Asset");
		List<ProcessedData> list = allMeterDataService.getLastMonthVoltageByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "date",
				"time", "week", "weekDay", "month", "dailyIndividualMeterVryVoltageAvg",
				"dailyIndividualMeterVybVoltageAvg", "dailyIndividualMeterVbrVoltageAvg");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/yesterdayco2")
	public MappingJacksonValue getYesterdayCo2() throws Exception {
		log.debug("Rest request to get Yesterday co2");
		List<AllMeterData> list = allMeterDataService.getYesterdayCo2();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "timestamp", "date",
				"time", "allMeterCarbonEmissionSum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/yesterdaycoassets")
	public MappingJacksonValue getYesterdayCo2ByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Yesterday co2 By Asset");
		List<ProcessedData> list = allMeterDataService.getYesterdayCo2ByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId",
				"unixTimestamp", "timestamp", "date", "time", "carbonEmission");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastweekco")
	public MappingJacksonValue getLastWeekCo2() throws Exception {
		log.debug("Rest request to get Last Week co2");
		List<AllMeterData> list = allMeterDataService.getLastWeekCo2();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "allMeterDailyCarbonEmissionCumulativeValue");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastweekcoassets")
	public MappingJacksonValue getLastWeekCo2ByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Last Week co2 By Asset");
		List<ProcessedData> list = allMeterDataService.getLastWeekCo2ByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "date",
				"time", "week", "weekDay", "dailyMeterWiseCo2Sum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastmonthco")
	public MappingJacksonValue getLastMonthCo2() throws Exception {
		log.debug("Rest request to get Last Month co ");
		List<AllMeterData> list = allMeterDataService.getLastMonthCo2();
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "date", "time", "week",
				"weekDay", "month", "allMeterDailyCarbonEmissionCumulativeValue");
		FilterProvider filters = new SimpleFilterProvider().addFilter("allMeterData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

	@GetMapping("/historical/lastmonthcoassets")
	public MappingJacksonValue getLastMonthCo2ByAsset(@RequestParam Integer[] assets) throws Exception {
		log.debug("Rest request to get Last Month co2 By Asset");
		List<ProcessedData> list = allMeterDataService.getLastMonthCo2ByAssets(assets);
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("siteId", "assetId", "date",
				"time", "week", "weekDay", "month", "dailyMeterWiseCo2Sum");
		FilterProvider filters = new SimpleFilterProvider().addFilter("processedData", filter);
		MappingJacksonValue mapping = new MappingJacksonValue(list);
		mapping.setFilters(filters);
		return mapping;
	}

}