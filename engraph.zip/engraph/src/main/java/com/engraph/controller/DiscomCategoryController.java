package com.engraph.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.model.DiscomCategoryBusinessTypeMaster;
import com.engraph.model.PowerTensionMaster;
import com.engraph.repository.DiscomCategoryRepository;
import com.engraph.repository.PowerTensionRepository;

@RestController
@RequestMapping("/engraph")
public class DiscomCategoryController {

	private static final Logger log = LoggerFactory.getLogger(DiscomCategoryController.class);
	
	private String ENTITY_NAME = "DiscomCategoryDetails";

	private String applicationName = "engraph";
	
	@Autowired
	private DiscomCategoryRepository categoryRepository;
	
	@Autowired
	private PowerTensionRepository powerTensionRepository;
	
	@GetMapping("/discomcategories")
    public List<DiscomCategoryBusinessTypeMaster> getAllDiscomCategories(@RequestParam("power_tension_id") long powerTenctionId) {
		
		log.debug("Rest request of  get all discom categories", powerTenctionId);
		
		Optional<PowerTensionMaster> powerMaster = powerTensionRepository.findById(powerTenctionId);
        List<DiscomCategoryBusinessTypeMaster> list = categoryRepository.findAllByPowerTenctionId(powerMaster.get());
        return list;
    }
	
	
	
}
