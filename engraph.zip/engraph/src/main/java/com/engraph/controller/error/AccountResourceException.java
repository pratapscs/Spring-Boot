package com.engraph.controller.error;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AccountResourceException extends RuntimeException{
	
	private static final long serialVersionUID = -6869084422385344120L;
	
	private static final Logger logger = LoggerFactory.getLogger(AccountResourceException.class);

	public AccountResourceException(String message) {
        super(message);
	}
}
