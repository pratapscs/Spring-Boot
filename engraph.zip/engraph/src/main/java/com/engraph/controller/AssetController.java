package com.engraph.controller;

import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.controller.error.BadRequestAlertException;
import com.engraph.controller.error.SiteResourceException;
import com.engraph.controller.util.PaginationUtil;
import com.engraph.model.Asset;
import com.engraph.model.SiteMaster;
import com.engraph.repository.SiteMasterRepository;
import com.engraph.service.AssetService;
import com.engraph.service.dto.AssetDTO;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class AssetController {

	private static final Logger log = LoggerFactory.getLogger(AssetController.class);

	private String ENTITY_NAME = "AssetDetails";

	private String applicationName = "engraph";

	@Autowired
	private AssetService assetService;

	@Autowired
	private SiteMasterRepository siteMasterRepository;

	/**
	 * {@code POST /asset} : Creates a new Asset and save Asset information.
	 * <p>
	 *
	 * @param Asset the asset to create.
	 * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with
	 *         body the new Asset, or with status {@code 400 (Bad Request)} if
	 *         ElectricityMeter id is missing or not exists.
	 * @throws URISyntaxException if the Location URI syntax is incorrect.
	 */

	@PostMapping("/asset")
	public List<Asset> createAsset(@Valid @RequestBody AssetDTO assetDTO) throws URISyntaxException {
		log.debug("REST request to save Asset : {}", assetDTO);
		
		if (assetDTO.getSiteId() == null) {
			throw new BadRequestAlertException("An Site ID is must for create Asset", ENTITY_NAME, "idRequired");
		}

		// Site details.
		Optional<SiteMaster> siteMaster = siteMasterRepository.findBySiteId(assetDTO.getSiteId());
		
		if (!siteMaster.isPresent()) {
			throw new BadRequestAlertException("An Site is not exists ", ENTITY_NAME, "SiteNotExists");
		}
		
		List<Asset> assets = assetService.saveAssetInfo(assetDTO, siteMaster.get());
		
		return assets;
	}

	
	/**
	 * {@code GET /site-assets} : get all assets of an site.
	 *
	 * @param pageable the pagination information. @return the
	 *                 {@link ResponseEntity} with status {@code 200 (OK)} and with
	 *                 body all assets. @throws
	 */
	@GetMapping("/site-assets")
	public ResponseEntity<List<Asset>> getAllAssetsofSite(
			@RequestParam(name = "siteId", required = false) Long siteId, Pageable pageable) throws URISyntaxException {
		log.debug("Rest request of  get all assets of site ", siteId);

		Optional<SiteMaster> site = siteMasterRepository.findBySiteId(siteId);

		if (!site.isPresent())
			throw new SiteResourceException("No Site was found for this siteId");
		final Page<Asset> page = assetService.getAllAssetssofSite(site.get(), pageable);
		
		HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/engraph/site-assets");
		return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
	}
	
}
