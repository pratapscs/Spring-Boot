package com.engraph.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.engraph.model.FtpDetails;
import com.engraph.repository.FtpRepository;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class FtpController {

	private static final Logger log = LoggerFactory.getLogger(FtpController.class);

	@Autowired
	private FtpRepository ftpRepository;


	@GetMapping("/ftpdetails")
	public List<FtpDetails> getAllFtpdetails() {
		log.debug("Get all FTP details...");
		List<FtpDetails> ftpdetails = new ArrayList<>();
		ftpRepository.findAll().forEach(ftpdetails::add);
		return ftpdetails;
	}

	@PostMapping(value = "/ftp/create")
	public FtpDetails postFTPDetails(@RequestBody FtpDetails ftpdetails) {
		FtpDetails ftp = ftpRepository.save(ftpdetails);
		return ftp;
	}

	@GetMapping("/ftp/{ftpID}")
	public ResponseEntity<FtpDetails> getFTPById(@PathVariable(value = "ftpID") Long ftpID)
			throws ResourceNotFoundException {
		FtpDetails ftp = ftpRepository.findById(ftpID)
				.orElseThrow(() -> new ResourceNotFoundException("FTP not found for this id :: " + ftpID));
		return ResponseEntity.ok().body(ftp);
	}

	@PutMapping("/update-ftp/{ftpID}")
	public ResponseEntity<FtpDetails> updateFTP(@PathVariable(value = "ftpID") Long ftpID,
			@Valid @RequestBody FtpDetails ftpDetails) throws ResourceNotFoundException {
		FtpDetails ftp = ftpRepository.findById(ftpID)
				.orElseThrow(() -> new ResourceNotFoundException("FTP not found for this id :: " + ftpID));
		ftp.setFtpUrl(ftpDetails.getFtpUrl());
		ftp.setFtpUID(ftpDetails.getFtpUID());
		ftp.setFtpPassword(ftpDetails.getFtpPassword());
		ftp.setManufacturingID(ftpDetails.getManufacturingID());

		final FtpDetails updatedFTP = ftpRepository.save(ftp);
		return ResponseEntity.ok(updatedFTP);
	}

	@DeleteMapping("/delete-ftp/{ftpID}")
	public Map<String, Boolean> deleteFTP(@PathVariable(value = "ftpID") Long ftpID)
			throws ResourceNotFoundException {
		ftpRepository.findById(ftpID)
				.orElseThrow(() -> new ResourceNotFoundException("FTP not found for this id :: " + ftpID));

		ftpRepository.deleteById(ftpID);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
}
