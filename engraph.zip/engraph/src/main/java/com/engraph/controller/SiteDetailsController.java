package com.engraph.controller;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.controller.error.BadRequestAlertException;
import com.engraph.controller.error.SiteResourceException;
import com.engraph.controller.util.HeaderUtil;
import com.engraph.model.Organization;
import com.engraph.model.SiteElectrical;
import com.engraph.model.SiteMaster;
import com.engraph.model.SitePower;
import com.engraph.repository.OrganizationRepository;
import com.engraph.repository.SiteMasterRepository;
import com.engraph.service.SiteDetailService;
import com.engraph.service.dto.Node;
import com.engraph.service.dto.ResultDTO;
import com.engraph.service.dto.SiteElectricalInfo;
import com.engraph.service.dto.SiteGeneralInfo;
import com.engraph.service.dto.SitePowerInfo;
import com.engraph.service.dto.SolarPanelDTO;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class SiteDetailsController {

	private static final Logger log = LoggerFactory.getLogger(SiteDetailsController.class);

	private String ENTITY_NAME = "SiteDetail";

	private String applicationName = "engraph";

	@Autowired
	private OrganizationRepository organizationRepository;

	@Autowired
	private SiteDetailService siteDetailService;

	@Autowired
	private SiteMasterRepository siteMasterRepository;

	/**
	 * {@code POST  /site-general-info} : Creates a new site and save general
	 * information.
	 * <p>
	 *
	 * @param SiteGeneralInfo the site to create.
	 * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with
	 *         body the new site, or with status {@code 400 (Bad Request)} if org id
	 *         is missing or not exists.
	 * @throws URISyntaxException if the Location URI syntax is incorrect.
	 */
	@PostMapping("/site-general-info")
	public ResponseEntity<SiteMaster> createSiteGeneralInfo(@Valid @RequestBody SiteGeneralInfo siteGeneralInfo)
			throws URISyntaxException {
		log.debug("REST request to save site : {}", siteGeneralInfo);
		if (siteGeneralInfo.getOrgId() == null) {
			throw new BadRequestAlertException("An Org ID is must for create site", ENTITY_NAME, "idRequired");
		}
		// update the organization details.
		Optional<Organization> organization = organizationRepository.findByOrgId(siteGeneralInfo.getOrgId());

		if (!organization.isPresent()) {
			throw new BadRequestAlertException("An Organization is not exists ", ENTITY_NAME, "OrgNotExists");
		}
		Organization org = organization.get();
		org.setIsMultiSite(siteGeneralInfo.getIsMultiSite());
		org.setTotalSite(siteGeneralInfo.getTotalSite());
		org.setTotalLegalSite(siteGeneralInfo.getTotalLegalSite());
		org = organizationRepository.save(org);

		SiteMaster siteMaster = siteDetailService.saveSiteInfo(siteGeneralInfo, org);
		return ResponseEntity.created(new URI("/engraph/site-general-info/" + siteMaster.getSiteId()))
				.headers(HeaderUtil.createAlert(applicationName, ENTITY_NAME, siteMaster.getSiteId().toString()))
				.body(siteMaster);

	}

	/**
	 * {@code POST  /site-electrical-info} : Creates a new site and save electrical
	 * information.
	 * <p>
	 *
	 * @param SiteElectricalInfo the site to create.
	 * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with
	 *         body the new site electrical, or with status
	 *         {@code 400 (Bad Request)} if site id is missing or not exists.
	 * @throws URISyntaxException if the Location URI syntax is incorrect.
	 */
	@PostMapping("/site-electrical-info")
	public ResponseEntity<SiteElectrical> createSiteElectricalInfo(
			@Valid @RequestBody SiteElectricalInfo siteElectricalInfo) throws URISyntaxException {
		log.debug("REST request to save site electrical info : {}", siteElectricalInfo);
		if (siteElectricalInfo.getSiteId() == null) {
			throw new BadRequestAlertException("An Site ID is must for save site electrical details", ENTITY_NAME,
					"SiteidRequired");
		}
		// update the Site Master details.
		Optional<SiteMaster> siteMaster = siteMasterRepository.findBySiteId(siteElectricalInfo.getSiteId());
		if (!siteMaster.isPresent()) {
			throw new BadRequestAlertException("An Site is not exists ", ENTITY_NAME, "SiteNotExists");
		}

		SiteElectrical siteElectrical = siteDetailService.saveSiteElectricalInfo(siteElectricalInfo, siteMaster.get());
		
		
		return ResponseEntity.created(new URI("/engraph/site-general-info/" + siteElectrical.getSiteElectricalId()))
				.headers(HeaderUtil.createAlert(applicationName, ENTITY_NAME,
						siteElectrical.getSiteElectricalId().toString()))
				.body(siteElectrical);

	}

	/**
	 * {@code POST  /site-power-info} : Creates a new site and save power
	 * information.
	 * <p>
	 *
	 * @param SiteElectricalInfo the site to create.
	 * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with
	 *         body the new site electrical, or with status
	 *         {@code 400 (Bad Request)} if site id is missing or not exists.
	 * @throws URISyntaxException if the Location URI syntax is incorrect.
	 */
	@PostMapping("/site-power-info")
	public ResponseEntity<SitePower> createSitePowerInfo(@Valid @RequestBody SitePowerInfo sitePowerInfo)
			throws URISyntaxException {
		log.debug("REST request to save Site Power info : {}", sitePowerInfo);

		if (sitePowerInfo.getSiteId() == null) {
			throw new BadRequestAlertException("An Site ID is must for save site electrical details", ENTITY_NAME,
					"SiteidRequired");
		}
		// update the Site Master details.
		Optional<SiteMaster> siteMaster = siteMasterRepository.findBySiteId(sitePowerInfo.getSiteId());
		if (!siteMaster.isPresent()) {
			throw new BadRequestAlertException("An Site is not exists ", ENTITY_NAME, "SiteNotExists");
		}

		SitePower sitePower = siteDetailService.saveSitePowerInfo(sitePowerInfo, siteMaster.get());
		return ResponseEntity.created(new URI("/engraph/site-general-info/" + sitePower.getSitePowerId()))
				.headers(HeaderUtil.createAlert(applicationName, ENTITY_NAME, sitePower.getSitePowerId().toString()))
				.body(sitePower);
	}

	/**
	 * {@code GET /site-details} : get all details of an site.
	 *
	 * @param pageable the pagination information. @return the
	 *                 {@link ResponseEntity} with status {@code 200 (OK)} and with
	 *                 body all details. @throws
	 */

	@GetMapping("/site-details")
	public List<Node> getAllDetailssofSite(@RequestParam(name = "siteId", required = false) Long siteId,
			Pageable pageable) throws URISyntaxException {
		log.debug("Rest request of  get all details of site ");

		Optional<SiteMaster> site = siteMasterRepository.findBySiteId(siteId);

		if (!site.isPresent())
			throw new SiteResourceException("No Site was found for this siteId");

		ResultDTO result1 = siteDetailService.getDetailsOfSite(site.get(), pageable);
		
		return enrichResponse(result1);
	}
	
	public List<Node> enrichResponse(ResultDTO result) {
		SiteGeneralInfo generalInfo = result.getSite();
		List<Node> parentList = new ArrayList<Node>();
		Node site = new Node();
		site.setName(generalInfo.getSiteName());
		site.setValue(generalInfo.getSiteId());
		site.setType("site");
		generalInfo.getBuildings().forEach(building -> {
			Node buildingNode = new Node();
			buildingNode.setName(building.getBuildingName());
			buildingNode.setValue(building.getBuildingId());
			buildingNode.setType("building");
			building.getFloors().forEach(floor -> {
				Node floorNode = new Node();
				floorNode.setName(floor.getBuildingFloorName());
				floorNode.setValue(floor.getBuildingFloorId());
				floorNode.setType("floor");
				floor.getAssets().forEach(asset -> {
					Node assetNode = new Node();
					assetNode.setName(asset.getAssetName());
					assetNode.setValue(asset.getAssetId());
					assetNode.setType("asset");
					floorNode.getChildren().add(assetNode);
				});
				buildingNode.getChildren().add(floorNode);
			});
			site.getChildren().add(buildingNode);
		});
		parentList.add(site);
		return parentList;
	}
	
	

	/*
	 * public List<Node> enrichResponse(ResultDTO result) { SiteGeneralInfo
	 * generalInfo = result.getSite(); List<Node> parentList = new
	 * ArrayList<Node>(); Node site = new Node();
	 * site.setText(generalInfo.getSiteName());
	 * site.setValue(generalInfo.getSiteId());
	 * 
	 * generalInfo.getBuildings().forEach(building -> { Node buildingNode = new
	 * Node(); buildingNode.setText(building.getBuildingName());
	 * buildingNode.setValue(building.getBuildingId());
	 * building.getFloors().forEach(floor -> { Node floorNode = new Node();
	 * floorNode.setText(floor.getBuildingFloorName());
	 * floorNode.setValue(floor.getBuildingFloorId());
	 * floor.getAssets().forEach(asset -> { Node assetNode = new Node();
	 * assetNode.setText(asset.getAssetName());
	 * assetNode.setValue(asset.getAssetId());
	 * floorNode.getChildren().add(assetNode); });
	 * buildingNode.getChildren().add(floorNode); });
	 * site.getChildren().add(buildingNode); }); parentList.add(site); return
	 * parentList; }
	 */
	
	@GetMapping("/all-sitedetails")
	public List<SiteMaster> getAllSitedetails() {
		log.debug("Get all Site details...");
		List<SiteMaster> siteDetails = new ArrayList<>();
		siteMasterRepository.findAll().forEach(siteDetails::add);
		return siteDetails;
	}
	
	
	@GetMapping("/solar/{startDate}/{endDate}/{siteId}")
	public ResponseEntity<List<SolarPanelDTO>> currentSolar(@PathVariable("startDate") String startDate,
			@PathVariable("endDate") String endDate, @PathVariable("siteId") Long siteId) throws IOException, ParseException, JSONException {
		log.debug("Rest request of  get all assets of site ", siteId);

		Optional<SiteMaster> site = siteMasterRepository.findBySiteId(siteId);
		if (!site.isPresent())
			throw new SiteResourceException("No Site was found for this siteId");

		List<SolarPanelDTO> result = siteDetailService.getSolarIrredience(startDate, endDate, site.get());

		return new ResponseEntity<>(result, HttpStatus.OK);

	}

	@GetMapping("/solar-forecast/{startDate}/{endDate}/{siteId}/{solarPannelArea}")
	public ResponseEntity<List<SolarPanelDTO>> solarForecast(@PathVariable("startDate") String startDate,
			@PathVariable("endDate") String endDate, @PathVariable("siteId") Long siteId,
			@PathVariable("solarPannelArea") Long solarPannelArea)
			throws IOException, ParseException, JSONException {
		log.debug("Rest request of  get all assets of site ", siteId);

		Optional<SiteMaster> site = siteMasterRepository.findBySiteId(siteId);
		
		if (!site.isPresent())
			throw new SiteResourceException("No Site was found for this siteId");

		List<SolarPanelDTO> result = siteDetailService.getSolarForecast(startDate, endDate, site.get(),solarPannelArea);
		
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	/*
	 * @GetMapping("/site-details") public MappingJacksonValue getAllDetailssofSite(
	 * 
	 * @RequestParam(name = "siteId", required = false) Long siteId, Pageable
	 * pageable) throws URISyntaxException {
	 * log.debug("Rest request of  get all details of site ");
	 * 
	 * Optional<SiteMaster> site = siteMasterRepository.findBySiteId(siteId);
	 * 
	 * if (!site.isPresent()) throw new
	 * SiteResourceException("No Site was found for this siteId"); ResultDTO result
	 * = siteDetailService.getDetailsOfSite(site.get(), pageable);
	 * 
	 * SimpleBeanPropertyFilter filter =
	 * SimpleBeanPropertyFilter.filterOutAllExcept("site", "site_name", "buildings",
	 * "building_name", "floors", "building_floor_name", "assets", "asset_name");
	 * FilterProvider filters = new SimpleFilterProvider() .addFilter("resultDTO",
	 * SimpleBeanPropertyFilter.filterOutAllExcept("site"))
	 * .addFilter("siteGeneralInfoDTO",
	 * SimpleBeanPropertyFilter.filterOutAllExcept("site_name","buildings"))
	 * .addFilter("siteBuildingDTO",
	 * SimpleBeanPropertyFilter.filterOutAllExcept("building_name","floors"))
	 * .addFilter("buildingFloorDTO",
	 * SimpleBeanPropertyFilter.filterOutAllExcept("building_floor_name", "assets"))
	 * .addFilter("meterAssetDTO",
	 * SimpleBeanPropertyFilter.filterOutAllExcept("asset_name"));
	 * MappingJacksonValue mapping = new MappingJacksonValue(result);
	 * mapping.setFilters(filters);
	 * 
	 * return mapping;
	 * 
	 * }
	 */

}