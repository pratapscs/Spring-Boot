
package com.engraph.controller.error;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SiteResourceException extends RuntimeException{

	private static final long serialVersionUID = -6528342049250159804L;
	
	private static final Logger logger = LoggerFactory.getLogger(SiteResourceException.class);

	public SiteResourceException(String message) {
        super(message);
	}
}
