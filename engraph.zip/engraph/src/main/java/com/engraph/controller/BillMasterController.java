package com.engraph.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.engraph.controller.error.BadRequestAlertException;
import com.engraph.controller.util.HeaderUtil;
import com.engraph.model.BillMaster;
import com.engraph.model.DiscomCategoryBusinessTypeMaster;
import com.engraph.model.DiscomMaster;
import com.engraph.model.LocationMaster;
import com.engraph.model.MeterTimeBill;
import com.engraph.model.PowerTensionMaster;
import com.engraph.model.SiteMaster;
import com.engraph.repository.SiteMasterRepository;
import com.engraph.service.BillDetailsService;
import com.engraph.service.IAllMeterDataService;
import com.engraph.service.SiteDetailService;
import com.engraph.service.dto.BillGeneralInfo;
import com.engraph.service.dto.BillNode;
import com.engraph.service.dto.BillUtility;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class BillMasterController {

	private static final Logger log = LoggerFactory.getLogger(BillMasterController.class);

	private String ENTITY_NAME = "BillDetails";

	private String applicationName = "engraph";
	
	@Autowired
	private BillDetailsService billDetailService;
	
	@Autowired
	private SiteMasterRepository siteMasterRepository;
	
	@Autowired
	private IAllMeterDataService allMeterDataService;
	
	@Autowired
	private SiteDetailService siteDetailService;
	
	@PostMapping("/bill-general-info")
	public ResponseEntity<BillMaster> createBillGeneralInfo(@Valid 
											@RequestBody BillGeneralInfo billGeneralInfo,
														 DiscomMaster discomMaster,
														 PowerTensionMaster powerTensionMaster,
														 DiscomCategoryBusinessTypeMaster discomCategoryMaster,
														 SiteMaster siteMaster,
														 LocationMaster locationMaster)
			throws URISyntaxException {
		log.debug("REST request to save bill : {}", billGeneralInfo);
		if (billGeneralInfo.getSiteId() == null) {
			throw new BadRequestAlertException("An Bill ID is must for create Bill", ENTITY_NAME, "idRequired");
		}
		
		Optional<SiteMaster> site = siteMasterRepository.findBySiteId(billGeneralInfo.getSiteId());

		if (!site.isPresent()) {
			throw new BadRequestAlertException("An Site is not exists ", ENTITY_NAME, "SiteNotExists");
		}
		
		BillMaster billMaster = billDetailService.saveBillInfo(billGeneralInfo, discomMaster,powerTensionMaster, discomCategoryMaster, siteMaster, locationMaster);
		return ResponseEntity.created(new URI("/engraph/bill-general-info/" + billMaster.getBillMasterId()))
				.headers(HeaderUtil.createAlert(applicationName, ENTITY_NAME, billMaster.getBillMasterId().toString()))
				.body(billMaster);

	}
	
	
	@GetMapping("/site-billing-details/{year}/{month}/{siteId}") 
	public List<BillNode> getAllDetailssofSite(@PathVariable("year") String year,
											@PathVariable("month") String month,
											@PathVariable("siteId") Long siteId) {
			
		log.debug("Rest request of  get all details of site bill ");
			
		String siteBillId = Long.toString(siteId);
			
		List<MeterTimeBill> siteBill = allMeterDataService.findByBillSiteId(year,month,siteBillId);
        
		MeterTimeBill site = allMeterDataService.findBySiteBill(year,month,siteBillId);
		
		List<MeterTimeBill> buildingBill = allMeterDataService.findByBuildingBill(year,month,siteBillId);
		
		List<MeterTimeBill> floorBill = allMeterDataService.findByFloorBill(year,month,siteBillId);
		
		List<MeterTimeBill> assetBill = allMeterDataService.findByAssetBill(year,month,siteBillId);
		
		List<BillNode> parentList = new ArrayList<BillNode>();
		
		BillNode siteNode = new BillNode();
		siteNode.setName(site.getSiteName());
		siteNode.setValue(site.getSiteId());
		siteNode.setType("site");
		siteNode.setPrice(site.getEnergyConsumptionPrice());
		siteNode.setBillData(site.getSiteName() + " : " + site.getEnergyConsumptionPrice()+" INR"); 
		
		buildingBill.forEach(building -> { 
				BillNode buildingNode = new BillNode(); 
				buildingNode.setName(building.getBuildingName());
				buildingNode.setValue(building.getSiteBuildingId());
				buildingNode.setType("building");
				buildingNode.setPrice(building.getEnergyConsumptionPrice());
				buildingNode.setBillData(building.getBuildingName() + " : " + building.getEnergyConsumptionPrice()+" INR"); 
	
		floorBill.forEach(floor -> { 
				BillNode floorNode = new BillNode();
				floorNode.setName(floor.getFloorName());
				floorNode.setValue(floor.getBuildingFloorId());
				floorNode.setType("floor");
				floorNode.setPrice(floor.getEnergyConsumptionPrice());
				floorNode.setBillData(floor.getFloorName() + " : " + floor.getEnergyConsumptionPrice()+" INR"); 
		
		assetBill.forEach(asset -> { 
				 BillNode assetNode = new BillNode();
				 assetNode.setName(asset.getAssetName());
				 assetNode.setValue(asset.getAssetId());
				 assetNode.setType("asset"); 
				 assetNode.setPrice(asset.getEnergyConsumptionPrice());
				 assetNode.setBillData(asset.getAssetName() + " : " + asset.getEnergyConsumptionPrice()+" INR");
				 
				 floorNode.getChildren().add(assetNode);
			  });
			  buildingNode.getChildren().add(floorNode);
			 });
			siteNode.getChildren().add(buildingNode);
		    });
			parentList.add(siteNode);
	       
		return parentList;	
	  }
	 
	
	@PostMapping(value = "/bill-utility")
	public BillUtility createBillUtility(@RequestBody BillUtility billUtility) {
		
		int _billUtility =  allMeterDataService.saveBillUtility(billUtility);
			
		return billUtility;
    }
	
	@GetMapping("/site-utility-billing-details/{year}/{month}/{siteId}") 
	public BillUtility getSiteUtilityBill(@PathVariable("year") String year,
											@PathVariable("month") String month,
											@PathVariable("siteId") Long siteId) {
			
		log.debug("Rest request of  get all details of site utility bill ");
			
		BillUtility billUtility = allMeterDataService.findBySiteBillUtility(year,month,siteId);
		
		return billUtility;
	}
	
	
}
