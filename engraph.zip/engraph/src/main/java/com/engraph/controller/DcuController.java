package com.engraph.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.model.Dcudetails;
import com.engraph.repository.DcuRepository;;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class DcuController {

	private static final Logger log = LoggerFactory.getLogger(DcuController.class);

	private String ENTITY_NAME = "DCUdetails";

	private String applicationName = "engraph";

	@Autowired
	private DcuRepository dcuRepository;

	
	@GetMapping("/dcudetails")
	public List<Dcudetails> getAllDcudetails() {
		log.debug("Get all DCU details...");
		List<Dcudetails> dcuDetails = new ArrayList<>();
		dcuRepository.findAll().forEach(dcuDetails::add);
		return dcuDetails;
	}

	@PostMapping(value = "/dcu/create")
	public Dcudetails postDCUDetails(@RequestBody Dcudetails dcudetails) {
		Dcudetails dcu = dcuRepository.save(dcudetails);
		return dcu;
	}

	@GetMapping("/dcu/{manufacturingID}")
	public ResponseEntity<Dcudetails> getDCUById(@PathVariable(value = "manufacturingID") Long manufacturingID)
			throws ResourceNotFoundException {
		Dcudetails dcu = dcuRepository.findById(manufacturingID)
				.orElseThrow(() -> new ResourceNotFoundException("DCU not found for this id :: " + manufacturingID));
		return ResponseEntity.ok().body(dcu);
	}

	@PutMapping("/update-dcu/{dcuId}")
	public ResponseEntity<Dcudetails> updateDCU(@PathVariable(value = "dcuId") Long dcuId,
			@Valid @RequestBody Dcudetails dcuDetails) throws ResourceNotFoundException {
		Dcudetails dcu = dcuRepository.findById(dcuId)
				.orElseThrow(() -> new ResourceNotFoundException("DCU not found for this id :: " + dcuId));
		dcu.setManufacturingID(dcuDetails.getManufacturingID());
		dcu.setModelNo(dcuDetails.getModelNo());
		dcu.setManufacturingDate(dcuDetails.getManufacturingDate());
		dcu.setServiceActiveState(dcuDetails.getServiceActiveState());
		dcu.setBatchNumber(dcuDetails.getBatchNumber());
		dcu.setLotQuantity(dcuDetails.getLotQuantity());
		dcu.setBasePrice(dcuDetails.getBasePrice());
		dcu.setMarketPrice(dcuDetails.getMarketPrice());
		dcu.setMinimumDiscountablePercentage(dcuDetails.getMinimumDiscountablePercentage());
		dcu.setMaximumDiscountablePercentage(dcuDetails.getMaximumDiscountablePercentage());

		final Dcudetails updatedDCU = dcuRepository.save(dcu);
		return ResponseEntity.ok(updatedDCU);
	}

	@DeleteMapping("/delete-dcu/{manufacturingID}")
	public Map<String, Boolean> deleteDCU(@PathVariable(value = "manufacturingID") Long manufacturingID)
			throws ResourceNotFoundException {
		Dcudetails dcu = dcuRepository.findById(manufacturingID)
				.orElseThrow(() -> new ResourceNotFoundException("DCU not found for this id :: " + manufacturingID));

		dcuRepository.deleteById(manufacturingID);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
