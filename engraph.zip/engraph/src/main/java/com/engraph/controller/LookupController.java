package com.engraph.controller;

import java.net.URISyntaxException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.controller.util.PaginationUtil;

import com.engraph.service.LookupService;
import com.engraph.service.dto.DesignationDTO;
import com.engraph.service.dto.LookupDTO;
import com.engraph.service.dto.RoleDTO;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class LookupController {

	private static final Logger log = LoggerFactory.getLogger(LookupController.class);
	
	@Autowired
	private LookupService lookupService; 
	
	
	/**
     * {@code GET /role} : get all role of an application.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body all role.
     * @throws 	 
     */
	@GetMapping("/roles")
    public ResponseEntity<List<RoleDTO>> getAllRole(Pageable pageable) throws URISyntaxException {
        log.debug("Rest request of  get all role");
    	final Page<RoleDTO> page = lookupService.getAllRole(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/engraph/roles");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
	
	/**
     * {@code GET /designation} : get all designation of an application.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body all designation.
     * @throws 	 
     */
	@GetMapping("/designation")
    public ResponseEntity<List<DesignationDTO>> getAllDesignation(Pageable pageable) throws URISyntaxException {
        log.debug("Rest request of  get all designation");
    	final Page<DesignationDTO> page = lookupService.getAllDesignation(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/engraph/designation");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
	
	
	/**
	 * GET /building/:site-id : get the "id" building and floor.
	 *
	 * @param id the id of the building to retrieve
	 * @return the ResponseEntity with status 200 (OK) and with body the
	 *         BuildingFloor, or with status 404 (Not Found)
	 */
	@GetMapping("/building")
	public ResponseEntity<List<LookupDTO>> getBuildingFloor(@RequestParam(name = "siteId", required = false) Long siteId) {
		log.debug("REST request to get SiteBuilding for site ", siteId);
		List<LookupDTO> result = lookupService.getBuildingFloorForSite(siteId);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}
	
}
