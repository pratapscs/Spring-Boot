package com.engraph.controller;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.controller.error.BadRequestAlertException;
import com.engraph.controller.error.SiteResourceException;
import com.engraph.controller.util.PaginationUtil;
import com.engraph.controller.util.Producer;
import com.engraph.model.SiteMaster;
import com.engraph.model.WifiDetails;
import com.engraph.repository.SiteMasterRepository;
import com.engraph.repository.WifiRepository;
import com.engraph.service.WifiDetailsService;
import com.engraph.service.dto.WifiDetailsDTO;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class WifiController {

	private static final Logger log = LoggerFactory.getLogger(WifiController.class);

	private String ENTITY_NAME = "WifiDetails";

	@Autowired
	private WifiRepository wifiRepository;
	
	@Autowired
	private WifiDetailsService wifiService;
	
	@Autowired
	private SiteMasterRepository siteMasterRepository;
	
	@Autowired
	private Producer jmsProducer;

	@PostMapping("/wifi")
	public WifiDetails saveWifiDetails(@Valid @RequestBody WifiDetailsDTO wifiDTO) {
		
		if (wifiDTO.getSiteId() == null) {
			throw new BadRequestAlertException("An  is must for create wifi", ENTITY_NAME, "idRequired");
		}
		
		Optional<SiteMaster> siteDetails = siteMasterRepository.findById(wifiDTO.getSiteId());
		SiteMaster site = siteDetails.get();
		site.setSiteId(wifiDTO.getSiteId());
		
		WifiDetails wifiDetails = wifiService.saveWifiDetails(wifiDTO, site);
		
		jmsProducer.send(wifiDetails);
		
		return wifiDetails;
	}
	
	@GetMapping("/wifidetails")
	public ResponseEntity<List<WifiDetails>> getAllMetersofSite(
			@RequestParam(name = "siteId", required = false) Long siteId, Pageable pageable) throws URISyntaxException {
		log.debug("Rest request of  get sites ");

		Optional<SiteMaster> site = siteMasterRepository.findBySiteId(siteId);

		if (!site.isPresent())
			throw new SiteResourceException("No Site was found for this siteId");
		final Page<WifiDetails> page = wifiService.getAllWifiDetailsofSite(site.get(), pageable);
		HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/engraph/wifidetails");
		return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
	}

    @GetMapping("/wifi/{wifi_id}")
    public ResponseEntity<WifiDetails> getWifiById(@PathVariable(value = "wifi_id") Long wifiId)
        throws ResourceNotFoundException {
        WifiDetails wifi = wifiRepository.findById(wifiId)
          .orElseThrow(() -> new ResourceNotFoundException("Wifi not found for this id :: " + wifiId));
        return ResponseEntity.ok().body(wifi);
    }

    @PutMapping("/update-wifi/{wifi_id}")
    public ResponseEntity<WifiDetails> updateWifi(@PathVariable(value = "wifi_id") Long wifiId,
         @Valid @RequestBody WifiDetails wifiDetails) throws ResourceNotFoundException {
        WifiDetails wifi = wifiRepository.findById(wifiId)
        .orElseThrow(() -> new ResourceNotFoundException("Wifi not found for this id :: " + wifiId));

        wifi.setWifiName(wifiDetails.getWifiName());
        wifi.setWifiPassword(wifiDetails.getWifiPassword());
        final WifiDetails updatedWifi = wifiRepository.save(wifi);
        return ResponseEntity.ok(updatedWifi);
    }

    @DeleteMapping("/delete-wifi/{wifi_id}")
    public Map<String, Boolean> deleteWifi(@PathVariable(value = "wifi_id") Long wifiId)
         throws ResourceNotFoundException {
        WifiDetails wifi = wifiRepository.findById(wifiId)
       .orElseThrow(() -> new ResourceNotFoundException("Wifi not found for this id :: " + wifiId));

        wifiRepository.deleteById(wifiId);
        Map<String, Boolean> response = new HashMap();
        response.put("deleted", Boolean.TRUE);
        return response;
    }
    
   
	
}
