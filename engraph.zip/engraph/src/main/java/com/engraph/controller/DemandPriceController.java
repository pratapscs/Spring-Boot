package com.engraph.controller;

import java.net.URISyntaxException;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.model.DemandPriceMaster;
import com.engraph.service.DemandPriceService;
import com.engraph.service.dto.DemandPrice;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class DemandPriceController {

	private static final Logger log = LoggerFactory.getLogger(DemandPriceController.class);

	private String ENTITY_NAME = "DemandPriceDetails";

	private String applicationName = "engraph";
	
	@Autowired
	private DemandPriceService demandPriceService;
	
	
	/**
	 * {@code POST  /demandprice} : Creates a new demand price and save Demand price
	 * information.
	 * <p>
	 *
	 * @param demandprice the new demand price to create.
	 * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with
	 *         body the new site, or with status {@code 400 (Bad Request)} if org id
	 *         is missing or not exists.
	 * @throws URISyntaxException if the Location URI syntax is incorrect.
	 */
	@PostMapping("/demandprice")
	public List<DemandPriceMaster> createDemandPriceInfo(@Valid @RequestBody DemandPrice demandPriceInfo)
			throws URISyntaxException {
		log.debug("REST request to save demand price : {}", demandPriceInfo);

		List<DemandPriceMaster> demandPrices = demandPriceService.saveDemandPriceInfo(demandPriceInfo);
		
		return demandPrices;
	}
	
	
}
