package com.engraph.controller.error;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EmailAlreadyUsedException extends BadRequestAlertException {

	private static final long serialVersionUID = -7683906823981827246L;

	private static final Logger logger = LoggerFactory.getLogger(EmailAlreadyUsedException.class);
	
	public EmailAlreadyUsedException() {
	        super(ErrorConstants.EMAIL_ALREADY_USED_TYPE, "Email is already in use!", "userManagement", "emailexists");
	}
}
