package com.engraph.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.jms.JMSException;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.engraph.controller.error.BadRequestAlertException;
import com.engraph.controller.util.Producer;
import com.engraph.model.ClientDCUConfig;
import com.engraph.model.Dcudetails;
import com.engraph.model.SiteMaster;
import com.engraph.repository.ClientDCURepository;
import com.engraph.repository.DcuRepository;
import com.engraph.repository.SiteMasterRepository;
import com.engraph.service.ClientDcuService;
import com.engraph.service.dto.ClientDCUDTO;

@CrossOrigin(origins = { "http://localhost:4200", "*" })
@RestController
@RequestMapping("/engraph")
public class ClientDCUController {

	private static final Logger log = LoggerFactory.getLogger(FtpController.class);

	private String ENTITY_NAME = "ClientDCUDTO";

	@Autowired
	private ClientDCURepository clientDcuRepository;
	
	@Autowired
	private ClientDcuService clientDcuService;
	
	@Autowired
	private SiteMasterRepository siteMasterRepository;
	
	@Autowired
	private DcuRepository dcuRepository;
	
	@Autowired
	private Producer jmsProducer;
	
	
	@GetMapping("/client-dcudetails")
	public List<ClientDCUConfig> getAllClientDCUdetails() {
		log.debug("Get all client dcu details...");
		List<ClientDCUConfig> clientDcudetails = new ArrayList<>();
		clientDcuRepository.findAll().forEach(clientDcudetails::add);
		return clientDcudetails;
	}

	@PostMapping(value = "/client-dcu/create")
	public ClientDCUConfig postClientDCUDetails(@Valid @RequestBody ClientDCUDTO clientDCUDetails) throws JMSException {
		
		log.debug("REST request to save client DCU : {}", clientDCUDetails);
		if (clientDCUDetails.getSiteId() == null) {
			throw new BadRequestAlertException("An site ID is must for create client DCU", ENTITY_NAME, "idRequired");
		}
		
		Optional<SiteMaster> siteMaster = siteMasterRepository.findBySiteId(clientDCUDetails.getSiteId());
		Optional<Dcudetails> dcuDetails = dcuRepository.findByDcuId(clientDCUDetails.getDcuId());
		
		SiteMaster site = siteMaster.get();
		Dcudetails dcu = dcuDetails.get();
		ClientDCUConfig clientDCU = clientDcuService.saveClientDCUInfo(clientDCUDetails, site, dcu);
		
		jmsProducer.send(clientDCU);
		
		return clientDCU;
	}
	

	@GetMapping("/client-dcu/{clientDcuId}")
	public ResponseEntity<ClientDCUConfig> getClientDCUById(@PathVariable(value = "clientDcuId") Long clientDcuId)
			throws ResourceNotFoundException {
		ClientDCUConfig clientDCU = clientDcuRepository.findById(clientDcuId)
				.orElseThrow(() -> new ResourceNotFoundException("Client DCU not found for this id :: " + clientDcuId));
		return ResponseEntity.ok().body(clientDCU);
	}


	
	@PutMapping("/update-client-dcu/{clientDcuId}")
	public ResponseEntity<ClientDCUConfig> updateClientDCU(@PathVariable(value = "clientDcuId") Long clientDcuId,
			@Valid @RequestBody ClientDCUConfig clientDcuDetails) throws ResourceNotFoundException {
		ClientDCUConfig clientDcu = clientDcuRepository.findById(clientDcuId)
				.orElseThrow(() -> new ResourceNotFoundException("Client DCU not found for this id :: " + clientDcuId));
		clientDcu.setFrequency(clientDcuDetails.getFrequency());
		clientDcu.setFtpUID(clientDcuDetails.getFtpUID());
		clientDcu.setFtpURL(clientDcuDetails.getFtpURL());
		clientDcu.setFtpPassword(clientDcuDetails.getFtpPassword());
		clientDcu.setFtpPortNumber(clientDcuDetails.getFtpPortNumber());
		clientDcu.setBaudRate(clientDcuDetails.getBaudRate());
		clientDcu.setParity(clientDcuDetails.getParity());
		clientDcu.setStopBit(clientDcuDetails.getStopBit());
		clientDcu.setSiteId(clientDcuDetails.getSiteId());
		clientDcu.setDcuId(clientDcuDetails.getDcuId());
		
		final ClientDCUConfig updatedClientDCU = clientDcuRepository.save(clientDcu);
		
		return ResponseEntity.ok(updatedClientDCU);
	}


}
