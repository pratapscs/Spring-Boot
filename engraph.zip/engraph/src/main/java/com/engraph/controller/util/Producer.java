package com.engraph.controller.util;

import javax.jms.JMSException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import com.engraph.model.ClientDCUConfig;
import com.engraph.model.MeterSetup;
import com.engraph.model.WifiDetails;

@Component
public class Producer  {

	  private static final Logger log = LoggerFactory.getLogger(Producer.class);
	  
	  @Autowired
	  JmsTemplate jmsTemplate;
	  
	  @Value("${mq.topic}")
	  private String topic;
	
	  
	  public void send(final ClientDCUConfig clientDCUDetails) throws JMSException{
		  //topic = new ActiveMQTopic("TEST.Topic?consumer.retroactive=true");
		   jmsTemplate.convertAndSend( topic, clientDCUDetails);  
		  
	  } 	  

	  public void send(MeterSetup meterSetupDetails ){
		    jmsTemplate.convertAndSend(topic, meterSetupDetails);
	  }
	  
	  public void send(WifiDetails wifiDetails ){
		    jmsTemplate.convertAndSend(topic, wifiDetails);
	  }

}