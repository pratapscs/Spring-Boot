package com.engraph.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.engraph.model.SitePower;

@Repository
public interface SitePowerRepository extends JpaRepository<SitePower, Long>{

}
