package com.engraph.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.engraph.model.Asset;
import com.engraph.model.BuildingFloor;
import com.engraph.model.SiteBuilding;
import com.engraph.model.SiteMaster;

/**
 * Spring Data JPA repository for the {@link Asset} entity.
 */
@Repository
public interface AssetRepository extends JpaRepository<Asset, Long>{

	Page<Asset> findAllBySiteId(SiteMaster siteId,Pageable pageable);
	
	List<Asset> findAllBySiteIdAndSiteBuildingAndBuildingFloor(SiteMaster siteId,
			SiteBuilding siteBuilding,BuildingFloor buildingFloor);
}
