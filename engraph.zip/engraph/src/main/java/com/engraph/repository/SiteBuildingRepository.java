package com.engraph.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.engraph.model.SiteBuilding;
import com.engraph.model.SiteMaster;
import com.engraph.service.dto.LookupDTO;

/**
 * Spring Data JPA repository for the {@link SiteBuilding} entity.
 */
@Repository
public interface SiteBuildingRepository extends JpaRepository<SiteBuilding, Long>{

	Optional<SiteBuilding> findBySiteBuildingId(Long siteBuildingId);
	
	Page<SiteBuilding> findAllBySiteId(SiteMaster siteId,Pageable pageable);

	@Query(value = "SELECT s.site_building_id, s.building_name from site_building s WHERE s.site_id=?1",
			nativeQuery = true)
	List<LookupDTO> findLookupForSite(Long siteId);
}
