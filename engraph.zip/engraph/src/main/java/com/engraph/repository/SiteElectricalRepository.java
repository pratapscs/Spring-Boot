package com.engraph.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.engraph.model.SiteElectrical;
import com.engraph.model.UserRegistration;

/**
 * Spring Data JPA repository for the {@link SiteElectrical} entity.
 */
@Repository
public interface SiteElectricalRepository extends JpaRepository<SiteElectrical, Long>{

}
