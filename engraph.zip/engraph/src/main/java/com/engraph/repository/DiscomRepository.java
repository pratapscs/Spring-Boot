package com.engraph.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.engraph.model.DiscomMaster;
import com.engraph.model.LocationMaster;


@Repository
public interface DiscomRepository extends JpaRepository<DiscomMaster, Long>{

	List<DiscomMaster> findAllByLocationId(LocationMaster locationId);
}
