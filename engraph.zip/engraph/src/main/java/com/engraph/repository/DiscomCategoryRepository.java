package com.engraph.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.engraph.model.DiscomCategoryBusinessTypeMaster;
import com.engraph.model.PowerTensionMaster;


@Repository
public interface DiscomCategoryRepository extends JpaRepository<DiscomCategoryBusinessTypeMaster, Long> {
	
	List<DiscomCategoryBusinessTypeMaster> findAllByPowerTenctionId(PowerTensionMaster powerTenctionId);
	
}