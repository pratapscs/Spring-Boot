package com.engraph.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.engraph.model.DiscomMaster;
import com.engraph.model.PowerTensionMaster;

@Repository
public interface PowerTensionRepository extends JpaRepository<PowerTensionMaster, Long>{

	List<PowerTensionMaster> findAllByDiscomId(DiscomMaster discomId);
}
