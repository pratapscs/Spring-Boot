package com.engraph.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.engraph.model.DesignationMaster;

/**
 * Spring Data JPA repository for the {@link DesignationMaster} entity.
 */
@Repository
public interface DesignationMasterRepository extends JpaRepository<DesignationMaster, Long>{
	
	Optional<DesignationMaster> findOneByDesignationId(Long designtionId);
}
