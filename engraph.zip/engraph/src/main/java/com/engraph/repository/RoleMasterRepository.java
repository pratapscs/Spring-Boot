package com.engraph.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.engraph.model.RoleMaster;


/**
 * Spring Data JPA repository for the {@link RoleMaster} entity.
 */
@Repository
public interface RoleMasterRepository extends JpaRepository<RoleMaster, Long> {

	Optional<RoleMaster> findOneByRoleId(Long roleId);
}
