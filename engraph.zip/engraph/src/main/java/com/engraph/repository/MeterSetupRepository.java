package com.engraph.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.engraph.model.MeterSetup;
import com.engraph.model.SiteMaster;

@Repository
public interface MeterSetupRepository  extends JpaRepository<MeterSetup, Long>{

	Page<MeterSetup> findAllBySiteId(SiteMaster siteId,Pageable pageable);
}
