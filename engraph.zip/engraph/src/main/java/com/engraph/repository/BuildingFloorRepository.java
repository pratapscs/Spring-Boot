package com.engraph.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.engraph.model.BuildingFloor;

/**
 * Spring Data JPA repository for the {@link BuildingFloor} entity.
 */
@Repository
public interface BuildingFloorRepository extends JpaRepository<BuildingFloor, Long>{

	Optional<BuildingFloor> findByBuildingFloorId(Long floorId);
	
}
