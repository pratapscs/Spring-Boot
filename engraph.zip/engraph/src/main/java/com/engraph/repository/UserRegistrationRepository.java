package com.engraph.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.engraph.model.Organization;
import com.engraph.model.UserRegistration;

/**
 * Spring Data JPA repository for the {@link UserRegistration} entity.
 */
@Repository
public interface UserRegistrationRepository extends JpaRepository<UserRegistration, Long> {

	String USERS_BY_EMAIL_CACHE = "usersByEmail";

	Optional<UserRegistration> findOneByEmailIgnoreCase(String email);

	Optional<UserRegistration> findOneByResetKey(String resetKey);

	Page<UserRegistration> findAllByOrgId(Organization orgId,Pageable pageable);

	Optional<UserRegistration> findOneByActivationKey(String authkey);

	Optional<UserRegistration> findOneByEmail(String email);

	Optional<UserRegistration> findOneByEmailAndPassword(String username, String password);
	
	Optional<UserRegistration> findOneByActivationKeyAndEmail(String authKey,String email);

}
