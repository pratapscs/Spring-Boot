package com.engraph.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.engraph.model.BillMaster;

/**
 * Spring Data JPA repository for the {@link BillMaster} entity.
 */
@Repository
public interface BillMasterRepository extends JpaRepository<BillMaster, Long> {

}
