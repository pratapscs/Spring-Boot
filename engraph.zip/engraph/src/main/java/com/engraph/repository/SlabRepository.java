package com.engraph.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.engraph.model.SlabMaster;
import com.engraph.model.UsageHourMaster;

@Repository
public interface SlabRepository extends JpaRepository<SlabMaster, Long> {

	List<SlabMaster> findAllByUsageHourMasterId(UsageHourMaster usageHourMasterId);
	
}
