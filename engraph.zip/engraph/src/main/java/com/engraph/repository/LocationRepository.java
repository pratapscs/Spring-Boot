package com.engraph.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.engraph.model.LocationMaster;

@Repository
public interface LocationRepository extends JpaRepository<LocationMaster, Long>{

}
