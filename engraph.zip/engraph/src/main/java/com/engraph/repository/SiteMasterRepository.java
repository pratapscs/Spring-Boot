package com.engraph.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.engraph.model.SiteMaster;
import com.engraph.service.dto.ResultDTO;


/**
 * Spring Data JPA repository for the {@link SiteMaster} entity.
 */
@Repository
public interface SiteMasterRepository extends JpaRepository<SiteMaster, Long>{

	Optional<SiteMaster> findBySiteId(Long siteId);
	
	Page<ResultDTO> findAllBySiteId(SiteMaster siteId,Pageable pageable);

}
