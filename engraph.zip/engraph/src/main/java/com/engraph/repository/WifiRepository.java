package com.engraph.repository;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.engraph.model.SiteMaster;
import com.engraph.model.WifiDetails;

public interface WifiRepository extends JpaRepository<WifiDetails, Long>{

	
	Page<WifiDetails> findAllBySiteId(SiteMaster siteId,Pageable pageable);

	
}
