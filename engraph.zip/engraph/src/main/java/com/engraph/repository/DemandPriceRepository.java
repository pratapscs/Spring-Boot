package com.engraph.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.engraph.model.DemandPriceMaster;


/**
 * Spring Data JPA repository for the {@link DemandPriceMaster} entity.
 */
@Repository
public interface DemandPriceRepository extends JpaRepository<DemandPriceMaster, Long>{

	
}
