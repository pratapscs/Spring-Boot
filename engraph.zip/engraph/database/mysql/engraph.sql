
CREATE TABLE `designation_master` (
  `designation_id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`designation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;


INSERT INTO `designation_master` VALUES (1,'Chief Operating Officer'),(2,'Group Head'),(3,'Facility Manager'),(4,'Facility Supervisor'),(5,'Energy Manager'),(6,'Energy Supervisor'),(7,'Audit Dept.'),(8,'BU Head'),(9,'FM Contracted Vendor');


CREATE TABLE `organization_details` (
  `organization_id` int(11) NOT NULL AUTO_INCREMENT,
  `organization_name` varchar(50) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL,
  `state` varchar(40) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `locality` varchar(200) DEFAULT NULL,
  `street_address` varchar(300) DEFAULT NULL,
  `building_name` varchar(30) DEFAULT NULL,
  `pin_code` varchar(40) DEFAULT NULL,
  `cin_number` varchar(30) DEFAULT NULL,
  `pan_number` varchar(30) DEFAULT NULL,
  `gst_number` varchar(30) DEFAULT NULL,
  `facility_manager_name` varchar(50) DEFAULT NULL,
  `facility_manager_email` varchar(100) DEFAULT NULL,
  `facility_manager_mobile` int(11) DEFAULT NULL,
  `facility_manager_phone` int(11) DEFAULT NULL,
  `is_multi_site` char(1) DEFAULT NULL,
  `total_site` int(11) DEFAULT NULL,
  `total_different_legal_site` int(11) DEFAULT NULL,
  PRIMARY KEY (`organization_id`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
  
  
CREATE TABLE `role_master` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(30) DEFAULT NULL,
  `role_description` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;


INSERT INTO `role_master` VALUES (1,'Super Admin','CURD Operation'),(2,'Admin','CURD Operation with permission'),(3,'Super User','Only Read Operation'),(4,'User','Read Operation on a particular module'),(5,'Guest','Read Operation on a particular module for a particular time period');


CREATE TABLE `registration_table` (
  `user_registration_id` int(11) NOT NULL AUTO_INCREMENT,
  `organization_id` int(11) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `salutation` varchar(45) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `registration_date` date DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `user_active_state` char(1) DEFAULT NULL,
  `password_hash` varchar(100) DEFAULT NULL,
  `user_authentication_email` varchar(1000) DEFAULT NULL,
  `user_authentication_confirmation_bit` varchar(100) DEFAULT NULL,
  `user_access_for` int(11) DEFAULT NULL,
  `user_deactivation_date` date DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `designation_id` int(11) DEFAULT NULL,
  `activated` binary(1) DEFAULT NULL,
  `activation_key` varchar(20) DEFAULT NULL,
  `deactivate_date` date DEFAULT NULL,
  `reset_key` varchar(45) DEFAULT NULL,
  `reset_date` date DEFAULT NULL,
  `registration_date` date DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`user_registration_id`),
  KEY `role_id_idx` (`role_id`),
  KEY `designation_id_idx` (`designation_id`),
  CONSTRAINT `role_id` FOREIGN KEY (`role_id`) REFERENCES `role_master` (`role_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `designation_id` FOREIGN KEY (`designation_id`) REFERENCES `designation_master` (`designation_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;


CREATE TABLE `asset_details` (
  `asset_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `asset_batch_number` varchar(255) DEFAULT NULL,
  `asset_mac_id` varchar(255) DEFAULT NULL,
  `asset_manufacturer` varchar(255) DEFAULT NULL,
  `asset_model_number` varchar(255) DEFAULT NULL,
  `electricity_meter_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`asset_id`),
  KEY `FKebxrrccc1bxsiw3mnghkujyp1` (`electricity_meter_id`),
  CONSTRAINT `FKebxrrccc1bxsiw3mnghkujyp1` FOREIGN KEY (`electricity_meter_id`) REFERENCES `electricity_meter_details` (`electricity_meter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `building_floor` (
  `building_floor_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `building_floor_buildup_area` double DEFAULT NULL,
  `building_floor_name` varchar(50) DEFAULT NULL,
  `building_floor_number` int(11) DEFAULT NULL,
  `site_building_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`building_floor_id`),
  KEY `FKexijowoiu990tj7rt3nea0apo` (`site_building_id`),
  CONSTRAINT `FKexijowoiu990tj7rt3nea0apo` FOREIGN KEY (`site_building_id`) REFERENCES `site_building` (`site_building_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `designation_master` (
  `designation_id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(30) DEFAULT NULL,
  `designation_description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`designation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

CREATE TABLE `electricity_meter_details` (
  `electricity_meter_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `meter_batch_number` varchar(255) DEFAULT NULL,
  `meter_mac_id` varchar(255) DEFAULT NULL,
  `meter_manufacturer` varchar(255) DEFAULT NULL,
  `meter_model_number` varchar(255) DEFAULT NULL,
  `meter_name` varchar(50) DEFAULT NULL,
  `meter_number` int(11) DEFAULT NULL,
  `meter_slave_id` varchar(255) DEFAULT NULL,
  `building_floor_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`electricity_meter_id`),
  KEY `FKe6wyrutuln8vss3npnk0xgtor` (`building_floor_id`),
  CONSTRAINT `FKe6wyrutuln8vss3npnk0xgtor` FOREIGN KEY (`building_floor_id`) REFERENCES `building_floor` (`building_floor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `site_building` (
  `site_building_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `building_buildup_area` double DEFAULT NULL,
  `building_electrical_diagram` varchar(255) DEFAULT NULL,
  `building_name` varchar(50) DEFAULT NULL,
  `building_number` int(11) DEFAULT NULL,
  `building_terrace_area` double DEFAULT NULL,
  `building_total_meters` double DEFAULT NULL,
  `site_id` bigint(20) DEFAULT NULL,
  `building_total_floors` int(11) DEFAULT NULL,
  PRIMARY KEY (`site_building_id`),
  KEY `FKiq9kbk0126xy4rhk2ps53565k` (`site_id`),
  CONSTRAINT `FKiq9kbk0126xy4rhk2ps53565k` FOREIGN KEY (`site_id`) REFERENCES `site_master` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `site_electrical` (
  `site_electrical_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(50) DEFAULT NULL,
  `bill_date` int(11) DEFAULT NULL,
  `connection_id` varchar(50) DEFAULT NULL,
  `connection_load` double DEFAULT NULL,
  `consumer_code` varchar(50) DEFAULT NULL,
  `contract_demand` double DEFAULT NULL,
  `contract_demand_unit` varchar(10) DEFAULT NULL,
  `contract_end_date` date DEFAULT NULL,
  `contract_start_date` date DEFAULT NULL,
  `data_collection_frequency` int(11) DEFAULT NULL,
  `load_unit` varchar(10) DEFAULT NULL,
  `phase_connection` varchar(30) DEFAULT NULL,
  `rr_number` varchar(50) DEFAULT NULL,
  `site_electrical_diagram` varchar(255) DEFAULT NULL,
  `total_meter` int(11) DEFAULT NULL,
  `site_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`site_electrical_id`),
  KEY `FKcusjpn05odu06lji9jxnid4uk` (`site_id`),
  CONSTRAINT `FKcusjpn05odu06lji9jxnid4uk` FOREIGN KEY (`site_id`) REFERENCES `site_master` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `site_master` (
  `site_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) DEFAULT NULL,
  `site_abbreviation` varchar(100) DEFAULT NULL,
  `site_building_no` int(11) DEFAULT NULL,
  `site_buildup_area` double DEFAULT NULL,
  `site_connection_type` varchar(50) DEFAULT NULL,
  `site_consumption_goal` varchar(1) DEFAULT NULL,
  `site_energy_auditing` varchar(1) DEFAULT NULL,
  `site_energy_auditing_frequency` int(11) DEFAULT NULL,
  `site_goal_amount` varchar(30) DEFAULT NULL,
  `site_name` varchar(100) DEFAULT NULL,
  `site_open_area` double DEFAULT NULL,
  `site_terrace_area` double DEFAULT NULL,
  `site_total_area` double DEFAULT NULL,
  `site_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `site_power_source` (
  `site_power_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `all_source_meter` bit(1) DEFAULT NULL,
  `is_biomass_energy` bit(1) DEFAULT NULL,
  `is_diesel_generated` bit(1) DEFAULT NULL,
  `is_discom` bit(1) DEFAULT NULL,
  `is_fuel_cell` bit(1) DEFAULT NULL,
  `is_geothermal_energy` bit(1) DEFAULT NULL,
  `is_hydroelectrical_energy` bit(1) DEFAULT NULL,
  `is_hydrogen_energy` bit(1) DEFAULT NULL,
  `is_nuclear_energy` bit(1) DEFAULT NULL,
  `is_solar_energy` bit(1) DEFAULT NULL,
  `is_tidal_energy` bit(1) DEFAULT NULL,
  `is_wave_energy` bit(1) DEFAULT NULL,
  `is_wind_energy` bit(1) DEFAULT NULL,
  `non_meter_source` bit(1) DEFAULT NULL,
  `site_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`site_power_id`),
  KEY `FKpi2udp8386nx24r5ctipyh2en` (`site_id`),
  CONSTRAINT `FKpi2udp8386nx24r5ctipyh2en` FOREIGN KEY (`site_id`) REFERENCES `site_master` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



  
