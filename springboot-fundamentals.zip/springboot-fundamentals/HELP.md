# Getting Started

Spring:
------

Spring boot(Spring MVC, Spring Data, Spring Security, Spring Session, Spring AMQP, Spring Batch)

Configuration Challenges:
------------------------
- XML config files
- Configuration needed
- Annotation based

Structure:
---------
   
   Application - controller - services - repository - Database
        |
   Configuration(XML)			(Servlet Container - Tomcat)

- Spring Boot solves this problem, assists with configuration, and helps with 
  dependency management. 
- Spring Boot emphasizes convention over configuration and is smart enough to 
  choose your dependencies for you, and auto configures what you need so that 
  you can literally launch your application with a single click.

Simple Deployment:
------------------
-   Application  --(WAR file)--  Application
     (WAR file)			 (Servlet Container)
-  Spring Boot also simplifies the deployment of your application and comes with several 
   built‑in servlet containers and embeds directly with no need to deploy WAR files separately.
   You no longer need to download, install, and configure web servers, or package your application.

Features of spring boot:
-----------------------
- Automatic configuration
	- Time saving feature.
	- Configures application based on libraries.
	- Maven dependencies configured automatically.
	- for example, if you include a dependency in your Maven POM file for the H2 in‑memory
 	  database, Spring Boot auto configures your application for the specific database 
          access you need.

- Starter dependencies
	- spring-boot-starter-web
	- spring-boot-starter-test
	- spring-boot-starter-data-jpa
	- spring-boot-starter-thymeleaf
	- minimum dependencies required to create a web application using Spring:
		- <dependency>
		     <groupId>org.springframework</groupId>
		     <artifactId>spring-web</artifactId>
		     <version>5.1.8.RELEASE</version>
		  <dependency>
		- <dependency>
		     <groupId>org.springframework</groupId>
		     <artifactId>spring-webmvc</artifactId>
		     <version>5.1.8.RELEASE</version>
		  <dependency>
 		- But spring boot
		- <dependency>
		     <groupId>org.springframework.boot</groupId>
		     <artifactId>spring-boot-starter-web</artifactId>
		     <version>2.1.5.RELEASE</version>
		  <dependency>
		- Includes Testing Libraries(JUnit, Mockito, Hamcrest, Spring core, Spring test)
		 <dependency>
		     <groupId>org.springframework.boot</groupId>
		     <artifactId>spring-boot-starter-test</artifactId>
		     <scope>test</scope>
		  <dependency>
		- Spring Data JPA with Hibernate.(JDBC,EntityManager,TransactionAPI,SpringDataJPA, Aspects)
		 <dependency>
		     <groupId>org.springframework.boot</groupId>
		     <artifactId>spring-boot-starter-data-jpa</artifactId>
		  <dependency>
		- Web Application Development.(Spring MVC,REST,Tomcat,Jackson)
		 <dependency>
		     <groupId>org.springframework.boot</groupId>
		     <artifactId>spring-boot-web</artifactId>
		  <dependency>
		
- spring boot CLI
	- command line interface
	- application written using groovy scripts
	- rapid prototyping

- actuator
	- monitor running application.
	- manage via HTTP endpoints or JMX.
	- Health status, metrics, loggers, audit events, HTTP trace.
	
Spring Boot CLI:
----------------
- Generate a project using the CLI.
- Some developers prefer over Spring Initilizr
- Install CLI using Homebrew.

Autoconfiguration Action:
------------------------
- Auto-configuration is a very useful and powerful feature of Spring Boot,
  which takes a "convenction-over-configuration" approach.

How it Works:
------------
- Process (Finds JARs on the classpath and auto-configures bean).
- Auto-configures (Data source for Hibernate or DispatcherServlet for spring MVC)

Automatic Configuration:
-----------------------
- Java (Beans - add your own beans, like a datasource bean).
- Database Support (Default embedded database support backs away).

Auto-Configuration Insights:
---------------------------
- Start application with --debug switch
- Add a simple property to application-properties.
- Use the spring boot actuator.


@SpringBootApplication Annotation:
---------------------------------
- @SpringBootConfiguration - Replaces @Configuration and annotates a class as configuration.
- @EnableAutoConfiguration - Tells Spring Boot to configure beans.
- @ComponentScan - Tells Spring Boot to scan current package and subpackages.

Spring Boot application.properties:
----------------------------------


Spring Boot Profiles:
--------------------
- Different Environments(Profiles are fundamental to the Spring framework. Let's say we have an application 
  that we need to deploy to different environments such as development, test, and production. The application
  configuration in each of these environments will be different. 
  For example, when running in dev, you want the app to connect to the development database. 
  Or if you're deploying your application to production, you'll want to connect to the production database.)

- spring-profiles-active = dev -> define active profile
- applications-{profile}-properties -> Naming format
- applications-dev.properties -> Dev profile
- applications-test.properties -> Test/QA profile
- applications-prod.properties -> Prod profile

Accessing Data with Spring Boot:
-------------------------------
H2 Database:
-----------
- Open source database written in java.
- in-memory database
- good for POC's, dev environments, simple database.
- administer via the H2 console.

H2 Dependency - Auto-cnfigures H2 Related properties

<dependency>
   <groupId>com.h2database</groupId>
   <artifactId>h2</artifactId>
   <scope>runtime</scope>
</dependency>

H2 Defaults:
-----------
spring.datasource.url = jdbc.h2:mem:testdb
spring.datasource.driverClassName = org.h2.Driver
spring.datasource.username = sa
spring.datasource.password =
spring.h2.console.enabled = false

Override Defaults:
-----------------
spring.h2.console.enabled = true
spring.h2.console.path = /h2
spring.datasource.url = jdbc:h2:mem:bugtracker


ORM with JPA :
-------------
- (Database) - spring Data JPA (Hibernate),Java Persistence API(JPA),Java Database Connectivity(JDBC)

- Spring Data - Hibernate, Spring Data JPA, Spring ORM
 <dependency>
   <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-data-jpa</artifactId>
 </dependency>
 
Configuring a spring MVC Application with Spring boot:
-----------------------------------------------------
- Spring MVC Dependency : dependency needed for spring MVC is spring‑boot‑starter‑web,
- Spring Boot's autoconfiguration sees that Spring MVC's on the class path and autoconfiguration 
  kicks in, and it provides all of the dependencies and the autoconfiguration needed to develop 
  web applications, a dispatcher servlet, a default error page, an embedded servlet container, 
  Tomcat is the default, and WebJars to manage static dependencies.

 <dependency>
	<groupId>org.springframework.boot</groupId>
	<artifactId>spring-boot-starter-web</artifactId>
  </dependency>

MVC Design Pattern:
------------------

user ----(activates)-------------> Controller
 |					|
 |				( manipulates )
 |					|
  ---(sees)---> view <--(Displays on)--Model	

MVC:
---
Model -> Representation of data in a system.
View -> Responsible for displaying data.
Controller -> Directing incoming user requests.

Thymeleaf:
---------
- Fragaments(Fragments allow you to define repeatable chunks of code that can be reused in 
             another Thymeleaf   template file.)
- Repeatable chunks of code
- components reused across pages.

Packaging and Deployment:
------------------------
- packaged as traditional web application in a .war file.
- Trackzilla is standalone application.
- packaged in an executable JAR file with a main method.

Spring Boot Maven Plugin:
--------------------------
- Repakages your .jar and .war files to be executable.
- Runs Spring Boot application.
- Provides built-in dependency resolver.
- Manages lifecycle of spring boot application.

<build>
   <plugins>
      <plugin>
	 <groupId>org.springframework.boot</groupId>
	  <artifactId>spring-boot-maven-plugin</artifactId>
       </plugin>
   </plugins>
</build>

Building a RESTful web Application with Spring boot:
----------------------------------------------------

REST Architecture style:
-----------------------
- Data and functionality in the API are considered resources and identify through 
  something called the URI, or the Uniform Resource Identifier.
- Resources are manipulated using a fixed set of operations.
  (GET retrieves a resource, POST creates one, use PUT to update the resource,
   DELETE will remove it)
- Resources can be represented in multiple formats like HTML, XML, plain text, and 
  other formats defined by a media type.
- Communication b/w the client and endpoint is stateless,meaning the server will 
  not remember or store any state about the client that made the call.

Response formats:
----------------
Class ResponseEntity<T>  -> ResponseEnity is generic

return new ResponseEntity<List<Ticket>>(list, HttpStatus.OK) -> return tickets

return new ResponseEntity<List<Application>>(list, HttpStatus.OK) -> retunn applications

Response codes:
--------------
- HttpStatus.OK - 200
- HttpStatus.BAD_REQUEST - 400
- HttpStatus.CONFLICT - 409
- HttpStatus.NOT_FOUND - 404 Not Found

- Success Status Code(200)
- Failure Status code(404)

Exception Handling:
-----------------
- ResponseStatusException
	- Programmatic alternative to @ResponseStatus
	- Provide HttpStatus and a reason and a cause.
	- Exceptions can  be created programmatically.
	- Provides a default error mapping.

Building a GraphQL Server with Spring Boot:
------------------------------------------
GraphQL:
-------
- REST is popular way to expose data from a server through an API.
- REST is very rigid and returns all of the data points as designed by the developer
- GraphQL offers greater flexibility  in the response returned than REST.

- GraphQL is a query language for API's or a syntax that describes how to ask for data.

Features:
--------
- Allows client to specify the exact data needed.
- Aggregation of data from multiple sources.
- No longer required to call multiple APIs for needed data.
- GraphQL offers maximum efficiency and flexibility.

Sample Query:
------------
{
findAllApplications
  {
    id
  }
}

o/p:

{
  "data":
   {
     "findAllApplications":
      [{ "id" : "1"},
       { "id" : "2"}]
    }
}
------------------------
{
findAllApplications
  {
    id
    owner
  }
}

o/p:

{
  "data":
   {
     "findAllApplications":
      [{ "id" : "1",
         "owner": "pratap"},
       { "id" : "2",
	 "owner": "ghowra"}}]
    }
}

GraphQL Dependencies:
--------------------
-  Graphql‑spring‑boot‑starter, this starter is very helpful because it will add 
   and automatically configure a GraphQL Servlet that you can access at /graphql. 
   This starter will also use a GraphQL schema library to parse all schema files 
   found on the class path. 
	        <dependency>
		     <groupId>com.graphql-java</groupId>
		     <artifactId>graphql-spring-boot-starter</artifactId>
		     <version>5.0.2</version>
		  <dependency>
- The second dependency is graphql‑java‑tools. This is a helper library to parse 
  the GraphQL schema.
		 <dependency>
		     <groupId>com.graphql-java</groupId>
		     <artifactId>graphql-java-tools</artifactId>
		     <version>5.2.4</version>
		  <dependency>

GraphQL Operations:
------------------

Mutations:
---------
- GraphQL also has the ability to update the data stored on the server by means of
  mutations. 
- Mutations such as creating, updating, or deleting will change the data, unlike a query.
- Mutations are defined in the Java code by defining a class that implements GraphQLMutationResolver.
- Mutation implements GraphQLMutationResolver. The mutation resolver allows Spring to
  automatically detect and call the right method in response to one of the GraphQL 
  mutations declared inside of the schema.

Ex:
---
Create:
-------
mutation{
   newApplication(
	name: "pratap",
	owner: "swetha",
	description: "An Application used a schedule"),{
	  id
	  name
          owner
	  description
   }
}

update:
-------
mutation{
   updateApplicationOwner(
	newOwner: "sushma",
	id: "2"),{
	  id
	  name
          owner
	  description
   }
}

delete:
------
mutation{
    deleteApplication(id:1)
}

ErrorHandling:
--------------
-  GraphicQLError provides a field called extensions,And this is used to pass an 
   additional data to the error object sent to the client. In this case simply, 
   we will pass in the invalidApplicationId.

Demo:
-----
- open http://localhost:8080/graphiql  in browser.

Enabling Actuators, Metrics, and Health Indicators:
---------------------------------------------------
Spring Boot actuator:
--------------------
- Spring Boot Actuator provides health checkups, auditing, metrics gathering, 
  and HTTP tracing by exposing various HTTP or JMX endpoints you can interact with.

- Enable of these features is to add a dependency in the POM file for 
  spring‑boot‑starter‑actuator.

  <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-actuator</artifactId>
  <dependency>

Demo:
----
- open http://localhost:8080/actuator in browser.
- metrics - http://localhost:8080/actuator/metrics
  (endpoint shows several useful metrics, contains information like 
   the JVM memory used, system CPU usage, open files, and more.)
- http://localhost:8080/actuator/loggers for logs.

custom Endpoints(custom Health indicator):
------------------------------------------



Testing with Spring Boot:
------------------------
Testing Overview:
----------------
- Spring‑boot‑starter‑test imports both Spring Boot test modules, as 
  well as JUnit, AssertJ, Hamcrest, and a number of other useful 
  libraries.
	<dependency>
		<groupId>org.springframework.boot</groupId>
		<artifactId>spring-boot-starter-test</artifactId>
		<scope>test</scope>
	</dependency>

Unit Testing:
------------
- unit testing REST APIs using JUnit, Mockito, and Spring Test, also known as MockMvc
- Writing unit tests using JUnit allows you to test individual units of source code. 
  JUnit is by far the most popular unit testing framework. Mockito is a great mocking 
  framework, which we'll use to provide data to our unit tests. Spring also has the 
  @MockBean annotation, which works well with the Mockito library.
- @WebMvcTest is an annotation used for controller layer unit testing and is often used 
  to test one controller class at a time, and works in combination with Mockito to mock 
  the dependencies. 
- @WebMvcTest scans only the controllers, so @Controllers, including @RestControllers, 
  and will not load the full application context.
- @WebMvcTest - Dependent beans must be mocked.
- @WebMvcTest - Speeds up testing by loading small portion of application.

Integratin Testing:
------------------
- Integration testing allows for testing of the entire application and all of its 
  layers and not just individual units, and it is useful to be able to do this without 
  requiring deployment of the application
  
- @SpringBootTest annotation is useful for integration testing and is chosen over 
  @WebMVCTest  because @SpringBootTest starts the full application context, 
  including the server, and does not customize component scanning at all.
  
-  @SpringBootTest will look for the main configuration class, annotated with 
   the @SpringBootApplication annotation, and use that to start a Spring 
   ApplicationContext, simulating a client call. Let's look at integration testing.




