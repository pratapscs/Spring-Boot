package com.pratap.exception;

import graphql.ErrorType;
//import graphql.GraphQLError;
import graphql.language.SourceLocation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ApplicationNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -4256466474030548431L;
	
	private Map<String, Object> extensions = new HashMap<>();

	/*
	 * public ApplicationNotFoundException(String exception) { 
	 *    super(exception); 
	 * }
	 */
	
	 public ApplicationNotFoundException(String message, Long invalidApplicationId) {
	        super(message);
	        extensions.put("invalidApplicationId", invalidApplicationId);
	    }

	    public List<SourceLocation> getLocations() {
	        return null;
	    }

	    public Map<String, Object> getExtensions() {
	        return extensions;
	    }

	    public ErrorType getErrorType() {
	        return ErrorType.DataFetchingException;
	    }
	
}
