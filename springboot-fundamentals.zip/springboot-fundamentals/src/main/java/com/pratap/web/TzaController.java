package com.pratap.web;

import com.pratap.entity.Application;
import com.pratap.entity.Ticket;
import com.pratap.exception.ApplicationNotFoundException;
import com.pratap.service.ApplicationService;
import com.pratap.service.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

//@RestController and @RequestMapping are spring MVC annotations not related to spring boot
//This simplifies creating RESTful web services. The controller now simply returns object 
//data that is written directly to the HTTP response as JSON.
@RestController 
@RequestMapping("/tza") // @RequestMapping is an important annotation because it maps HTTP requests to
                        // the correct handler methods in the controller.

public class TzaController {
   
	private ApplicationService applicationService;
    private TicketService ticketService;

    @Autowired
    public void setApplicationService(ApplicationService applicationService) { 
    	this.applicationService = applicationService; 
    }

    @Autowired
    public void setTicketService(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    /*
     * @RestController doesn't work with our view technology Thymeleaf, so methods cannot return models.
     * 
     * Notice here this method is returning a ResponseEntity. Now it can't return models because of the 
     * inclusion of the @ResponseBody annotation. @ResponseBody on a controller indicates to Spring that 
     * the return value of the method is serialized directly to the body of the HTTP request. 
     * 
     * ResponseEntity represents the entire HTTP response. That includes status code.
     * So it includes the status code, headers, and the response body. Now the HTTP response is fully configurable. 
     * All I need to do is return it from the endpoint, and Spring handles the rest.
     */
    @GetMapping("/tickets")
    public ResponseEntity<List<Ticket>> getAllTickets() {
        List<Ticket> list = ticketService.listTickets();
        return new ResponseEntity<List<Ticket>>(list, HttpStatus.OK);
    }

    @GetMapping("/applications")
    public ResponseEntity<List<Application>> getAllApplications() {
        List<Application> list = applicationService.listApplications();
        return new ResponseEntity<List<Application>>(list, HttpStatus.OK);
    }

    @GetMapping("/application/{id}")
    public ResponseEntity<Application> getApplication(@PathVariable("id") long id) {
        try {
            return new ResponseEntity<Application>(applicationService.findApplication(id),
                    HttpStatus.OK);
        } catch (ApplicationNotFoundException exception) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Application Not Found");
        }
    }
}