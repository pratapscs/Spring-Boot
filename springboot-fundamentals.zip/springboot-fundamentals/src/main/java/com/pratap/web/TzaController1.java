package com.pratap.web;

import com.pratap.service.ApplicationService1;
import com.pratap.service.ReleaseService1;
import com.pratap.service.TicketService1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TzaController1 {
	
    private ApplicationService1 applicationService;
    private TicketService1 ticketService;
    private ReleaseService1 releaseService;

    @Autowired
    public void setApplicationService(ApplicationService1 applicationService) {
        this.applicationService = applicationService;
    }

    @Autowired
    public void setTicketService(TicketService1 ticketService) {
        this.ticketService = ticketService;
    }

    @Autowired
    public void setReleaseService(ReleaseService1 releaseService) {
        this.releaseService = releaseService;
    }

    @GetMapping("/applications")
    public String retrieveApplications(Model model){
        model.addAttribute("applications", applicationService.listApplications());
        return "applications";
    }

    @GetMapping("/tickets")
    public String retrieveTickets(Model model){
        model.addAttribute("tickets", ticketService.listTickets());
        return "tickets";
    }

    @GetMapping("/releases")
    public String retrieveReleases(Model model){
        model.addAttribute("releases", releaseService.listReleases());
        return "releases";
    }
}