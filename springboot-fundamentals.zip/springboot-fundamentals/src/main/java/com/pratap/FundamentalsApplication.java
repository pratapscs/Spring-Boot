package com.pratap;

//import com.pratap.repository.ApplicationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.pratap.entity.Application;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.context.annotation.Bean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// This class used to bootstrap and launch a Spring application from a Java main method .

/*
 * @SpringBootApplication annotation, it bootstraps our application by starting Spring. 
 * 
 * Typically, it will create an instance of Spring's application context, expose command‑line 
 * arguments as Spring properties, load Spring beans, etc. 
 */
@SpringBootApplication
public class FundamentalsApplication {
	
	@SuppressWarnings("unused")
	private static final Logger log = LoggerFactory.getLogger(FundamentalsApplication.class);
	
	public static void main(String[] args) {
		//FundamentalsApplication.class as an argument to the run method to identify the primary Spring component
		//args array is also passed through to expose any command‑line arguments.
		SpringApplication.run(FundamentalsApplication.class, args);
		System.out.println("Hello Pratap!");
	}
	
	/*
	@Bean
	public CommandLineRunner demo(ApplicationRepository repository) {
		return (args) -> {
			repository.save(new Application("Trackzilla","kesha.williams","Application for tracking bugs."));
			repository.save(new Application("Expenses","mary.jones","Application to track expense reports."));
			repository.save(new Application("Notifications","karen.kane","Application to send alerts and notifications to users."));

			for (Application application : repository.findAll()) {
				log.info("The application is: " + application.toString());
			}
		};
	}
	*/
}
