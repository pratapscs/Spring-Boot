package com.pratap.service;

import com.pratap.entity.Release;

public interface ReleaseService1 {
    Iterable<Release> listReleases();
}


