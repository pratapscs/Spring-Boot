package com.pratap.service;

import com.pratap.entity.Application;

public interface ApplicationService1 {
    Iterable<Application> listApplications();
}


