package com.pratap.service;

import com.pratap.entity.Ticket;

public interface TicketService1 {
    Iterable<Ticket> listTickets();
}


