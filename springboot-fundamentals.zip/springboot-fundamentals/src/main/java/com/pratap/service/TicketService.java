package com.pratap.service;

import com.pratap.entity.Ticket;

import java.util.List;

public interface TicketService {
    List<Ticket> listTickets();
}


